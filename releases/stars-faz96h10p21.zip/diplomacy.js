/* ═══════════════════════════════════════════════════════════════════
   YILDIZ HANEDANI · diplomacy.js — DİPLOMASİ VE ENTRİKA
   Onur/Güven endeksi, Casus Belli, savaş ilanı, ittifaklar, casusluk,
   fraksiyonlar, federasyon, Galaktik Konsey.
   ═══════════════════════════════════════════════════════════════════ */


/* ---------- SINIRLAR / ETKİ ALANI ----------
   Her sistemin bir "erişim" yarıçapı var: koloni nüfusu, kaleler ve
   teknoloji büyüttükçe sınırlar genişler. Bölgeler haritada renkle ayrılır. */
function borderReach(sys){
  if (sys.owner < 0) return 0;
  const e = G.emps[sys.owner];
  if (!e || e.dead) return 0;
  let r = 210;                                   // taban etki
  for (const p of sys.planets){
    if (!p.col) continue;
    r += 26 * Math.sqrt(p.col.pop);              // nüfus sınırı iter
    r += (p.col.b.kale||0) * 55;                 // kaleler alanı genişletir
    r += (p.col.b.liman||0) * 22;
    if (focusOf(p.col).e.defFlat) r += 45;       // garnizon odağı
  }
  if (e.home === sys.id) r += 130;               // başkent güçlü yayılır
  r *= 1 + (e.mods.sensor||0) * .10;
  if (hasCivic(e,'fortress')) r *= 1.18;
  if (hasCivic(e,'panopt'))   r *= 1.10;
  return r;
}
/* Sınır baskısı: filo gücü ve koloni sayısı yüksek imparatorluklar
   rakiplerinin etki alanını geriye iter. Ancak bir sistemin kendi
   yakın çevresi (çekirdek) asla itilemez — kolonilerin güvendedir. */
const CORE_RADIUS = 165;
function borderPressure(e){
  if (!e || e.dead) return 1;
  if (e._press !== undefined && e._pressAt === G.day) return e._press;
  const pow = totalPower(e);
  const p = clamp(.78 + Math.log(1 + pow/1800) * .17 + e.colonies.length * .011, .70, 1.55);
  e._press = p; e._pressAt = G.day;
  return p;
}
function influenceAt(wx, wy){
  let best = -1, bestScore = Infinity;
  for (const s of G.sys){
    if (s.owner < 0) continue;
    const reach = s._reach || 0;
    if (!reach) continue;
    const dx = s.x - wx, dy = s.y - wy;
    const d2 = dx*dx + dy*dy;
    if (d2 > reach*reach) continue;
    const d = Math.sqrt(d2);
    // çekirdek bölge: sistemin hemen çevresi tartışmasız sahibinindir
    if (d < CORE_RADIUS) return s.owner;
    const score = (d / reach) / borderPressure(G.emps[s.owner]);
    if (score < bestScore){ bestScore = score; best = s.owner; }
  }
  return best;
}
function refreshReach(){
  for (const s of G.sys) s._reach = borderReach(s);
}
/* sahipsiz bir sistem kimin sınırları içinde kalıyor? */
function claimOf(sys){
  if (sys.owner >= 0) return sys.owner;
  return influenceAt(sys.x, sys.y);
}

/* ---------- SINIR SÜRTÜŞMESİ ----------
   Sınırları birbirine değen imparatorluklar arasında ilişki yavaşça
   aşınır. Uzun süren sürtüşme olaylara ve savaşa zemin hazırlar. */
function borderContacts(){
  // her imparatorluk çifti için "temas uzunluğu" (kaba örnekleme)
  const N = 46, cw = G.W/N, ch = G.H/N;
  const own = new Int16Array(N*N).fill(-1);
  const best = new Float32Array(N*N).fill(2);
  for (const s of G.sys){
    if (s.owner < 0 || !s._reach) continue;
    const r = s._reach;
    const x0 = Math.max(0, Math.floor((s.x-r)/cw)), x1 = Math.min(N-1, Math.ceil((s.x+r)/cw));
    const y0 = Math.max(0, Math.floor((s.y-r)/ch)), y1 = Math.min(N-1, Math.ceil((s.y+r)/ch));
    for (let y=y0;y<=y1;y++) for (let x=x0;x<=x1;x++){
      const dx = s.x-(x+.5)*cw, dy = s.y-(y+.5)*ch;
      const d = Math.sqrt(dx*dx+dy*dy);
      if (d > r) continue;
      const sc = d/r, i = y*N+x;
      if (own[i] < 0 || sc < best[i]){ own[i] = s.owner; best[i] = sc; }
    }
  }
  const pairs = {};
  for (let y=0;y<N;y++) for (let x=0;x<N-1;x++){
    const a = own[y*N+x], b = own[y*N+x+1];
    if (a >= 0 && b >= 0 && a !== b){
      const k = a < b ? a+'_'+b : b+'_'+a;
      pairs[k] = (pairs[k]||0) + 1;
    }
  }
  for (let y=0;y<N-1;y++) for (let x=0;x<N;x++){
    const a = own[y*N+x], b = own[(y+1)*N+x];
    if (a >= 0 && b >= 0 && a !== b){
      const k = a < b ? a+'_'+b : b+'_'+a;
      pairs[k] = (pairs[k]||0) + 1;
    }
  }
  return pairs;
}

function borderFriction(){
  refreshReach();
  const pairs = borderContacts();
  G.friction = G.friction || {};
  const seen = {};
  for (const k in pairs){
    const [a, b] = k.split('_').map(Number);
    const ea = G.emps[a], eb = G.emps[b];
    if (!ea || !eb || ea.dead || eb.dead) continue;
    if (ea.ally[b]) continue;                       // müttefikler sürtüşmez
    if (hasCivic(ea,'outpost') || hasCivic(eb,'outpost')) continue;
    if ((ea.treaty && ea.treaty[b]) || (eb.treaty && eb.treaty[a])) continue;
    seen[k] = true;
    // 94D.1: geographic contact is metadata, not proof of an intrusion.
    // Keep old counters/save references; no passive relation damage or random incident.
    G.friction[k] = (G.friction[k] || 0) + 1;
  }
  // teması kesilen çiftlerin sayacı sıfırlansın
  for (const k in G.friction) if (!seen[k]) G.friction[k] = 0;
}

/* 92A — savaş kanıt defteri. Puan/ödül/toprak dağıtmaz, RNG tüketmez.
   Her cephe tek devlet çiftine aittir. Yalnız açık destek çağrısı aynı
   sefere bağlar; ortak düşman/sonradan ittifak geçmişi yeniden yazmaz. */
const WAR_END_REASONS={exhaustion:'%100 savaş yorgunluğu nedeniyle zorunlu barış',crisis:'Galaktik kriz nedeniyle AI ateşkesi',agreement:'Diplomatik barış anlaşması','ai-peace':'AI tarafından başlatılan barış','council-unity':'Konsey Galaktik Odak kuralı','proxy-peace':'Vekil savaş yükümlülüğünün sona ermesi','status-quo':'Statüko anlaşması','alliance':'İttifak anlaşması','alliance-conflict':'İttifak ile savaş çelişkisinin onarılması','subject-binding':'Vasallık bağıyla çelişen savaşın onarılması','subjugation':'Boyun eğdirme sonucu','subjugation-federation':'Boyun eğdirme / federasyon sonucu','rebel-coalition':'Ortak isyancı koalisyonu','rebellion-victory':'Özgürlük savaşının kazanılması'};
function warLedgerEmpty(){ return {v:1,next:1,fronts:[]}; }
function warLedgerPair(a,b){
  const x=G.emps[a],y=G.emps[b];
  return !!(x && y && a!==b && !x.dead && !y.dead && !x.wild && !y.wild &&
    !x.crisisSide && !y.crisisSide && x.war[b] && y.war[a]);
}
function warLedgerFind(a,b){
  const fs=G.warLedger && G.warLedger.fronts || [];
  for(let i=fs.length-1;i>=0;i--){const f=fs[i];
    if(f.ended===null && f.sides.includes(a) && f.sides.includes(b)) return f;
  }
  return null;
}
function warLedgerMember(id){
  const e=G.emps[id],f=findFed(e);
  return {id,day:G.day,fed:f?f.id:null,lord:Number.isInteger(e.overlord)?e.overlord:null};
}
function warLedgerGoal(f,id){
  if(!f) return;
  const g=G.emps[id].wg && G.emps[id].wg[f.sides.find(x=>x!==id)];
  if(!g || (!f.legacy && Number.isFinite(g.start) && g.start<f.opened)) return;
  const targets=Array.isArray(g.targets)?g.targets.filter(n=>Number.isInteger(n)&&G.sys[n]):[];
  const item={by:id,day:G.day,type:String(g.t||''),targets};
  const last=f.goals.filter(x=>x.by===id).slice(-1)[0];
  if(!last || last.type!==item.type || JSON.stringify(last.targets)!==JSON.stringify(targets)) f.goals.push(item);
}
function warLedgerOpen(a,b,support=null,legacy=false){
  if(!warLedgerPair(a,b)) return null;
  const existing=warLedgerFind(a,b); if(existing) return existing;
  if(!G.warLedger) G.warLedger=warLedgerEmpty();
  const l=G.warLedger,id=l.next++;
  const metric=()=>({rounds:0,shipsLost:0,shipsDestroyed:0,damageDealt:0,damageTaken:0,
    groundLost:0,groundDestroyed:0,garrisonLost:0,garrisonReduced:0,systems:[],planets:[]});
  let parent=null,roles=[0,1];
  if(support && support.enemy===b && support.sponsor!==a){
    const p=warLedgerFind(support.sponsor,b);
    if(p && warLedgerPair(support.sponsor,b)){
      const r=p.roles[p.sides.indexOf(support.sponsor)];
      // Zıt safta daha önce yer almış devlet aynı sefere sessizce geçirilmez.
      const conflict=l.fronts.some(x=>x.campaign===p.campaign && x.sides.some((v,i)=>
        (v===a && x.roles[i]!==r)||(v===b && x.roles[i]===r)));
      if(!conflict){parent=p;roles=[r,1-r];}
    }
  }
  const f={id,campaign:parent?parent.campaign:id,parent:parent?parent.id:null,
    reason:parent?String(support.kind):legacy?'observed':'declaration',sides:[a,b],roles,
    opened:G.day,legacy:!!legacy,ended:null,endReason:null,
    entryKind:support&&support.kind||'declaration',sponsor:support&&Number.isInteger(support.sponsor)?support.sponsor:null,
    membership:[warLedgerMember(a),warLedgerMember(b)],goals:[],metrics:[metric(),metric()],occupation:[]};
  l.fronts.push(f); warLedgerGoal(f,a);warLedgerGoal(f,b);
  if(!legacy)recordNews({category:'war',empires:[a,b],key:'war-front:'+f.id,title:parent?'Savaşa yeni katılım':'Savaş ilanı',text:G.emps[a].name+' → '+G.emps[b].name,important:true});
  return f;
}
function warLedgerSync(reason='observed',actor=null){
  if(!G.warLedger) G.warLedger=warLedgerEmpty();
  for(const f of G.warLedger.fronts){
    if(f.ended!==null) continue;
    if(!warLedgerPair(...f.sides)){
      f.ended=G.day;f.endReason=reason+'|actor:'+(actor===null?(['observed','load-observed','legacy'].includes(reason)?'unknown':'auto'):actor);
      recordNews({category:'peace',empires:f.sides,key:'war-end:'+f.id,title:'Savaş sona erdi',text:(typeof WAR_END_REASONS!=='undefined'&&WAR_END_REASONS[reason]||'Bitiş nedeni: '+reason)+' · Savaş #'+f.id+' · '+f.sides.map(id=>G.emps[id]?.name||'?').join(' ↔ ')+' · gün '+G.day+' · '+f.endReason,important:true});continue;
    }
    for(const id of f.sides){
      const n=warLedgerMember(id),prev=f.membership.filter(x=>x.id===id).slice(-1)[0];
      if(!prev || prev.fed!==n.fed || prev.lord!==n.lord) f.membership.push(n);
      warLedgerGoal(f,id);
    }
  }
  // Eski kayıt ve declareWar dışındaki mevcut ayaklanma yolları:
  // gerçek başlangıç/katılım zinciri bilinmiyorsa açıkça kısmi kayıt.
  for(let a=0;a<G.emps.length;a++) for(let b=a+1;b<G.emps.length;b++)
    if(warLedgerPair(a,b) && !warLedgerFind(a,b)){
      const f=warLedgerOpen(a,b,null,true);
      if(!['legacy','load-observed'].includes(reason)){
        f.entryKind='event';
        warStartNotice(G.emps[a],G.emps[b]);
      }
    }
}
function warLedgerBattle(a,b,hitA,hitB,round=true){
  if(!warLedgerPair(a,b)) return;
  const f=warLedgerFind(a,b)||warLedgerOpen(a,b,null,true);
  for(const [id,taken,dealt] of [[a,hitA,hitB],[b,hitB,hitA]]){
    const m=f.metrics[f.sides.indexOf(id)];
    const n=x=>Number.isFinite(x)&&x>0?x:0;
    m.rounds+=round?1:0;m.shipsLost+=n(taken.killed);m.shipsDestroyed+=n(dealt.killed);
    m.damageTaken+=n(taken.damage);m.damageDealt+=n(dealt.damage);
    if(typeof diplomaticBattleEvidence==='function')diplomaticBattleEvidence(f,G.emps[id],n(dealt.damage));
  }
}
function warLedgerGround(a,b,lost,reduced){
  if(!warLedgerPair(a,b))return;
  const f=warLedgerFind(a,b)||warLedgerOpen(a,b,null,true),i=f.sides.indexOf(a);
  const n=v=>Number.isFinite(v)?Math.max(0,v):0;
  f.metrics[i].groundLost+=n(lost);f.metrics[1-i].groundDestroyed+=n(lost);
  f.metrics[i].garrisonReduced+=n(reduced);f.metrics[1-i].garrisonLost+=n(reduced);
}
function warLedgerCapture(sys,planet,old,by){
  if(old===by || !warLedgerPair(old,by)) return;
  const f=warLedgerFind(old,by)||warLedgerOpen(old,by,null,true),i=f.sides.indexOf(by);
  const key=planet===null?String(sys.id):sys.id+':'+planet;
  const keys=planet===null?f.metrics[i].systems:f.metrics[i].planets;
  if(!keys.includes(key)) keys.push(key); // Aynı yeri geri alıp vererek katkı şişirilemez.
  const prior=f.occupation.filter(x=>x.sys===sys.id && x.planet===planet).slice(-1)[0];
  if(prior && prior.to===by) return;
  f.occupation.push({sys:sys.id,planet,from:old,to:by,day:G.day});
}
// BETA-P0.2: read-only, per-observer DTO. Never select a newer war by its empire pair.
function warNewsReport(viewer,id){
  const fronts=G.warLedger?.fronts||[],f=fronts.find(x=>x.id===id);
  if(!viewer||G.emps[viewer.id]!==viewer||!f)return null;
  const known=n=>n===viewer.id||!!viewer.contact[n],mine=f.sides.indexOf(viewer.id);
  if(!warFrontKnown(viewer,f))return null;
  const seen=n=>!!G.sys[n]&&(G.sys[n].seen||[]).includes(viewer.id);
  const active=f.ended===null,number=n=>Number.isFinite(n)?n:null;
  const parties=f.sides.map((id,i)=>{const e=G.emps[id],foe=f.sides[1-i],own=id===viewer.id,observed=viewer.aiIntel?.powers?.[id];
    // Own fleets or a dated observation, never unobserved foreign fleets / a later war's statistics.
    const power=!active?null:own?{value:G.fleets.filter(x=>x.e===id).reduce((n,x)=>n+fleetPower(x),0),day:G.day,exact:true}:observed&&Number.isFinite(observed.value)&&Number.isFinite(observed.day)&&G.day-observed.day>=0&&G.day-observed.day<=720?{value:observed.value,day:observed.day,exact:false}:null;
    const m=mine>=0?f.metrics?.[mine]:null;
    return {id,role:f.roles?.[i]??i,exhaustion:active&&(own||intelOf(viewer,id)>=3)?number(e?.exh?.[foe]):null,power,
      shipsLost:m?number(own?m.shipsLost:m.shipsDestroyed):null};});
  const permitted=x=>warFrontKnown(viewer,x);
  const campaign=fronts.filter(x=>x.campaign===f.campaign&&permitted(x)),participants=[];
  for(const x of campaign)for(let i=0;i<x.sides.length;i++){const id=x.sides[i];if(known(id)&&!participants.some(p=>p.id===id))participants.push({id,role:x.roles?.[i]??i});}
  const actorMatch=/\|actor:(\d+)$/.exec(f.endReason||''),actor=actorMatch&&known(+actorMatch[1])?+actorMatch[1]:null;
  return {id:f.id,asOf:G.day,sides:f.sides.slice(),opened:f.legacy?null:f.opened,ended:f.ended,legacy:!!f.legacy,reason:String(f.endReason||'').split('|')[0],actor,
    entryKind:f.entryKind||'event',campaign:f.campaign,sponsor:Number.isInteger(f.sponsor)&&known(f.sponsor)?f.sponsor:null,
    parties,participants,goals:(f.goals||[]).filter(g=>g.by===viewer.id).map(g=>({by:g.by,type:String(g.type),day:g.day,targets:(g.targets||[]).filter(seen)})),
    fronts:active?campaign.filter(x=>x.ended===null&&warFrontKnown(viewer,x)).map(x=>({id:x.id,sides:x.sides.slice(),opened:x.legacy?null:x.opened})):[],
    progress:(f.occupation||[]).filter(x=>mine>=0&&seen(x.sys)&&known(x.from)&&known(x.to)).map(x=>({sys:x.sys,planet:x.planet,from:x.from,to:x.to,day:x.day}))};
}

function warLedgerView(e,foe){
  if(!e || G.emps[e.id]!==e) return null;
  const fs=G.warLedger && G.warLedger.fronts || [];
  const f=fs.filter(x=>x.sides.includes(e.id)&&x.sides.includes(foe)).slice(-1)[0];
  if(!f) return null;
  const i=f.sides.indexOf(e.id),role=f.roles[i],members=new Set();
  for(const x of fs) if(x.campaign===f.campaign)
    x.sides.forEach((id,j)=>{if(x.roles[j]===role && id!==e.id && e.contact[id]) members.add(id);});
  // Oyuncuya kendi cephe katkısı; yabancı cephe istatistiği/keşfedilmemiş konum yok.
  return {id:f.id,campaign:f.campaign,active:f.ended===null&&warLedgerPair(...f.sides),
    legacy:f.legacy,opened:f.opened,ended:f.ended,mine:JSON.parse(JSON.stringify(f.metrics[i])),
    partners:[...members],goals:f.goals.filter(x=>x.by===e.id).map(x=>({type:x.type,day:x.day}))};
}
function restoreWarLedger(raw){
  if(raw===undefined || raw===null){G.warLedger=warLedgerEmpty();warLedgerSync('legacy');return;}
  const fail=()=>{throw Error('Geçersiz savaş katkı kaydı');};
  const nat=n=>Number.isSafeInteger(n)&&n>=0, time=n=>Number.isFinite(n)&&n>=0;
  if(raw.v!==1 || !nat(raw.next) || raw.next<1 || !Array.isArray(raw.fronts)) fail();
  const ids=new Set(),active=new Set();
  for(const f of raw.fronts){
    if(!f || !nat(f.id) || !f.id || f.id>=raw.next || ids.has(f.id) ||
       !Array.isArray(f.sides) || f.sides.length!==2 || f.sides[0]===f.sides[1] ||
       f.sides.some(id=>!nat(id)||!G.emps[id]) || !Array.isArray(f.roles) ||
       f.roles.length!==2 || ![0,1].includes(f.roles[0]) || f.roles[1]!==1-f.roles[0] ||
       !time(f.opened) || !(f.ended===null || time(f.ended)&&f.ended>=f.opened) ||
       typeof f.legacy!=='boolean' || !Array.isArray(f.membership) || !Array.isArray(f.goals) ||
       !Array.isArray(f.metrics) || f.metrics.length!==2 || !Array.isArray(f.occupation)) fail();
    if(!fedRaiderLootValid(f))fail();
    if(f.parent===null){if(f.campaign!==f.id)fail();}
    else if(!ids.has(f.parent) || !raw.fronts.some(x=>x.id===f.parent&&x.campaign===f.campaign)) fail();
    ids.add(f.id);
    if(f.ended===null){const k=f.sides.slice().sort((a,b)=>a-b).join(':');if(active.has(k))fail();active.add(k);}
    for(const m of f.metrics){
      if(!m || ['rounds','shipsLost','shipsDestroyed'].some(k=>!nat(m[k])) ||
         ['damageDealt','damageTaken','groundLost','groundDestroyed','garrisonLost','garrisonReduced'].some(k=>!time(m[k])) ||
         ['systems','planets'].some(k=>!Array.isArray(m[k])||m[k].some(v=>typeof v!=='string')||new Set(m[k]).size!==m[k].length)) fail();
    }
    for(const x of f.membership) if(!x||!f.sides.includes(x.id)||!time(x.day)||
      !(x.fed===null||nat(x.fed))||!(x.lord===null||Number.isInteger(x.lord)&&x.lord>=-1))fail();
    for(const x of f.goals) if(!x||!f.sides.includes(x.by)||!time(x.day)||typeof x.type!=='string'||
      !Array.isArray(x.targets)||x.targets.some(n=>!nat(n)||!G.sys[n]))fail();
    for(const x of f.occupation) if(!x||!nat(x.sys)||!G.sys[x.sys]||
      !(x.planet===null||nat(x.planet)&&G.sys[x.sys].planets[x.planet])||
      !f.sides.includes(x.from)||!f.sides.includes(x.to)||x.from===x.to||!time(x.day))fail();
  }
  if(raw.preparations!==undefined&&!warPreparationsValid(raw.preparations))fail();
  G.warLedger=JSON.parse(JSON.stringify(raw));
  warLedgerSync('load-observed');
}

/* 92B — barış sonrası ortak paylaşım önerisi. Hiçbir sahiplik mutasyonu
   yapmaz. Katkı puanı pazarlık ağırlığıdır; otomatik mülkiyet hakkı değildir. */
function settlementEmpty(){return {v:1,next:1,offers:[]};}
function settlementAssetKey(sys,planet){return planet===null?'s:'+sys:'p:'+sys+':'+planet;}
function settlementVisible(e,row){
  const s=G.sys[row.sys],p=row.planet===null?null:s&&s.planets[row.planet];
  return !!(s && (row.from===e.id || (row.planet===null?s.seen:s.surv).includes(e.id)) &&
    (row.planet===null || p&&p.col));
}
function settlementContext(e,campaign){
  const no=why=>({ok:false,why});
  if(!e || G.emps[e.id]!==e || e.dead || e.wild || e.crisisSide) return no('Geçerli devlet yok');
  const fs=(G.warLedger&&G.warLedger.fronts||[]).filter(f=>f.campaign===campaign);
  const own=fs.find(f=>f.sides.includes(e.id));
  if(!own) return no('Bu seferin katılımcısı değilsin');
  if(fs.some(f=>f.legacy)) return no('Kısmi savaş kaydı paylaşım için yeterli değil');
  if(fs.some(f=>f.ended===null || warLedgerPair(...f.sides))) return no('Seferdeki bütün cepheler kapanmalı');
  const role=own.roles[own.sides.indexOf(e.id)],same=new Set(),enemy=new Set();
  for(const f of fs)f.sides.forEach((id,i)=>(f.roles[i]===role?same:enemy).add(id));
  if([...same].some(id=>enemy.has(id)))return no('Seferin taraf kaydı çelişkili');
  const members=[...same].filter(id=>G.emps[id]&&!G.emps[id].dead).sort((a,b)=>a-b);
  if(members.length<2) return no('Paylaşım için en az iki yaşayan ortak gerekir');
  if(members.some(id=>G.emps[id].wild||G.emps[id].crisisSide||diploBlocked(e,G.emps[id])))return no('Katılımcı doktrini ortak müzakereye kapalı');
  if(members.some(id=>id!==e.id&&!e.contact[id]))return no('Bütün ortaklarla temas gerekli');
  for(const a of members)for(const b of [...same,...enemy])
    if(a!==b&&(G.emps[a].war[b]||G.emps[b].war[a]))return no('Sefer tarafları arasında yeniden savaş var');
  const events=fs.flatMap(f=>f.occupation.map((o,i)=>({...o,front:f.id,order:i})));
  const keys=new Map();
  for(const o of events)if(enemy.has(o.from)&&same.has(o.to))keys.set(settlementAssetKey(o.sys,o.planet),o);
  const rows=[];
  for(const [key,o] of keys){
    const s=G.sys[o.sys],pl=o.planet===null?null:s&&s.planets[o.planet];
    if(!s || (o.planet!==null&&!pl?.col))continue;
    // Kolonili sistemde yörüngeyi ayrıca puanlayıp aynı toprağı iki kez dağıtma.
    if(o.planet===null&&s.planets.some(p=>p.col))continue;
    const from=pl?pl.owner:s.owner;
    if(!members.includes(from))continue; // üçüncü taraf veya düşman mülkü
    const history=events.filter(x=>settlementAssetKey(x.sys,x.planet)===key);
    const lastDay=Math.max(...history.map(x=>x.day));
    const latest=history.filter(x=>x.day===lastDay);
    // 92A aynı gün farklı cephelerin olay sırasını saklamıyor: belirsizliği dağıtma.
    if(new Set(latest.map(x=>x.front)).size>1 || latest.slice(-1)[0].to!==from)continue;
    const newer=(G.warLedger.fronts||[]).some(f=>f.campaign!==campaign&&f.occupation.some(x=>
      settlementAssetKey(x.sys,x.planet)===key&&x.day>=lastDay));
    if(newer)continue;
    const claims=members.filter(id=>fs.some(f=>f.goals.filter(g=>g.by===id&&g.day<=lastDay).slice(-1)
      .some(g=>g.type==='fetih'&&g.targets.includes(s.id))));
    rows.push({key,sys:s.id,planet:o.planet,from,value:pl?3:1,claims,
      revision:[s.shareRev||0,pl&&pl.shareRev||0],
      scope:[s.owner,s.planets.map(p=>[p.owner,p.shareRev||0,!!p.col])]});
  }
  rows.sort((a,b)=>a.sys-b.sys||(a.planet===null?-1:a.planet)-(b.planet===null?-1:b.planet));
  if(!rows.length)return no('Güncel sahipliği ve sefer kanıtı uygun toprak yok');
  const points={};
  for(const id of members){
    let damage=0,kills=0,ground=0;
    for(const f of fs){const i=f.sides.indexOf(id);if(i<0)continue;
      const m=f.metrics[i];damage+=m.damageDealt;kills+=m.shipsDestroyed;ground+=m.garrisonReduced;}
    const captures=new Set(events.filter(x=>x.to===id&&enemy.has(x.from)).map(x=>settlementAssetKey(x.sys,x.planet)));
    // Kolonili yerlerde yalnız koloni, boş sistemde yalnız sistem ağırlığı.
    const land=rows.filter(x=>captures.has(x.key)).length;
    points[id]=1+Math.min(1000,Math.floor(damage/100))+3*kills+Math.floor(ground/25)+2*land;
  }
  const total=rows.reduce((n,r)=>n+r.value,0),sum=members.reduce((n,id)=>n+points[id],0);
  const shares=members.map(id=>({id,points:points[id],target:total*points[id]/sum,
    held:rows.filter(r=>r.from===id).reduce((n,r)=>n+r.value,0)}));
  const state=members.map(id=>({id,fed:findFed(G.emps[id])?.id??null,lord:G.emps[id].overlord??null,
    persona:G.emps[id].mizac||G.emps[id]._pers,allies:members.map(x=>!!G.emps[id].ally[x])}));
  const stamp=JSON.stringify({protocol:2,campaign,role,fs,rows,shares,state});
  return {ok:true,campaign,role,members,rows,shares,total,stamp};
}
/* 95C: geography breaks equal contribution/claim scores in NEW drafts.
   Existing explicit assignments, offer stamps and unanimous approval survive.
   This is a known military route assessment, never a new ownership right. */
function settlementReach(e,row){
  if(row.from===e.id)return true;
  const probe={e:e.id,ships:[{c:'kor',h:1}]};
  return (e.colonies||[]).slice(0,6).some(c=>G.sys[c.s]&&aiKnownRoute(e,probe,c.s,row.sys));
}
function settlementPreview(e,campaign,assignments=null){
  const c=settlementContext(e,campaign);if(!c.ok)return c;
  const given=Object.fromEntries(c.members.map(id=>[id,0])),rows=[];
  if(assignments!==null && (typeof assignments!=='object'||Array.isArray(assignments)||
    Object.keys(assignments).some(k=>!c.rows.some(r=>r.key===k))))return {ok:false,why:'Geçersiz toprak satırı'};
  for(const r of c.rows){
    const score=id=>c.shares.find(s=>s.id===id).target-given[id]+(r.claims.includes(id)?4:0)+(r.from===id?2:0);
    const reach=Object.fromEntries(c.members.map(id=>[id,settlementReach(G.emps[id],r)]));
    const ranked=c.members.slice().sort((a,b)=>score(b)-score(a)||Number(reach[b])-Number(reach[a])||a-b);
    const to=assignments&&Object.prototype.hasOwnProperty.call(assignments,r.key)?assignments[r.key]:ranked[0];
    if(!c.members.includes(to))return {ok:false,why:'Alıcı bu seferin yaşayan ortağı değil'};
    given[to]+=r.value;
    rows.push({...r,to,why:(r.claims.includes(to)?'Fetih hedefi; ':'')+(r.from===to?'Mevcut kontrol korunuyor; ':'Kontrol devri önerisi; ')+
      'alıcının katkı ağırlığı '+c.shares.find(s=>s.id===to).points});
  }
  return {...c,rows,shares:c.shares.map(s=>({...s,allocated:given[s.id],delta:given[s.id]-s.held})),cost:0};
}
function settlementOpinion(e,q){
  if(q.rows.some(r=>!settlementVisible(e,r))||q.members.some(id=>id!==e.id&&!e.contact[id]))
    return {yes:false,why:'Toprak veya ortaklar hakkında yeterli bilgi yok'};
  const s=q.shares.find(x=>x.id===e.id);if(!s)return {yes:false,why:'Katılımcı değil'};
  const yes=s.allocated+1>=s.target*.8 && s.held-s.allocated<=Math.max(1,q.total*.4);
  return {yes,why:yes?'Katkı payı ve verilen toprak kabul edilebilir':'Önerilen pay katkıma göre düşük veya verilen toprak fazla'};
}
function settlementTerms(o){return JSON.stringify([o.campaign,o.role,o.proposer,o.created,o.expires,o.stamp,o.rows,o.shares,o.members,o.total]);}
function settlementState(o){
  if(!o)return {state:'invalid',why:'Teklif yok'};
  if(!['pending','approved'].includes(o.state))return {state:o.state,why:o.why||''};
  if(o.terms!==settlementTerms(o))return {state:'invalid',why:'Onaylanan teklif içeriği değişti; yeni teklif gerekli'};
  if(G.day>=o.expires)return {state:'expired',why:'Teklifin 180 günlük süresi doldu'};
  const q=settlementContext(G.emps[o.proposer],o.campaign);
  if(!q.ok||q.stamp!==o.stamp)return {state:'invalid',why:q.ok?'Sahiplik, katılım veya sefer bilgisi değişti':q.why};
  return {state:o.state,why:''};
}
function settlementTick(){
  for(const o of G.settlements?.offers||[]){const s=settlementState(o);o.state=s.state;o.why=s.why;}
}
/* 92D: aylık barış gündemi. Oyuncunun oyu ve son uygulaması otomatize edilmez.
   Sefer/taraf başına yalnız bir otomatik teklif; reddin ardından manuel müzakere.
   Arşivdeki eski savaşlara yeni gündem açılmaz. RNG tüketmez. */
function settlementAgendaTick(){
  const result={submitted:0,applied:0,blocked:0};
  if(!G.p||G.over||_dealTxActive||G._sideBuf)return result;
  settlementTick();
  const offers=G.settlements?.offers||[];
  const apply=o=>{
    if(o.members.includes(0)||o.members.some(id=>!G.emps[id]?.ai))return;
    const r=settlementApply(G.emps[o.proposer],o.id);
    if(r.ok)result.applied++;else result.blocked++;
  };
  for(const o of offers)if(o.state==='approved')apply(o);
  const groups=new Map();
  for(const f of G.warLedger?.fronts||[]){
    if(!groups.has(f.campaign))groups.set(f.campaign,[]);
    groups.get(f.campaign).push(f);
  }
  const recent=[...groups.entries()].filter(([,fs])=>fs.every(f=>!f.legacy&&f.ended!==null)&&
    G.day-Math.max(...fs.map(f=>f.ended))<=180)
    .sort((a,b)=>a[0]-b[0]);
  for(const [campaign,fs] of recent){
    for(const role of [0,1]){
      if(result.submitted>=2)return result;
      if(offers.some(o=>o.campaign===campaign&&o.role===role))continue;
      const ids=[...new Set(fs.flatMap(f=>f.sides.filter((id,i)=>f.roles[i]===role)))].sort((a,b)=>a-b);
      for(const id of ids){
        const e=G.emps[id];if(!e?.ai||id===0||e.dead||e.wild||e.crisisSide)continue;
        const q=settlementPreview(e,campaign);
        if(!q.ok||!q.rows.some(r=>r.from!==r.to)||!settlementOpinion(e,q).yes)continue;
        const r=settlementSubmit(e,campaign,q.stamp);
        if(!r.ok){result.blocked++;break;}
        result.submitted++;
        const o=settlementOffer(r.id);
        if(o.members.includes(0)){
          try{say('Ortak savaş paylaşımı önerildi — Diplomasi merkezinde inceleyebilirsin','dip');}
          catch(err){sideBufferError('notice',err,'settlement-agenda');}
        }else if(o.state==='approved')apply(o);
        break;
      }
    }
  }
  return result;
}
function settlementOffer(id){return (G.settlements?.offers||[]).find(o=>o.id===id);}
function settlementSubmit(e,campaign,stamp,assignments=null){
  const q=settlementPreview(e,campaign,assignments);
  if(!q.ok)return q;
  if(q.stamp!==stamp)return {ok:false,why:'Taslak eskidi; yeniden incele'};
  if(q.rows.some(r=>!settlementVisible(e,r)))return {ok:false,why:'İncelenemeyen toprak var; keşif bilgisi gerekli'};
  if((G.settlements?.offers||[]).some(o=>o.campaign===campaign&&o.role===q.role&&
    ['pending','approved','applied'].includes(settlementState(o).state)))return {ok:false,why:'Bu taraf için açık, onaylı veya uygulanmış teklif var'};
  const tx=dealTxBegin();
  try{
    if(!G.settlements)G.settlements=settlementEmpty();
    const o={id:G.settlements.next++,campaign,role:q.role,proposer:e.id,created:G.day,expires:G.day+180,
      stamp:q.stamp,rows:q.rows,shares:q.shares,total:q.total,members:q.members,state:'pending',why:'',votes:[]};
    o.terms=settlementTerms(o);
    o.votes.push({by:e.id,yes:true,why:'Teklifi inceleyip sundu'});
    for(const id of q.members){
      if(id===e.id||id===0)continue; // oyuncunun oyu hiçbir koşulda otomatik değil
      const opinion=settlementOpinion(G.emps[id],q);o.votes.push({by:id,...opinion});
    }
    o.state=o.votes.some(v=>!v.yes)?'rejected':o.votes.length===o.members.length?'approved':'pending';
    G.settlements.offers.push(o);
    if(typeof G._settlementFailInject==='function')G._settlementFailInject('submit');
    return {ok:true,id:o.id,state:o.state};
  }catch(err){dealTxRollback(tx);return {ok:false,why:'Teklif kaydedilemedi; önceki durum korundu'};}
}
function settlementVote(e,id,yes){
  const o=settlementOffer(id),s=settlementState(o);
  if(!e||G.emps[e.id]!==e||e.dead||typeof yes!=='boolean'||s.state!=='pending'||
    !o.members.includes(e.id)||o.votes.some(v=>v.by===e.id))return {ok:false,why:s.why||'Oy artık kullanılamaz'};
  if(yes&&(o.rows.some(r=>!settlementVisible(e,r))||o.members.some(id=>id!==e.id&&!e.contact[id])))
    return {ok:false,why:'Tam teklif incelenemiyor; kabul için keşif ve temas gerekli'};
  const tx=dealTxBegin();
  try{
    o.votes.push({by:e.id,yes,why:yes?'Açık onay verdi':'Teklifi reddetti'});
    o.state=!yes?'rejected':o.votes.length===o.members.length?'approved':'pending';
    if(typeof G._settlementFailInject==='function')G._settlementFailInject('vote');
    return {ok:true,state:o.state};
  }catch(err){dealTxRollback(tx);return {ok:false,why:'Oy kaydedilemedi; önceki durum korundu'};}
}
function settlementWithdraw(e,id){
  const o=settlementOffer(id);
  if(!e||G.emps[e.id]!==e||!o||o.proposer!==e.id||!['pending','approved'].includes(settlementState(o).state))
    return {ok:false,why:'Bu teklif geri çekilemiyor'};
  o.state='withdrawn';o.why='Öneren geri çekti; yeni taslak yeni onay gerektirir';return {ok:true};
}
function restoreSettlements(raw){
  if(raw===undefined||raw===null){G.settlements=settlementEmpty();return;}
  const fail=()=>{throw Error('Geçersiz paylaşım kaydı');},ids=new Set();
  if(raw.v!==1||!Number.isSafeInteger(raw.next)||raw.next<1||!Array.isArray(raw.offers))fail();
  for(const o of raw.offers){
    if(!o||!Number.isSafeInteger(o.id)||o.id<1||o.id>=raw.next||ids.has(o.id)||
      !Number.isSafeInteger(o.campaign)||![0,1].includes(o.role)||!G.emps[o.proposer]||
      !Number.isFinite(o.created)||o.created<0||o.expires!==o.created+180||typeof o.stamp!=='string'||
      !['pending','approved','rejected','expired','invalid','withdrawn','applied'].includes(o.state)||
      !Array.isArray(o.members)||o.members.length<2||new Set(o.members).size!==o.members.length||
      !o.members.includes(o.proposer)||o.members.some(id=>!Number.isSafeInteger(id)||!G.emps[id])||
      !Array.isArray(o.rows)||!o.rows.length||!Array.isArray(o.votes)||!Array.isArray(o.shares))fail();
    ids.add(o.id);const keys=new Set(),voters=new Set();
    for(const r of o.rows){
      const s=G.sys[r.sys];
      if(!s||!(r.planet===null||Number.isSafeInteger(r.planet)&&s.planets[r.planet])||
        r.key!==settlementAssetKey(r.sys,r.planet)||keys.has(r.key)||!o.members.includes(r.from)||
        !o.members.includes(r.to)||r.value!==(r.planet===null?1:3)||typeof r.why!=='string')fail();
      keys.add(r.key);
    }
    for(const v of o.votes){if(!v||!o.members.includes(v.by)||voters.has(v.by)||typeof v.yes!=='boolean'||typeof v.why!=='string')fail();voters.add(v.by);}
    const total=o.rows.reduce((n,r)=>n+r.value,0),shareIds=new Set();
    if(o.total!==total||o.shares.length!==o.members.length||!o.votes.some(v=>v.by===o.proposer&&v.yes))fail();
    for(const s of o.shares){
      if(!s||!o.members.includes(s.id)||shareIds.has(s.id)||
        ['points','target','held','allocated'].some(k=>!Number.isFinite(s[k])||s[k]<0)||s.points<1||
        s.held!==o.rows.filter(r=>r.from===s.id).reduce((n,r)=>n+r.value,0)||
        s.allocated!==o.rows.filter(r=>r.to===s.id).reduce((n,r)=>n+r.value,0)||s.delta!==s.allocated-s.held)fail();
      shareIds.add(s.id);
    }
    if(o.state==='pending'&&(o.votes.length===o.members.length||o.votes.some(v=>!v.yes)))fail();
    if(o.state==='rejected'&&!o.votes.some(v=>!v.yes))fail();
    if(['approved','applied'].includes(o.state)&&(o.votes.length!==o.members.length||o.votes.some(v=>!v.yes)))fail();
    if(o.state==='applied'){
      const r=o.receipt;
      if(o.terms!==settlementTerms(o)||!r||!o.members.includes(r.by)||!Number.isFinite(r.at)||r.at<o.created||r.at>=o.expires||r.at>G.day||
        JSON.stringify(r.transfers)!==JSON.stringify(o.rows.filter(x=>x.from!==x.to).map(x=>({key:x.key,from:x.from,to:x.to}))))fail();
      if(raw.offers.some(x=>x!==o&&x.state==='applied'&&x.campaign===o.campaign&&x.role===o.role))fail();
    }else if(o.receipt!==undefined)fail();
    const now=settlementPreview(G.emps[o.proposer],o.campaign,Object.fromEntries(o.rows.map(r=>[r.key,r.to])));
    // Güncel teklifler için satır/katkı özeti de yeniden türetilir; eski kayıt onay uyduramaz.
    if(now.ok&&now.stamp===o.stamp&&JSON.stringify([now.rows,now.shares,now.total,now.members])!==JSON.stringify([o.rows,o.shares,o.total,o.members]))fail();
  }
  G.settlements=JSON.parse(JSON.stringify(raw));settlementTick();
}

// Saf uygulama kapısı: onaylı satırlar yeniden üretilir; hiçbir mülk yazılmaz.
function settlementApplyQuote(e,id){
  const no=why=>({ok:false,why}),o=settlementOffer(id),state=settlementState(o);
  if(!e||G.emps[e.id]!==e||e.dead||state.state!=='approved'||!o.members.includes(e.id))
    return no(state.why||'Uygulanabilir ortak onayı yok');
  if(o.votes.length!==o.members.length||new Set(o.votes.map(v=>v.by)).size!==o.members.length||
    o.members.some(id=>!o.votes.some(v=>v.by===id&&v.yes===true)))return no('Oybirliği doğrulanamadı');
  const q=settlementPreview(G.emps[o.proposer],o.campaign,Object.fromEntries(o.rows.map(r=>[r.key,r.to])));
  if(!q.ok||q.stamp!==o.stamp||JSON.stringify([q.rows,q.shares,q.members,q.total])!==JSON.stringify([o.rows,o.shares,o.members,o.total]))
    return no('Onaylanan paylaşım değişti; yeni teklif gerekli');
  if(o.rows.some(r=>!settlementVisible(e,r))||o.members.some(id=>id!==e.id&&!e.contact[id]))return no('Tam paylaşım incelenemiyor');
  if(G.settlements.offers.some(x=>x!==o&&x.state==='applied'&&x.campaign===o.campaign&&x.role===o.role))return no('Bu seferin paylaşımı zaten uygulandı');
  const transfers=o.rows.filter(r=>r.from!==r.to);
  for(const r of transfers){
    const s=G.sys[r.sys],p=r.planet===null?null:s.planets[r.planet];
    if(p){
      // Gerçek koloni ve iki devletin indeksleri birbiriyle tutarlı olmalı.
      const owners=G.emps.flatMap(a=>(a.colonies||[]).filter(c=>c.s===s.id&&c.p===p.i).map(()=>a.id));
      if(owners.length!==1||owners[0]!==r.from)return no('Koloni sahiplik kaydı tutarsız');
    }else if(s.queue.length||(s.work&&s.work.length))return no('Boş sistemde bekleyen üretim var; önce tamamlanmalı');
  }
  for(const id of o.members){
    const actual=G.sys.flatMap(s=>s.planets.filter(p=>p.col&&p.owner===id).map(p=>({s:s.id,p:p.i})));
    const after=actual.length-transfers.filter(r=>r.planet!==null&&r.from===id).length+transfers.filter(r=>r.planet!==null&&r.to===id).length;
    if(actual.length>0&&after===0)return no('Bir ortak son kolonisinden vazgeçemez');
  }
  return {ok:true,offer:o,transfers};
}
function settlementApply(e,id){
  if(_dealTxActive||G._sideBuf)return {ok:false,why:'Başka bir işlem sürüyor'};
  let tx=null,q;const buf=[];
  _dealTxActive=true;
  const inject=stage=>{if(typeof G._settlementFailInject==='function')G._settlementFailInject(stage);};
  try{
    q=settlementApplyQuote(e,id);if(!q.ok)return q;
    tx=dealTxBegin();G._sideBuf=buf;inject('before:apply');
    const touched=new Set();
    for(const r of q.transfers){
      const s=G.sys[r.sys],from=G.emps[r.from],to=G.emps[r.to];
      if(r.planet===null){
        territoryOwnerSet(s,to.id);
        delete s.loopBuild;delete s.rally;delete s._loopWarn;
      }else{
        const p=s.planets[r.planet],c=p.col;
        const idx=from.colonies.findIndex(x=>x.s===s.id&&x.p===p.i);
        from.colonies.splice(idx,1);to.colonies.push({s:s.id,p:p.i});
        for(const leader of leaderPool(from))if(leader.tip==='vali'&&String(leader.post)===s.id+':'+p.i)delete leader.post;
        delete c.leader;c.auto=false;delete c._dirWarn;
        territoryOwnerSet(p,to.id); // Barışçı devir: nüfus/yapı/fetih hafızası korunur.
        if(!s.surv.includes(to.id))s.surv.push(to.id);
      }
      if(!s.seen.includes(to.id))s.seen.push(to.id);
      touched.add(s);inject('after:'+r.key);
    }
    inject('after:items');
    for(const id of q.offer.members){
      const a=G.emps[id];
      if(a.colonies.length&&!a.colonies.some(c=>c.s===a.home))a.home=a.colonies.slice().sort((a,b)=>a.s-b.s||a.p-b.p)[0].s;
    }
    economyTick(true); // Yalnız türetilmiş gelir/kapasite; stok, takvim veya aylık tik ilerlemez.
    for(const s of touched)s.def=sysDefense(s);
    refreshReach();
    inject('after:recalc');
    for(const r of q.offer.rows){
      const s=G.sys[r.sys],p=r.planet===null?null:s.planets[r.planet];
      if((p?p.owner:s.owner)!==r.to)throw Error('Devir sonucu uyuşmuyor');
      if(p){const owners=G.emps.flatMap(a=>(a.colonies||[]).filter(c=>c.s===s.id&&c.p===p.i).map(()=>a.id));
        if(owners.length!==1||owners[0]!==r.to)throw Error('Koloni indeksi uyuşmuyor');}
    }
    q.offer.state='applied';q.offer.why='Ortakların onayladığı paylaşım uygulandı';
    q.offer.receipt={at:G.day,by:e.id,transfers:q.transfers.map(r=>({key:r.key,from:r.from,to:r.to}))};
    inject('after:receipt');
    // Yalnız oyuncunun katıldığı paylaşım bildirilir; yabancı sefer isimleri sızmaz.
    if(q.offer.members.includes(0))say('Ortak savaş paylaşımı tamamlandı — '+q.transfers.length+' devir','win');
    commitSideBuffer(buf);inject('after:log');inject('son');
  }catch(err){if(tx)dealTxRollback(tx);return {ok:false,why:'Paylaşım uygulanamadı; önceki durum korundu'};}
  finally{if(tx)dealTxRestoreAuth(tx);_dealTxActive=false;}
  // Commit sonrasında sunum hatası devri geri almaz veya tekrar uygulatmaz.
  flushSideBuffer(buf);
  try{View.bcache=null;View.bkey='';UI.refresh();}catch(err){sideBufferError('refresh',err,'settlement-presentation');}
  return {ok:true,state:'applied',transfers:q.transfers.length};
}

/* 94D.1: edge-triggered notices, never synthesized from loaded war flags.
   Ledger mutations participate in existing deal rollback. UI remains deferred. */
function warStartNotice(a,b,support=null){
  if(!a||!b||!a.war[b.id]||!b.war[a.id])return false;
  const f=warLedgerFind(a.id,b.id)||warLedgerOpen(a.id,b.id,support);
  if(!f)return false;
  // Remote humans deserve the same explicit declaration contact as the host.
  // This reveals identity, never any location, fleet, stock or intelligence.
  if(a.ai===false||b.ai===false){a.contact=a.contact||{};b.contact=b.contact||{};a.contact[b.id]=true;b.contact[a.id]=true;}
  recordNews({category:'war',empires:[a.id,b.id],key:'war-front:'+f.id,title:'Savaş başladı',text:a.name+' → '+b.name,important:true});
  if(!G.p||!([a.id,b.id].includes(G.p.id)))return false;
  const root=(G.warLedger.fronts||[]).find(x=>x.id===f.campaign)||f;
  // One notice per actual pair/front, not one for the entire coalition.
  if(f.playerNotified)return false;
  f.playerNotified=true;
  const entry=f;
  const data={attacker:entry.sides[0],defender:entry.sides[1],rootAttacker:root.sides[0],rootDefender:root.sides[1],
    front:entry.id,campaign:entry.campaign,reason:entry.entryKind||'declaration',sponsor:entry.sponsor??null,
    day:G.day,year:G.year,month:G.month};
  say('SAVAŞ BAŞLADI — '+G.emps[data.attacker].name+' → '+G.emps[data.defender].name,'war');
  if(typeof UI!=='undefined'&&UI.warDeclared)deferUI(UI.warDeclared.bind(UI),data);
  return true;
}
/* Shared war knowledge for the war mode and the independent overlay.
   Diplomatic contact alone does not reveal third-party war plans. */
function knownWarPairs(viewer=G.p){
  if(!viewer)return [];
  const known=e=>e&&(e.id===viewer.id||!!(viewer.contact&&viewer.contact[e.id]));
  const out=[];
  for(let i=0;i<G.emps.length;i++)for(let j=i+1;j<G.emps.length;j++){
    const a=G.emps[i],b=G.emps[j];
    if(!warLedgerPair(i,j)||!known(a)||!known(b))continue;
    if(i!==viewer.id&&j!==viewer.id&&intelOf(viewer,i)<3&&intelOf(viewer,j)<3)continue;
    out.push({a:i,b:j,player:i===viewer.id||j===viewer.id});
  }
  return out;
}
function warMapConnections(){
  const endpoint=id=>{
    const e=G.emps[id],visible=s=>s&&s.owner===id&&pSeen(s);
    const home=G.sys[e.home];
    return visible(home)?home:G.sys.find(visible);
  };
  return knownWarPairs().map(p=>({...p,from:endpoint(p.a),to:endpoint(p.b)})).filter(p=>p.from&&p.to);
}

/* ---------- diplomasi ---------- */
/* A peace settles participation in an existing call, not the sponsor's other
   wars. A new source front still permits a genuinely new obligation. IDs
   disambiguate two events on the same game day; no new save field/RNG. */
function warCallSettled(a,b,support){
  if(!a||!b||!support||support.enemy!==b.id||!Number.isInteger(support.sponsor))return false;
  if(!['vassal','overlord','federation'].includes(support.kind))return false; // fresh voluntary promises are explicit decisions
  const source=warLedgerFind(support.sponsor,b.id);
  if(!source)return false;
  // Pre-ledger saves may still carry exact bilateral peace/source-war dates.
  const since=G.emps[support.sponsor]?.warSince?.[b.id],peace=Math.max(a.peaceAt?.[b.id]??-1,b.peaceAt?.[a.id]??-1);
  if(source.legacy&&Number.isFinite(since)&&since<=peace)return true;
  return (G.warLedger?.fronts||[]).some(f=>f.ended!==null&&f.sides.includes(a.id)&&f.sides.includes(b.id)&&
    (f.campaign===source.campaign||source.opened<f.ended||source.opened===f.ended&&source.id<=f.id));
}
function declareWar(a, b, support = null){
  if(warCallSettled(a,b,support))return false;
  const access=warDeclarationAccess(a,b);
  if(!access.ok){if(a?.id===0)say(access.why,'war');return false;}
  const fedDefense = fedDefensiveWar(a,b);
  // Galaktik Konsey savaş yasağı — çiğnemek ağır bedel
  if (typeof councilBlocksWar === 'function' && councilBlocksWar(a, b)){
    if (a.id === 0){
      say('KONSEY YASAĞI: ' + b.name + ' korunuyor. Yine de saldırırsan konsey sana döner.', 'war');
      /* 86G: Oyuncu bilinçli çiğneyebilir; ceza uygulanır ama savaş
         kurulumu aşağıdaki TEK ortak yoldan devam eder. Eski erken return,
         NAP/pakt/ittifak temizliği, hafıza, fraksiyon ve UI bildirimlerini
         atlıyordu. */
      councilPunish(a);
    } else {
      if (rnd() < .75) return false;               // AI genelde uyar
      councilPunish(a);
    }
  }
  if (!canDeclareWarOn(a,b)){
    if (a.id === 0) say(b.name + ' kendini galaksiden soyutlamış — savaş ilan edilemiyor');
    return false;
  }
  if (hasCivic(a,'warFury')){ a.furyUntil = G.day + 24*30; recalcMods(a); }
  if (hasCivic(a,'mobilize')){
    a.extra = a.extra || {};
    a.extra.dmgMul = (a.extra.dmgMul||0) + .30;
    recalcMods(a);
    if (a.id === 0) say('Sonsuz Seferberlik: filolarına kalıcı +%30 güç eklendi', 'win');
  }
  /* ── HAFIZA ── mağdur bunu unutmaz; söz çiğnemek galaksiye yayılır */
  const wasAlly = a.ally[b.id] && b.ally[a.id];
  const hadNap  = !!(a.nap && a.nap[b.id] > G.day);
  remember(b, a.id, wasAlly ? 'ihanet' : hadNap ? 'paktBozdu' : 'savasIlan');
  if (wasAlly || hadNap){
    for (const x of G.emps){
      if (x.dead || x.wild || x.id === a.id || x.id === b.id) continue;
      remember(x, a.id, 'paktBozdu');
      x.rel[a.id] = clamp(x.rel[a.id] - 14, -100, 100);
    }
    if (a.id === 0) say('İHANET — tüm galaksi bunu gördü, itibarın çöktü', 'war');
    else if (b.id === 0) say(a.name + ' verdiği sözü çiğnedi!', 'war');
  }
  const _cb = a._lastCB; a._lastCB = null;
  a.warCause = a.warCause || {};
  if (_cb){
    a.warCause[b.id] = _cb.n;
    if (b.id === 0) say('Gerekçeleri: "' + _cb.n + '"', 'war');
  }

  warLedgerSync();
  a.war[b.id] = true; b.war[a.id] = true;
  a.warSince = a.warSince || {}; b.warSince = b.warSince || {};
  a.warSince[b.id] = G.day; b.warSince[a.id] = G.day;   // FAZ 48
  a.warDefense = a.warDefense || {}; b.warDefense = b.warDefense || {};
  a.warDefense[b.id] = {since:G.day, defensive:fedDefense};
  b.warDefense[a.id] = {since:G.day, defensive:!fedDefense};
  warLedgerOpen(a.id, b.id, support);
  const warFed = findFed(a);
  if (warFed && warFed.warPermits) delete warFed.warPermits[a.id + '>' + b.id];
  endTreatiesForWar(a, b);
  a.warStart = a.warStart || {}; b.warStart = b.warStart || {};
  a.warStart[b.id] = G.day; b.warStart[a.id] = G.day;
  a.ally[b.id] = false; b.ally[a.id] = false;
  a.rel[b.id] = Math.min(a.rel[b.id], -60);
  b.rel[a.id] = Math.min(b.rel[a.id], -60);
  if (hasPerk(b,'condemn')){
    for (const x of G.emps){
      if (x.dead || x.wild || x.id === a.id) continue;
      x.rel[a.id] = clamp(x.rel[a.id] - 20, -100, 100);
      a.rel[x.id] = clamp(a.rel[x.id] - 8, -100, 100);
    }
    if (b.id === 0) say('Galaktik Kınama: ' + a.name + ' tüm galakside itibar kaybetti', 'win');
  }
  if (typeof facEvent === 'function'){ facEvent(a,'war'); facEvent(b,'war'); }
  if (typeof fedDefend === 'function') fedDefend(a, b);
  if (typeof fedAttack === 'function') fedAttack(a,b,support);
  if (typeof overlordDefend === 'function') overlordDefend(a, b);
  if (typeof judgeCasusBelli === 'function') judgeCasusBelli(a, b);
  warStartNotice(a,b,support);
  if(typeof aiPlanEvent==='function')aiPlanEvent(a,'war-started',{other:b.id,support:!!support});
  return true;
}
function peaceAlwaysAccepted(a, b){
  return hasPerk(a,'peaceAlways') || hasPerk(b,'peaceAlways');
}
/* ═══════════════════════════════════════════════════════════════════
   FAZ 80 — FANATİK ARINDIRICI SERT KİLİDİ
   Faz 73'te kilit yalnız oyuncu arayüzüne ve birkaç AI koluna
   konmuştu; canPeace/canAlly/canPact/evalOffer gibi ASIL kapılar
   açıktı ve AI oradan teklif sızdırıyordu.

   Artık tek bir kapı var: diploBlocked(a, b). TARAFLARDAN BİRİ
   bile Arındırıcıysa istihbarat dışındaki her diplomatik ve
   ticari eylem burada durur. Yeni bir diplomasi işlevi eklendiğinde
   tek satırla korunur.
   ═══════════════════════════════════════════════════════════════════ */
function diploBlocked(a, b){
  if (typeof isPurifier !== 'function') return false;
  if (a && isPurifier(a)) return true;
  if (b && isPurifier(b)) return true;
  return false;
}

function canPeace(a, b){
  if (diploBlocked(a, b)) return false;
  return !hasCivic(a,'blood') && !hasCivic(b,'blood') &&
         true;
}
function canAlly(a, b){
  if (diploBlocked(a, b)) return false;
  return true;
}
/* ═══════════════════════════════════════════════════════════════════
   FAZ 86C.2 — GÖREV 1B: SAF SAVAŞ SÖZÜ KAPISI

   ÖLÇÜLEN HATA: `canDeclareWarOn` AI için `_dealAuth`/`_warAuth`
   geçici yetkilerini şart koşuyor. dealQuote SAF aşamada çalıştığı
   için bu yetkiler henüz kurulmamış oluyor ve AI'ın anlaşma kapsamında
   verdiği `warOn` sözü quote'ta "o devlete savaş açamaz" diye
   ÖLÜYORDU (ölçüldü: quote.ok=false, _warAuth=null, _dealAuth=false).

   `canPromiseWarOn` ANLAŞMA KAPSAMINDA verilen sözün geçerliliğini
   sınar. Sıradan savaş meclisi yetkisinden (aiWarReview / _warAuth)
   AYRIDIR: burada geçici yetki aranmaz, çünkü yetkiyi anlaşmanın
   kendisi verir. SAFtır — global yetki alanlarına DOKUNMAZ ve RNG
   TÜKETMEZ; sonuç deterministiktir. */
function canPromiseWarOn(a, b, skipFed = false){
  if(sovereignPair(a,b))return {ok:false,why:'Önce bağımsızlık gerekir'};
  if (!a || !b) return {ok:false, why:'hedef devlet yok'};
  if (a.id === b.id)       return {ok:false, why:'kendine savaş açamaz'};
  if (b.dead)              return {ok:false, why:'hedef devlet yok'};
  if (b.wild)              return {ok:false, why:'korsanlara savaş sözü verilemez'};
  if (b.crisisSide)        return {ok:false, why:'kriz tarafına savaş sözü verilemez'};
  if (!a.contact[b.id])    return {ok:false, why:'hedefle temas yok'};
  /* Savaş ilanını yasaklayan doktrinler */
  if (typeof hasCivic === 'function' && hasCivic(a, 'shadow'))
    return {ok:false, why:'doktrini vekâlet savaşını yasaklar'};
  if (typeof isPurifier === 'function' && isPurifier(b))
    return {ok:false, why:'o devlete savaş açamaz'};
  /* Konsey yasağı: DETERMİNİSTİK sınanır (rnd() KULLANILMAZ). */
  if (typeof councilBlocksWar === 'function' && councilBlocksWar(a,b))
    return {ok:false, why:'Konsey savaş yasağı yürürlükte'};
  /* Zaten savaştaysa yeni etki yok — redundant kurallarına bırakılır. */
  if (a.war[b.id]) return {ok:true, redundant:true};
  if (!skipFed && !fedWarAllowed(a,b)) return {ok:false, why:'federasyon savaş izni gerekli'};
  return {ok:true};
}
function canDeclareWarOn(a, b){
  if (!a || !b || a.dead || b.dead || a.id === b.id || sovereignPair(a,b) || !fedWarAllowed(a,b)) return false;
  if(isVassal(a)&&a.vassalContract&&vassalContractOf(a)?.terms.autonomy==='consent'&&!overlordOf(a).war[b.id]&&!fedDefensiveWar(a,b))return false;
  if (false) return false;          // sürgüne kimse savaş açamaz
  if (!a || !a.ai) return true;                   // oyuncu kendi kararını verir
  if (G._dealAuth) return true;                   // anlaşmada verilmiş söz
  /* ESKİ GÜÇ MANTIĞI DEVRE DIŞI: aiTurn içindeki "ondan güçlüysem
     saldırırım" bloğu ve borderFriction'ın kendiliğinden savaşı artık
     buradan geçemez. AI savaşları YALNIZCA aiWarReview() üzerinden,
     yani hafıza ve Casus Belli değerlendirmesiyle açılır. */
  return G._warAuth === (a.id + '>' + b.id);
}
/* Bir tarafın "senin için" girdiği vekil savaşlar, asıl savaş bitince
   kendiliğinden sona erer. Aksi hâlde müttefikin savaşta kalıp kalıyordu. */
function resolveProxyWars(a, b){
  for (const x of G.emps){
    if (x.dead || x.wild || !x.proxyWar) continue;
    // x, a adına b ile savaşa girmişti mi?
    if (x.proxyWar[b.id] === a.id && x.war[b.id]){
      x.war[b.id] = false; b.war[x.id] = false;
      x.peaceAt = x.peaceAt || {}; b.peaceAt = b.peaceAt || {};
      x.peaceAt[b.id] = G.day; b.peaceAt[x.id] = G.day;
      delete x.proxyWar[b.id];
      if (x.id === 0 || b.id === 0)
        say('Vekil savaş sona erdi — ' + (x.id===0 ? b.name : x.name) + ' ile barış', 'win');
    }
    // x, b adına a ile savaşa girmişti mi?
    if (x.proxyWar[a.id] === b.id && x.war[a.id]){
      x.war[a.id] = false; a.war[x.id] = false;
      x.peaceAt = x.peaceAt || {}; a.peaceAt = a.peaceAt || {};
      x.peaceAt[a.id] = G.day; a.peaceAt[x.id] = G.day;
      delete x.proxyWar[a.id];
      if (x.id === 0 || a.id === 0)
        say('Vekil savaş sona erdi — ' + (x.id===0 ? a.name : x.name) + ' ile barış', 'win');
    }
  }
  warLedgerSync('proxy-peace');
}
function makePeace(a, b, reason=a?.ai?'ai-peace':'agreement', actor=a?.id??null){
  if (!canPeace(a,b)) return false;
  a.war[b.id] = false; b.war[a.id] = false;
  if (a.warDefense) delete a.warDefense[b.id];
  if (b.warDefense) delete b.warDefense[a.id];
  if (a.proxyWar) delete a.proxyWar[b.id];
  if (b.proxyWar) delete b.proxyWar[a.id];
  a.peaceAt = a.peaceAt || {}; b.peaceAt = b.peaceAt || {};
  a.peaceAt[b.id] = G.day; b.peaceAt[a.id] = G.day;
  /* FAZ 18: BAĞIMSIZLIK SAVAŞI BEYAZ BARIŞLA BİTERSE
     vasal özgür kalır ve bir süre yeniden boyunduruk altına
     alınamaz — kazanılmış bağımsızlık kolay geri alınmasın. */
  const bagimsizlik = (a.warCause && a.warCause[b.id] === 'Bağımsızlık Savaşı') ||
                      (b.warCause && b.warCause[a.id] === 'Bağımsızlık Savaşı');
  if (bagimsizlik){
    const isyanci = (a.warCause && a.warCause[b.id] === 'Bağımsızlık Savaşı') ? a : b;
    const eskiLord = (isyanci === a) ? b : a;
    if (isyanci.overlord === eskiLord.id) freeVassal(isyanci, 'barış');
    isyanci.freeUntil = (G.memAge || 0) + 60;      // 5 yıl dokunulmazlık
    if (isyanci.id === 0) say('BAĞIMSIZLIĞIN TANINDI — artık kimsenin vasalı değilsin', 'win');
    else if (eskiLord.id === 0) say(isyanci.name + ' bağımsızlığını kazandı', 'war');
    else say(isyanci.name + ', ' + eskiLord.name + ' boyunduruğundan kurtuldu');
  }
  if (a.warCause) delete a.warCause[b.id];
  if (b.warCause) delete b.warCause[a.id];
  remember(a, b.id, 'barisImzala');
  remember(b, a.id, 'barisImzala');
  warLedgerSync(reason,actor);
  resolveProxyWars(a, b);
  recordNews({category:'peace',empires:[a.id,b.id],key:'peace:'+Math.min(a.id,b.id)+':'+Math.max(a.id,b.id)+':'+G.day,title:'Barış anlaşması',text:a.name+' ile '+b.name+' arasındaki savaş sona erdi',important:true});
  if (typeof facEvent === 'function'){ facEvent(a,'peace'); facEvent(b,'peace'); }
  a.rel[b.id] = Math.max(a.rel[b.id], -10);
  b.rel[a.id] = Math.max(b.rel[a.id], -10);
  if (a.id === G.p?.id || b.id === G.p?.id){
    const rest=G.emps.filter(e=>e!==G.p&&!e.dead&&G.p.war[e.id]).map(e=>e.name);
    say('Barış imzalandı — '+(a===G.p?b.name:a.name)+(rest.length?' · Savaş devam ediyor: '+rest.join(', '):' · Aktif savaş kalmadı'), 'win');
  }
  return true;
}
/* ---------- ELÇİLER — FAZ 86D ----------
   Kıdem yalnız çalışılan aylarda artar. Kaydı yüklemek, menü açmak ve
   teklif hesaplamak elçiyi ilerletmez. Görev değişimi kıdemi sıfırlar. */
const ENVOY_TASKS = Object.freeze({
  yakinlasma: {n:'Yakınlaşma', relation:2.2, bonus:.02, rankBonus:.01,
    kinds:null, scope:'Bütün olumlu teklif maddeleri'},
  ticaret: {n:'Ticari heyet', relation:.9, bonus:.04, rankBonus:.03,
    kinds:['res','tribute','tech','lux','pact'], scope:'Kaynak, haraç, teknoloji, lüks ve ticaret paktı'},
  guvenlik: {n:'Güvenlik teması', relation:.8, bonus:.04, rankBonus:.03,
    kinds:['peace','nap','ally','passage','intel','spynet','warOn','peaceWith'],
    scope:'Barış, saldırmazlık, ittifak, geçiş, istihbarat ve savaş taahhütleri'}
});
function envoyMonth(){
  return Number.isInteger(G.year) && Number.isInteger(G.month) && G.month>=1 && G.month<=12
    ? G.year*12+G.month-1 : Math.floor((G.day||0)/30);
}
function envoyRecord(e,id){
  if (!e || !e.envoy || !Object.prototype.hasOwnProperty.call(e.envoy,id)) return null;
  const r=e.envoy[id], now=envoyMonth();
  if (r===true) return {task:'yakinlasma',months:0,lastMonth:now};
  if (!r || typeof r!=='object' || Array.isArray(r) ||
      !Object.prototype.hasOwnProperty.call(ENVOY_TASKS,r.task)) return null;
  return {task:r.task,
    months:Number.isFinite(r.months)?clamp(Math.floor(r.months),0,Number.MAX_SAFE_INTEGER):0,
    lastMonth:Number.isFinite(r.lastMonth)?Math.min(Math.floor(r.lastMonth),now):now};
}
function envoyPair(e,id){
  const o=G.emps && G.emps[id];
  return Number.isInteger(id) && e && G.emps[e.id]===e && o &&
    e.id!==id && !e.dead && !o.dead && !e.wild && !o.wild &&
    !e.crisisSide && !o.crisisSide ? o : null;
}
function envoyGate(e,id){
  const o=envoyPair(e,id);
  if (!o) return {ok:false,why:'Geçerli bir elçi hedefi yok'};
  if (diploBlocked(e,o)) return {ok:false,why:'Doktrin elçi görevini yasaklıyor'};
  if (!e.contact || !e.contact[id]) return {ok:false,why:'Temas kurulmadı'};
  if ((e.war&&e.war[id]) || (o.war&&o.war[e.id]))
    return {ok:false,why:'Savaş sürüyor'};
  return {ok:true,why:''};
}
function envoyStatus(e,id){
  const r=envoyRecord(e,id), gate=envoyGate(e,id);
  const rank=r ? (r.months>=36?2:r.months>=12?1:0) : 0;
  const task=r ? ENVOY_TASKS[r.task] : null;
  return {record:r,task,rank,rankName:['Yeni','Kıdemli','Uzman'][rank],
    active:!!r&&gate.ok,why:gate.why,
    bonus:task?Math.min(.10,task.bonus+rank*task.rankBonus):0,
    relation:task?task.relation*(1+rank*.1):0};
}
/* Eski v8 true → yeni Yakınlaşma, kıdem 0. Geçmiş aylar uydurulmaz.
   Boolean false / bozuk görev / ölü hedef silinir; savaşta kayıt kalır.
   Alanı olmayan imparatorluklara boş kayıt eklenmez. RNG tüketilmez. */
function normalizeEnvoys(){
  for (const e of G.emps||[]){
    if (!e || !Object.prototype.hasOwnProperty.call(e,'envoy')) continue;
    if (!e.envoy || typeof e.envoy!=='object' || Array.isArray(e.envoy)) {
      e.envoy={}; continue;
    }
    for (const k of Object.keys(e.envoy)){
      const r=envoyRecord(e,k);
      if (String(+k)!==k || !envoyPair(e,+k) || !r) {delete e.envoy[k];continue;}
      if (e.envoy[k]===true) e.envoy[k]=r;
      else Object.assign(e.envoy[k],r);
    }
  }
}
function envoyCap(e){
  let n = 2;
  if (e.mods.dipMul > .25) n++;
  if (e.mods.dipMul > .60) n++;
  if (hasCivic(e,'allyCheap')) n++;
  for (const c of e.colonies){
    const pl = G.sys[c.s].planets[c.p];
    if (pl.col && pl.col.b.arsiv) { n++; break; }
  }
  return n;
}
function envoysUsed(e){
  return Object.keys(e.envoy||{}).filter(k=>String(+k)===k &&
    envoyPair(e,+k) && envoyRecord(e,k)).length;
}
function setEnvoyTask(e,id,task){
  if (!Object.prototype.hasOwnProperty.call(ENVOY_TASKS,task))
    return {ok:false,why:'Bilinmeyen elçi görevi'};
  const gate=envoyGate(e,id);
  if (!gate.ok) return gate;
  const old=envoyRecord(e,id);
  if (old && old.task===task) return {ok:true,changed:false,action:'same'};
  if (!old && envoysUsed(e)>=envoyCap(e))
    return {ok:false,why:'Boşta elçin yok — önce bir elçiyi geri çek'};
  if (!e.envoy || typeof e.envoy!=='object' || Array.isArray(e.envoy)) e.envoy={};
  e.envoy[id]={task,months:0,lastMonth:envoyMonth()};
  return {ok:true,changed:true,action:old?'change':'send'};
}
function recallEnvoy(e,id){
  if (!e || !envoyRecord(e,id)) return {ok:false,why:'Bu devlette elçin yok'};
  delete e.envoy[id];
  return {ok:true,changed:true,action:'recall'};
}
/* Eski çağıranlar için boolean dönüşlü toggle. Yeni UI/AI açık eylemleri kullanır. */
function assignEnvoy(e,id){
  return (envoyRecord(e,id)?recallEnvoy(e,id):setEnvoyTask(e,id,'yakinlasma')).ok;
}
function envoyTick(){
  normalizeEnvoys();
  const now=envoyMonth();
  for (const e of G.emps){
    for (const k of Object.keys(e.envoy||{})){
      const r=e.envoy[k];
      if (r.lastMonth>=now) continue;
      r.lastMonth=now; // duraklanan / atlanan aylar sonradan telafi edilmez
      if (!envoyGate(e,+k).ok) continue;
      r.months=Math.min(Number.MAX_SAFE_INTEGER,r.months+1);
      const o=G.emps[k], status=envoyStatus(e,+k);
      const mevcut=e.rel[o.id]||0;
      const doygun=clamp(1-Math.max(0,mevcut)/55,.05,1);
      const gain=status.relation*(1+e.mods.dipMul)*doygun;
      e.rel[o.id]=clamp(mevcut+gain,-100,100);
      o.rel[e.id]=clamp((o.rel[e.id]||0)+gain*.6,-100,100);
    }
  }
}
/* Saf teklif katkısı. Önceden hesaplanmış olumlu faydalarla ağırlıklandırılır:
   küçücük bir ticaret maddesi tüm güvenlik paketine bonus taşıyamaz.
   İki tarafın elçileri toplanmaz; her maddede uygun en güçlü katkı alınır. */
function envoyDealFactor(ai,other,parts){
  const states=[envoyStatus(ai,other.id),envoyStatus(other,ai.id)].filter(s=>s.active);
  let total=0, extra=0, net=0;
  for (const p of parts||[]){
    net+=p.value;
    if (!(p.value>0)) continue;
    total+=p.value;
    let bonus=0;
    if (p.effective!==false) for (const s of states){
      if (!s.task.kinds || s.task.kinds.includes(p.it.t)) bonus=Math.max(bonus,s.bonus);
    }
    extra+=p.value*bonus;
  }
  return total>0 && net>0 ? clamp(1+extra/total,1,1.10) : 1;
}
/* ortak düşman varsa anlaşmalar çok daha kolay */
function sharedFoe(a, b){
  for (const x of G.emps){
    if (x.dead || x.wild || x.id === a.id || x.id === b.id) continue;
    if (a.war[x.id] && b.war[x.id]) return true;
  }
  return false;
}

/* ticaret anlaşması */
function canPact(a, b){
  return pactAccess(a,b).ok;
}
function pactAccess(a,b){
  if (!a || !b || a===b || a.dead || b.dead) return {ok:false,why:'Geçerli iki devlet gerekli'};
  if (diploBlocked(a,b) || diploBlocked(b,a)) return {ok:false,why:'Doktrin ticareti yasaklıyor'};
  if (a.war[b.id] || b.war[a.id]) return {ok:false,why:'Savaş sürüyor'};
  // tradeBlocked owns Council sanctions, bilateral embargoes and smuggling exceptions.
  if (tradeBlocked(a,b)) return {ok:false,why:'Ticaret yaptırımı / ambargo yürürlükte'};
  return {ok:true};
}
function makePact(a, b){
  if (!canPact(a,b)) return false;
  a.pact = a.pact || {}; b.pact = b.pact || {};
  recordNews({category:'economy',empires:[a.id,b.id],title:'Ticaret anlaşması',text:a.name+' ile '+b.name+' ticaret anlaşması imzaladı'});
  a.pact[b.id] = true; b.pact[a.id] = true;
  a.rel[b.id] = clamp(a.rel[b.id] + 15, -100, 100);
  b.rel[a.id] = clamp(b.rel[a.id] + 15, -100, 100);
  return true;
}
function breakPact(a, b){
  if (a.pact) a.pact[b.id] = false;
  if (b.pact) b.pact[a.id] = false;
}
/* 86G: Savaş ile aynı anda yürüyemeyen ikili antlaşmaların tek kapanış
   noktası. NAP süre alanı silinmezse UI aynı çifti hem savaşta hem NAP'ta
   gösteriyor, barıştan sonra eski söz yeniden canlanıyor ve yeni teklif
   yanlışlıkla redundant sayılıyordu. */
function endTreatiesForWar(a, b){
  if (!a || !b) return;
  if (a.nap) delete a.nap[b.id];
  if (b.nap) delete b.nap[a.id];
  breakPact(a, b);
  if (a.ally) a.ally[b.id] = false;
  if (b.ally) b.ally[a.id] = false;
  for(const key of ['visionFrom','shareVis','spynet','passage']){
    if(a[key])delete a[key][b.id];if(b[key])delete b[key][a.id];
  }
}
/* Eski v8 kayıtlarındaki savaş+antlaşma çakışmasını ay ilerletmeden,
   bildirim üretmeden ve RNG tüketmeden onarır. Savaş kaydı korunur. */
function normalizeWarTreaties(){
  const out={pairs:0,nap:0,pact:0,ally:0};
  if (!G || !Array.isArray(G.emps)) return out;
  for (let i=0;i<G.emps.length;i++) for (let j=i+1;j<G.emps.length;j++){
    const a=G.emps[i],b=G.emps[j];
    if (!a || !b || !((a.war&&a.war[b.id])||(b.war&&b.war[a.id]))) continue;
    const hadNap=!!((a.nap&&Object.prototype.hasOwnProperty.call(a.nap,b.id))||
                    (b.nap&&Object.prototype.hasOwnProperty.call(b.nap,a.id)));
    const hadPact=!!((a.pact&&a.pact[b.id])||(b.pact&&b.pact[a.id]));
    const hadAlly=!!((a.ally&&a.ally[b.id])||(b.ally&&b.ally[a.id]));
    const hadSensors=!!(a.visionFrom?.[b.id]||b.visionFrom?.[a.id]||a.shareVis?.[b.id]||b.shareVis?.[a.id]);
    if (!(hadNap||hadPact||hadAlly||hadSensors)) continue;
    out.pairs++;if(hadNap)out.nap++;if(hadPact)out.pact++;if(hadAlly)out.ally++;
    endTreatiesForWar(a,b);
  }
  return out;
}
/* =====================================================================
   MÜZAKERE MASASI — teklif / değerlendirme / karşı teklif
   ===================================================================== */

/* Masaya konabilecek öğe türleri. Her biri iki tarafa da konabilir. */
const DEAL_KINDS = {
  freight:{n:'Kaynak Kargo Sözleşmesi',ico:'▱'},
  res    :{n:'Kaynak',            ico:'◆'},
  tribute:{n:'Aylık Ödeme (10 yıl)',ico:'⏳'},
  sys    :{n:'Yıldız Sistemi',    ico:'★'},
  tech   :{n:'Teknoloji',         ico:'✦'},
  lux    :{n:'Lüks Mal Erişimi',  ico:'❖'},
  peace  :{n:'Barış',             ico:'🕊'},
  nap    :{n:'Saldırmazlık Paktı',ico:'🛡'},
  pact   :{n:'Ticaret Anlaşması', ico:'🤝'},
  ally   :{n:'İttifak',           ico:'⚑'},
  warOn  :{n:'Üçüncü Tarafa Savaş',ico:'⚔'},
  warJoin:{n:'Belirli Savaşa Destek',ico:'⚔'},
  peaceWith:{n:'Üçüncü Tarafla Barış',ico:'🤲'},
  /* FAZ 86C.1: `intel` TEK YÖNLÜdür — veren tarafın sensör verisini
     alıcıya açar. Simetrik ortak casus ağı `spynet`tir. */
  intel  :{n:'Sensör Verisi Paylaşımı', ico:'👁',
           d:'Tek yönlü: sensör verisi paylaşılır (ortak casus ağı değildir)'},
  spynet :{n:'Casusluk Ağı Paktı',  ico:'🕸'},
  passage:{n:'Sınır Geçiş İzni',ico:'🚪'}
};

function dealLabel(it){
  switch(it.t){
    case 'res':     return RES[it.r].ico + ' ' + it.v + ' ' + RES[it.r].n;
    case 'freight': return '▱ '+it.v+' '+RES[it.r].n+'/sefer · '+(G.sys[it.source]?.name||'?')+' → '+(G.sys[it.target]?.name||'?')+' · '+it.every+' günde / '+it.months+' ay';
    case 'tribute': return '⏳ ' + it.v + ' ' + RES[it.r].n + '/ay · 10 yıl';
    case 'sys':     return '★ ' + (G.sys[it.id] ? G.sys[it.id].name : '?') + ' sistemi';
    case 'tech':    return '✦ ' + (TECHS[it.id] ? TECHS[it.id].n : '?');
    case 'lux':     return (LUXURY[it.k] ? LUXURY[it.k].ico + ' ' + LUXURY[it.k].n : '❖') + ' erişimi';
    case 'peace':   return '🕊 Barış';
    case 'nap':     return '🛡 Saldırmazlık paktı';
    case 'pact':    return '🤝 Ticaret anlaşması';
    case 'ally':    return '⚑ İttifak';
    case 'warJoin': return '⚔ '+(it.plan?'Hazırlık #'+it.plan:'Cephe #'+it.front)+' · '+(G.emps[it.target]?.name||'Bilinmeyen devlet')+' karşısında destek';
    case 'warOn':   return '⚔ ' + (G.emps[it.target] ? G.emps[it.target].name : '?') + '\'a savaş ilanı';
    case 'peaceWith': return '🤲 ' + (G.emps[it.target] ? G.emps[it.target].name : '?') + ' ile barış';
    case 'intel':   return '👁 Sensör anlaşması';
    case 'spynet':  return '🕸 Casusluk ağı paktı';
    case 'passage': return '🚪 Sınır geçiş izni';
  }
  return '?';
}

/* --------------------------------------------------------------------
   DEĞERLENDİRME — bir öğe "alan" taraf için ne kadar kıymetli?
   Değerler kabaca "etki puanı" biriminde tutulur.
   -------------------------------------------------------------------- */
function itemValue(e, it, other){
  const need = k => {
    // kaynağı ne kadar acil istiyor? (stok ve gelir düşükse kıymetli)
    const stock = e.res[k] || 0, inc = (e.inc && e.inc[k]) || 0;
    let m = 1;
    if (stock < 300) m += .6;
    if (inc < 0) m += .8;
    else if (inc < 5) m += .3;
    return m;
  };
  switch(it.t){
    case 'res':     return it.v * .38 * need(it.r);
    case 'freight': return it.v*.38*need(it.r)*Math.min(24,it.months*30/it.every);
    case 'tribute': return it.v * 16 * need(it.r);         // 10 yıllık akış
    case 'sys': {
      const sy = G.sys[it.id];
      if (!sy) return 0;
      let v = 55;
      for (const p of sy.planets){
        if (p.col) v += 45 + p.col.pop * 4;
        if (p.lux) v += 60;
        if (habOf(e, p) >= 50) v += 25;
      }
      // kendi sınırına yakınsa daha kıymetli
      if (claimOf(sy) === e.id) v *= 1.4;
      return v;
    }
    case 'tech': {
      const t = TECHS[it.id];
      if (!t || e.techs[it.id] || !researchAccess(e,it.id).ok) return 0;
      const ready = (t.r||[]).every(r => e.techs[r]);
      return (t.c * .07) * (ready ? 1 : .45);
    }
    case 'lux': {
      if (!LUXURY[it.k]) return 0;
      return (e.luxury && e.luxury[it.k]) ? 8 : 95;
    }
    case 'peace': {
      if (!e.war[other.id]) return 0;
      const ratio = totalPower(e) / (totalPower(other) + 1);
      let v = clamp(240 / Math.max(.35, ratio), 40, 700);
      // savaş yorgunluğu barışı çok daha kıymetli yapar
      if (typeof exhOf === 'function') v += exhOf(e, other.id) * 4.5;
      // karşı taraf savaş hedefine ulaştıysa barış onun için ucuzlar
      if (typeof warLeverage === 'function') v = Math.max(20, v - warLeverage(other, e.id) * .6);
      return v;
    }
    case 'nap':   return e.war[other.id] ? 0 : 60 + (e.rel[other.id] < 0 ? 40 : 0);
    case 'pact': {
      if (e.pact && e.pact[other.id]) return 0;
      const theirLux = ownLuxury(other);
      let v = 55;
      for (const k in theirLux) if (!(e.luxOwn && e.luxOwn[k])) v += 45;
      return v;
    }
    case 'ally': {
      if (e.ally[other.id]) return 0;
      const rel = e.rel[other.id];
      let v = 40 + rel * 1.6;
      if (sharedFoe(e, other)) v += 160;
      if (RACES[e.race].dip <= .05) v = -120;      // kovan ittifakı sevmez
      return v;
    }
    case 'warJoin': return ColonyInfo.read(()=>{
      const enemy=G.emps[it.target],p=it.plan&&warPreparation(it.plan),receiving=!!e.war[it.target]||p?.owner===e.id;
      if(!enemy)return 0;
      if(receiving)return clamp(80+aiKnownPower(e,other)/Math.max(1,aiKnownPower(e,e))*120,80,320);
      const risk=aiKnownPower(e,enemy)/Math.max(1,aiKnownPower(e,e)+aiKnownPower(e,other));
      return clamp((140+risk*100+(e.exh?.[it.target]||0)+Object.values(e.war||{}).filter(Boolean).length*25)*(e.mizac==='militarist'?.85:e.mizac==='pasifist'?1.3:e.mizac==='tuccar'?1.15:1),60,600);
    });
    case 'warOn': {
      const tgt = G.emps[it.target];
      if (!tgt || tgt.dead || e.war[tgt.id]) return 0;
      // düşmanına saldıracaksa değerli, dostuna saldıracaksa maliyet
      let v = -140;
      if (e.rel[tgt.id] < -40) v = 90;
      if (e.ally[tgt.id]) v = -400;
      return v;
    }
    case 'peaceWith': {
      const t = G.emps[it.target];
      if (!t || t.dead || !e.war[t.id]) return 0;
      const ratio = totalPower(e) / (totalPower(t) + 1);
      // kaybediyorsa barış kıymetli, kazanıyorsa fedakârlık
      return ratio < 1 ? clamp(180 / Math.max(.35, ratio), 40, 500) : -90 * (ratio - 1);
    }
    case 'passage': {
      // sınırını açmak risklidir: güçlü komşuya izin vermek pahalı
      if (e.passage && e.passage[other.id]) return 0;
      const ratio = totalPower(other) / (totalPower(e) + 1);
      return -60 * clamp(ratio, .4, 2.5);
    }
    case 'intel': return 45;
    case 'spynet': return 120;      // FAZ 66: çok daha değerli
  }
  return 0;
}

/* teklifin AI gözünden net değeri */
/* ═══════════════════════════════════════════════════════════════════
   FAZ 86C — GÖREV F: AÇIKLANABİLİR DEĞERLEME

   ÖLÇÜLEN ESKİ evalOffer: yalnız ham ilişki (rel/220) ve aiProfile
   (dip/war) kullanıyordu; sınırsızdı ve gerekçe üretmiyordu.
   ARTIK bütün yumuşak faktörler AYRI hesaplanır, her biri kendi
   cap'iyle sınırlanır ve kısa gerekçe döner. Karar DETERMİNİSTİK —
   kabul/ret için RNG YOKTUR. FAZ 86D: elçi katkısı yalnız uygun
   olumlu maddelerin değeri oranında eklenir ve en fazla +%10'dur. */
const DEAL_FACTOR_CAPS = {
  rel:      [0.80, 1.20],   // mevcut ilişki
  trust:    [0.85, 1.15],   // güven + önemli diplomatik hafıza
  ethic:    [0.90, 1.10],   // etik/ideoloji uyumu (normalleştirilmiş)
  honor:    [0.92, 1.08],   // onur/itibar
  persona:  [0.90, 1.10],   // kişilik/doktrin/stratejik ihtiyaç
  foe:      [1.00, 1.15],   // ortak düşman — YALNIZ güvenlik maddeleri
  envoy:    [1.00, 1.10],   // görev + kıdem; uygun olumlu maddelerde
  gainTot:  [0.60, 1.55],   // toplam fayda çarpanı
  costTot:  [0.85, 1.20]    // toplam çekince çarpanı
};
const DEAL_SECURITY_KINDS = ['peace','nap','ally','intel','spynet','warOn','warJoin','peaceWith'];
function _cap(v, k){
  const c = DEAL_FACTOR_CAPS[k];
  return clamp(v, c[0], c[1]);
}
/* Normalleştirilmiş etik farkı: 0 (aynı) … 1 (tam zıt). */
function ethicGap(a, b){
  const eks = ['mil','aut','mat','ahl'];
  let t = 0;
  for (const k of eks) t += Math.abs((a.ethics[k] || 0) - (b.ethics[k] || 0));
  return clamp(t / (eks.length * 6), 0, 1);   // her eksen −3..+3
}
/* Saf faktör hesabı — RNG yok, mutasyon yok. */
function dealFactors(ai, other, n, gainParts){
  const f = {}, why = [];
  const rel = ai.rel[other.id] || 0;
  f.rel = _cap(1 + rel / 500, 'rel');
  if (rel <= -40) why.push('İlişki düşmanca');
  else if (rel >= 40) why.push('İlişki dostane');

  const tr = (typeof trustOf === 'function') ? trustOf(ai, other.id) : 50;
  f.trust = _cap(1 + (tr - 50) / 340, 'trust');
  if (tr <= 30) why.push('Geçmiş ihlaller ağır basıyor');
  else if (tr >= 70) why.push('Güven yüksek');

  const gap = ethicGap(ai, other);
  f.ethic = _cap(1.10 - gap * 0.20, 'ethic');
  if (gap >= 0.55) why.push('İdeolojik güvensizlik');

  const hn = (typeof honorOf === 'function') ? honorOf(other) : 0;
  f.honor = _cap(1 + hn / 1250, 'honor');
  if (hn <= -30) why.push('Karşı tarafın itibarı kötü');

  const prof = ai.ai ? aiProfile(ai) : {dip:.5, war:.5};
  f.persona = _cap(1 + (prof.dip - .5) * 0.20 + (typeof aiStrategicDiplomacyBias==='function'?aiStrategicDiplomacyBias(ai,other,n):0), 'persona');
  f.greed   = _cap(1 + (prof.war - .5) * 0.20, 'costTot');

  /* Ortak düşman YALNIZ güvenlik maddelerinde ve en fazla +%15. */
  const guvenlikVar = n.give.concat(n.want).some(it =>
    DEAL_SECURITY_KINDS.indexOf(it.t) >= 0);
  const ortak = (typeof sharedFoe === 'function') && sharedFoe(ai, other);
  f.foe = (guvenlikVar && ortak) ? _cap(1.15, 'foe') : 1;
  if (f.foe > 1) why.push('Ortak tehdit güvenlik anlaşmasını değerli kılıyor');

  f.envoy = _cap(envoyDealFactor(ai,other,gainParts), 'envoy');
  if (f.envoy>1) why.push('Elçi görüşmeleri uygun faydayı +%' +
    ((f.envoy-1)*100).toFixed(1) + ' destekliyor');
  return {f, why, rel, trust:tr, ethicGap:gap, honor:hn, sharedFoe:!!ortak};
}
function evalOffer(ai, offer){
  /* Sert kilit: Arındırıcı masaya oturmaz — para ile aşılamaz. */
  if (typeof diploBlocked === 'function'){
    const kars = offer && offer.from !== undefined ? G.emps[offer.from] : null;
    if (diploBlocked(ai, kars))
      return {net: -9999, red: true, hardLock: true,
              why: ['Doktrin bu devletle anlaşmayı yasaklıyor']};
  }
  const other = G.emps[offer.from];
  if (!other) return {net: -9999, red: true, hardLock: true, why: ['Taraf yok']};
  const n = (typeof normalizeDeal === 'function')
            ? normalizeDeal(offer) : {give: offer.give || [], want: offer.want || []};
  if (n.errors && n.errors.length)
    return {net: -9999, red: true, hardLock: true, why: n.errors.slice(0, 2)};

  let gain = 0, cost = 0;
  const gainParts=[];
  for (const it of n.give){
    const value=itemValue(ai,it,other);
    gain+=value;
    gainParts.push({it,value,effective:!n.effectiveGive||n.effectiveGive.includes(it)});
  }
  for (const it of n.want) cost += itemValue(ai, it, other);

  const F = dealFactors(ai, other, n, gainParts);
  const f = F.f;
  /* Faktörler ÇARPILIR ama toplam iki uçta clamp'lenir — tek bir
     faktör aşırı uç üretemez, aynı bilgi iki kez sayılmaz. */
  const gainMul = _cap(f.rel * f.trust * f.ethic * f.honor * f.persona *
                       f.foe * f.envoy, 'gainTot');
  const costMul = _cap(f.greed, 'costTot');
  const G2 = gain * gainMul, C2 = cost * costMul;
  return {gain: G2, cost: C2, net: G2 - C2,
          rawGain: gain, rawCost: cost,
          factors: f, gainMul, costMul, why: F.why,
          rel: F.rel, trust: F.trust, ethicGap: F.ethicGap,
          honor: F.honor, sharedFoe: F.sharedFoe, hardLock: false};
}

/* teklifin uygulanabilirliği — taraflar sözünü tutabiliyor mu? */
/* --------------------------------------------------------------------
   UYGULAMA — anlaşma kabul edilince maddeleri yürürlüğe koy
   -------------------------------------------------------------------- */
function applyItems(giver, taker, items){
  /* FAZ 86C: hata enjeksiyonu kancası — üretimde tanımsız, yalnız
     atomiklik testleri bunu geçici olarak atar. */
  for (const it of items){
    /* FAZ 86C.2: aşamalı kanca — `before:<tür>` mutasyondan ÖNCE. */
    if (typeof G._dealFailInject === 'function') G._dealFailInject('before:' + it.t);
    switch(it.t){
      case 'freight': break; // Commerce.sign created the paired obligation atomically.
      case 'res':
        giver.res[it.r] = Math.max(0, (giver.res[it.r]||0) - it.v);
        taker.res[it.r] = (taker.res[it.r]||0) + it.v;
        break;
      case 'tribute':
        giver.tribute = giver.tribute || [];
        taker.tribute = taker.tribute || [];
        giver.tribute.push({to: taker.id, r: it.r, v: it.v, until: G.day + 3600});
        break;
      case 'sys': {
        const sy = G.sys[it.id];
        if (sy && sy.owner === giver.id) captureSystem(sy, taker.id, 'transfer');
        break;
      }
      case 'tech':
        if (giver.techs[it.id]){
          grantResearchTech(taker,it.id,'trade'); recalcMods(taker);
          remember(taker, giver.id, 'teknolojiVer');
        }
        break;
      case 'lux':
        taker.luxGrant = taker.luxGrant || {};
        taker.luxGrant[it.k] = giver.id;
        break;
      case 'peace': if(giver.war[taker.id]||taker.war[giver.id])makePeace(giver, taker); break;
      case 'nap':
        giver.nap = giver.nap || {}; taker.nap = taker.nap || {};
        giver.nap[taker.id] = G.day + 3600; taker.nap[giver.id] = G.day + 3600;
        break;
      case 'pact':
        makePact(giver, taker);
        remember(taker, giver.id, 'ticaretActi');
        remember(giver, taker.id, 'ticaretActi');
        break;
      case 'ally':
        // ittifak savaşı sona erdirir — aksi hâlde müttefikler savaşta kalıyordu
        if (giver.war[taker.id] || taker.war[giver.id]){
          makePeace(giver, taker);
        }
        recordNews({category:'politics',empires:[giver.id,taker.id],title:'İttifak kuruldu',text:giver.name+' ile '+taker.name+' ittifak imzaladı'});
        giver.ally[taker.id] = true; taker.ally[giver.id] = true;
        clearBilateralEmbargo(giver,taker);
        warLedgerSync('alliance',giver.id);
        giver.rel[taker.id] = Math.max(giver.rel[taker.id], 55);
        taker.rel[giver.id] = Math.max(taker.rel[giver.id], 55);
        break;
      case 'warJoin': {
        const gate=warSupportGate(giver,taker,it);if(!gate.ok)throw Error(gate.why);
        const enemy=G.emps[it.target];
        if(!declareWar(giver,enemy,{sponsor:taker.id,enemy:enemy.id,kind:'promise'}))throw Error('Katılım reddedildi');
        giver.proxyWar=giver.proxyWar||{};giver.proxyWar[enemy.id]=taker.id;
        const source=(G.warLedger.fronts||[]).find(f=>f.id===it.front);if(source)source.coalition=true;
        break;
      }
      case 'warOn': {
        const t = G.emps[it.target];
        if (t && !t.dead && declareWar(giver, t, {sponsor:taker.id, enemy:t.id, kind:'promise'})){
          // bu savaş "taker adına" açıldı: taker barışırsa bu da biter
          giver.proxyWar = giver.proxyWar || {};
          giver.proxyWar[t.id] = taker.id;
        }
        break;
      }
      case 'peaceWith': {
        const t = G.emps[it.target];
        if (t && !t.dead && giver.war[t.id]) makePeace(giver, t);
        break;
      }
      /* ═══ FAZ 66: CASUSLUK AĞI PAKTI ═══
         Sensör anlaşmasından farkı: taraflar ÜÇÜNCÜ devletler
         üzerindeki istihbarat seviyelerini havuzda birleştirir.
         Ortağın bir devlette 3. seviye ağı varsa sen de o
         devleti 3. seviyeden görürsün. Yüksek ilişki ister,
         120 etkiye mal olur ve karşılıklıdır. */
      case 'spynet':
        taker.spynet = taker.spynet || {};
        giver.spynet = giver.spynet || {};
        taker.spynet[giver.id] = true;
        giver.spynet[taker.id] = true;
        if (typeof say === 'function' && (taker.id === 0 || giver.id === 0))
          say('🕸 Casusluk ağı paktı — ortağın bildiği her şeyi artık sen de biliyorsun', 'sci');
        break;

      case 'intel':
        taker.intel = taker.intel || {};
        taker.intel[giver.id] = Math.max(taker.intel[giver.id] || 0, 2);
        /* ═══ FAZ 48: PAYLAŞILAN GÖRÜŞ (SHARED VISION) ═══
           Pakt kalıcı bir bağ kurar: veren tarafın keşifleri ve
           görüş alanı her ay alıcıya kopyalanır (visionTick).
           Anında bir kez de uygulanır ki oyuncu farkı görsün. */
        taker.visionFrom = taker.visionFrom || {};
        taker.visionFrom[giver.id] = true;
        if (typeof shareVision === 'function') shareVision(giver, taker);
        break;
      case 'passage':
        // veren taraf kendi sınırını alana açar
        giver.passage = giver.passage || {};
        giver.passage[taker.id] = true;
        break;
    }
    /* FAZ 86C.2: `after:<tür>` madde POSTCONDITION'ı gerçekleştikten
       SONRA çağrılır — kanca içinde DEĞİŞMİŞ durum görülebilir. */
    if (!dealPostcondition(giver, taker, it))
      throw new Error('postcondition başarısız: ' + it.t);
    if (typeof G._dealFailInject === 'function') G._dealFailInject('after:' + it.t);
  }
}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 86B — KANONİK VE ATOMİK ANLAŞMA MOTORU

   ÖN DENETİMDE GERÇEK ÜRETİM YOLUYLA KANITLANAN İSTİSMARLAR:
   1) KAYNAK ÇOĞALTMA: canDeliver satırları AYRI AYRI sınıyordu.
      1000 mineral stok + iki adet 800'lük satır → ikisi de geçti,
      executeDeal başarılı oldu, toplam 1500 → 2100 (600 mineral
      yoktan yaratıldı).
   2) BOŞ ANLAŞMA: give:[] want:[] → executeDeal true ve +6 ilişki.
      10 tekrar → +66 ilişki, sıfır maddeyle.
   3) ANTLAŞMA TEKRARI: yürürlükteki NAP üç kez imzalandı,
      ilişki 6 → 12 → 18. Süre uzamıyor ama ilişki sınırsız kasılıyor.
   4) spynet: 0 UI üreticisi + 0 AI üreticisi → tamamen erişilemez.
   5) canDeliver'da case'i OLMAYAN türler (hep "teslim edilebilir"):
      nap · lux · intel · spynet · passage.

   ÇÖZÜM: tek kanonik hat —
     normalizeDeal → dealValidity → dealQuote → executeDeal
   Her aşama SAF (RNG tüketmez, oyun durumu değiştirmez); yalnız
   executeDeal yazar ve o da ancak tam doğrulamadan sonra.
   ═══════════════════════════════════════════════════════════════════ */

/* ── KANONİK İMZALAMA MALİYET TABLOSU ──
   ÖLÇÜLEN ESKİ MALİYETLER (dağınık ve tutarsızdı):
     diploAct peace  : 30  (zar ATILMADAN ÖNCE kesiliyordu → ret'te kayıp)
     diploAct pact   : 40  (aynı sorun)
     diploAct ally   : 90 / 55 (allyCheap) · sharedFoe ×0.5 (aynı sorun)
     pactOpen intel  : 45  (AI teklifini KABUL EDEN oyuncudan kesiliyordu)
     pactOpen spynet : 120 (aynı)
     nap/passage     : maliyetsiz (oyuncu yolu zaten yoktu)
   YENİ POLİTİKA: maliyet YALNIZ başarılı imzada, YALNIZ teklifi
   GÖNDEREN taraftan, TAM BİR KEZ kesilir. Çok maddeli teklifte
   antlaşma maddelerinin maliyeti TOPLANIR (kaynak/sistem/teknoloji
   gibi maddi maddeler ek maliyet doğurmaz). */
const DEAL_TREATY_COST = {
  peace:30, pact:40, ally:90, intel:45, spynet:120,
  nap:0, passage:0, warOn:0, peaceWith:0
};
function dealItemCost(sender, other, it){
  let c = DEAL_TREATY_COST[it.t];
  if (c === undefined) return 0;
  if (it.t === 'ally'){
    if (typeof hasCivic === 'function' && hasCivic(sender,'allyCheap')) c = 55;
    if (typeof sharedFoe === 'function' && other && sharedFoe(sender, other))
      c = Math.round(c * .5);
  }
  return c;
}
/* Teklifin toplam Etki maliyeti — GÖNDEREN öder. */
function dealCost(offer){
  /* ═══ FAZ 86C — GÖREV D: ÇOKLU ANTLAŞMA MALİYET POLİTİKASI ═══
     Tabanlar korundu (peace 30 · pact 40 · ally 90 · intel 45 ·
     spynet 120 · nap/passage/warOn/peaceWith 0). allyCheap ve
     sharedFoe indirimleri ÖNCE her maddeye uygulanır.
     Fiyatlama: EN PAHALI benzersiz ücret tam, diğerlerinin %25'i.
     Aynı antlaşmanın iki yönde bulunması ikinci ücret doğurmaz.
     Tavan 160 Etki. Round yalnız EN SONDA bir kez. */
  const a = G.emps[offer.from], b = G.emps[offer.to];
  if (!a || !b) return 0;
  /* FAZ 86C.1: maliyet YALNIZ effective plan üzerinden — redundant
     antlaşma ücretlendirilmez. Ham teklif geldiyse normalize edilir. */
  const nn = (offer.effectiveGive || offer.effectiveWant)
             ? offer : normalizeDeal(offer);
  const kalemler = (nn.effectiveGive || []).concat(nn.effectiveWant || []);
  const gorulen = {};
  const ucretler = [];
  for (const it of kalemler){
    if (!it || gorulen[it.t]) continue;
    gorulen[it.t] = true;
    const c = dealItemCost(a, b, it);
    if (c > 0) ucretler.push(c);
  }
  if (!ucretler.length) return 0;
  ucretler.sort((x, y) => y - x);
  let t = ucretler[0];
  for (let k = 1; k < ucretler.length; k++) t += ucretler[k] * 0.25;
  return Math.min(160, Math.round(t*(hasCivic(a,'shadow')?.70:1)));
}

/* Simetrik antlaşmalar: iki tarafı da bağlar, teklifte TEK madde olur. */
const DEAL_SYMMETRIC = ['peace','nap','pact','ally','spynet'];
/* Tek yönlü maddeler: yön metni gerekir. */
const DEAL_DIRECTED  = ['res','tribute','sys','tech','lux','intel','passage',
                        'warOn','peaceWith'];
// Numeric safety ceiling; actual offers are additionally bounded by stock / capacity.
const DEAL_AMOUNT_LIMIT = 1000000000;
function dealMonthlyCapacity(e,r,stock=e.res[r]||0){
  const promised=(e.tribute||[]).filter(t=>t.r===r&&t.until>=G.day&&G.emps[t.to]&&!G.emps[t.to].dead)
    .reduce((n,t)=>n+Math.max(0,t.v||0),0);
  // Preserve the existing half-income OR 24-month-reserve rule, including live obligations.
  return Math.max(0,Math.min(DEAL_AMOUNT_LIMIT,Math.max(0,(e.inc?.[r]||0)*2,stock/24)-promised));
}

/* Bir maddenin kimliği — tekilleştirme anahtarı. */
function dealItemKey(it){
  if (!it || !it.t) return null;
  switch(it.t){
    case 'freight': return it.t+':'+it.r+':'+it.source+':'+it.target;
    case 'res': case 'tribute': return it.t + ':' + it.r;
    case 'sys': case 'tech':    return it.t + ':' + it.id;
    case 'lux':                 return it.t + ':' + it.k;
    case 'warJoin': return it.t+':'+(it.plan?'plan'+it.plan:it.front)+':'+it.target;
    case 'warOn': case 'peaceWith': return it.t + ':' + it.target;
    default:                    return it.t;
  }
}

/* ── 1) NORMALİZE (SAF) ──
   · Aynı kaynağın/haracın birden çok satırı TOPLANIR.
   · Aynı sistem/teknoloji/lüks/hedefli madde TEKİLLEŞTİRİLİR.
   · Simetrik antlaşma her iki listede de varsa TEK kanonik maddeye
     indirilir (give tarafında tutulur).
   · Bilinmeyen tür veya bozuk madde DÜŞÜRÜLÜR (gizlice geçerli
     hâle getirilmez — düşenler `dropped` ile raporlanır).
   Giriş nesnesi DEĞİŞTİRİLMEZ; yeni nesne döner. */
/* ═══════════════════════════════════════════════════════════════════
   FAZ 86C — GÖREV A: NORMALLEŞTİRME GEÇERSİZ TEKLİFİ KURTARMAZ

   ÖLÇÜLEN ZAFİYET (86B): bilinmeyen madde türü, eksik alan ve geçersiz
   miktar `dropped` listesine yazılıp SESSİZCE ATILIYOR, teklifin geri
   kalanı uygulanıyordu. Yani "geçerli ödül + geçersiz yükümlülük"
   paketinde ödül aktarılıp yükümlülük düşüyordu.

   ARTIK üç ayrı sınıf döner:
     normalizations : anlamı KORUYAN güvenli dönüşümler
     redundant      : zaten yürürlükte / yeni etkisi olmayan maddeler
     errors         : teklifin TAMAMINI geçersiz yapan FATAL hatalar
   Tek bir fatal hata varsa teklif bütünüyle reddedilir. */
function normalizeDeal(offer){
  const normalizations = [], redundant = [], errors = [];
  const bitir = () => ({from:null, to:null, give:[], want:[],
                        normalizations, redundant, errors,
                        dropped:errors.concat(normalizations)});
  if (!offer || typeof offer !== 'object'){
    errors.push('Teklif nesnesi yok'); return bitir();
  }
  /* ── TARAF DOĞRULAMASI ── */
  const fa = Number(offer.from), fb = Number(offer.to);
  if (!isFinite(fa) || !isFinite(fb) || !Number.isInteger(fa) || !Number.isInteger(fb)){
    errors.push('Taraf kimliği sayı değil'); return bitir();
  }
  if (fa === fb){ errors.push('Bir devlet kendisiyle anlaşma yapamaz'); return bitir(); }
  const A = G.emps[fa], B = G.emps[fb];
  if (!A || !B){ errors.push('Taraflardan biri bulunamadı'); return bitir(); }
  if (A.dead || B.dead){ errors.push('Ölü devletle anlaşma yapılamaz'); return bitir(); }
  if (A.wild || B.wild){ errors.push('Korsanlarla müzakere edilemez'); return bitir(); }
  if (A.crisisSide || B.crisisSide){
    errors.push('Kriz tarafıyla müzakere edilemez'); return bitir(); }
  if (!A.contact[B.id] || !B.contact[A.id]){
    errors.push('Taraflar arasında temas yok'); return bitir(); }
  /* Mevcut sert engeller (doktrin/purifier) kanonikleştirildi. */
  if (typeof diploBlocked === 'function' &&
      (diploBlocked(A, B) || diploBlocked(B, A))){
    errors.push('Doktrin bu devletle her türlü anlaşmayı yasaklıyor');
    return bitir();
  }

  const norm = (liste, taraf) => {
    const out = [], idx = {};
    for (const raw of (Array.isArray(liste) ? liste : [])){
      if (!raw || typeof raw !== 'object'){
        errors.push('Madde nesnesi bozuk'); continue; }
      if (!DEAL_KINDS[raw.t]){
        errors.push('Bilinmeyen madde türü: ' + String(raw.t)); continue; }
      const it = {t: raw.t};
      if(it.t==='warJoin'){const key=raw.plan!==undefined?'plan':'front';if(raw.plan!==undefined&&raw.front!==undefined||!Number.isSafeInteger(raw[key])||raw[key]<1||!Number.isSafeInteger(raw.target)){errors.push('Geçersiz savaş katılım kimliği');continue;}it[key]=raw[key];}
      if(it.t==='freight')for(const k of ['source','target','every','months'])it[k]=raw[k];
      if (raw.r !== undefined) it.r = raw.r;
      if (raw.k !== undefined) it.k = raw.k;
      if (raw.id !== undefined) it.id = raw.id;
      if (raw.target !== undefined) it.target = raw.target;
      if (raw.v !== undefined){
        const v = Number(raw.v);
        if (!isFinite(v) || v <= 0 || v > DEAL_AMOUNT_LIMIT){
          errors.push(raw.t + ': geçersiz miktar (' + String(raw.v) + ')'); continue; }
        it.v = v;
      }
      /* ── ZORUNLU ALAN + KATALOG DOĞRULAMASI (gerçek kataloglar) ── */
      if (it.t === 'res' || it.t === 'tribute' || it.t==='freight'){
        if (it.v === undefined || !it.r){
          errors.push(it.t + ': eksik kaynak veya miktar'); continue; }
        if (!Object.hasOwn(RES,it.r)){
          errors.push(it.t + ': bilinmeyen kaynak "' + String(it.r) + '"'); continue; }
      }
      if (it.t === 'sys'){
        const sy = (it.id !== undefined) ? G.sys[it.id] : null;
        if (!sy){ errors.push('sys: geçersiz sistem kimliği'); continue; }
      }
      if (it.t === 'tech'){
        if (it.id === undefined || !TECHS[it.id]){
          errors.push('tech: katalogda olmayan teknoloji'); continue; }
      }
      if (it.t === 'lux'){
        if (!it.k || (typeof LUXURY !== 'undefined' && !LUXURY[it.k])){
          errors.push('lux: katalogda olmayan lüks mal'); continue; }
      }
      if (it.t === 'warOn' || it.t === 'peaceWith'){
        const t = (it.target !== undefined) ? G.emps[it.target] : null;
        if (!t || t.dead){ errors.push(it.t + ': geçersiz hedef devlet'); continue; }
        if (t.id === taraf.id){
          errors.push(it.t + ': taraf kendini hedef alamaz'); continue; }
      }
      const key = dealItemKey(it);
      if (idx[key] !== undefined){
        if (it.t === 'res' || it.t === 'tribute'){
          /* GÜVENLİ NORMALLEŞTİRME: aynı kaynağın satırları toplanır. */
          out[idx[key]].v += it.v;
          if(out[idx[key]].v>DEAL_AMOUNT_LIMIT)errors.push(it.t+': toplam miktar güvenli sınırı aşıyor');
          normalizations.push(it.t + '/' + it.r + ': satırlar toplandı');
        } else {
          normalizations.push((DEAL_KINDS[it.t] ? DEAL_KINDS[it.t].n : it.t) +
                              ': yinelenen madde tek maddeye indirildi');
        }
        continue;
      }
      idx[key] = out.length; out.push(it);
    }
    return out;
  };
  const give = norm(offer.give, A), want = norm(offer.want, B);
  /* Simetrik antlaşma iki listede birden varsa TEK kanonik maddeye iner. */
  for (const t of DEAL_SYMMETRIC){
    const gi = give.findIndex(x => x.t === t), wi = want.findIndex(x => x.t === t);
    if (gi >= 0 && wi >= 0){
      want.splice(wi, 1);
      normalizations.push((DEAL_KINDS[t] ? DEAL_KINDS[t].n : t) +
                          ': simetrik antlaşma tek maddeye indirildi');
    }
  }
  /* ═══ FAZ 86C.1 — YAPISAL EFFECTIVE PLAN ═══
     ÖLÇÜLEN ZAFİYET: redundant antlaşma yalnız METİN olarak
     işaretleniyor, norm.give/norm.want içinde KALIYOR ve applyItems
     tarafından yeniden uygulanabiliyordu (NAP süresi uzuyor, pact
     ilişkisi/hafızası yeniden tetikleniyordu).
     ARTIK üç ayrı yapı üretilir:
       give/want                  → kullanıcıya GÖSTERİLECEK maddeler
       effectiveGive/effectiveWant→ gerçekten UYGULANACAK maddeler
       redundantItems             → yön + kararlı madde anahtarıyla
                                    YAPISAL kayıt (Türkçe metin değil) */
  const effectiveGive = [], effectiveWant = [], redundantItems = [];
  for (const it of give){
    if (treatyAlreadyActive(A, B, it)){
      redundantItems.push({yon:'give', key:dealItemKey(it), t:it.t, it});
      redundant.push((DEAL_KINDS[it.t] ? DEAL_KINDS[it.t].n : it.t) + ' zaten yürürlükte');
    } else effectiveGive.push(it);
  }
  for (const it of want){
    if (treatyAlreadyActive(B, A, it)){
      redundantItems.push({yon:'want', key:dealItemKey(it), t:it.t, it});
      redundant.push((DEAL_KINDS[it.t] ? DEAL_KINDS[it.t].n : it.t) + ' zaten yürürlükte');
    } else effectiveWant.push(it);
  }

  return {from: fa, to: fb, give, want,
          effectiveGive, effectiveWant, redundantItems,
          normalizations, redundant, errors,
          /* Uyumluluk alanı. FAZ 86C.1: bu alan artık HİÇBİR karar
             veya UI yolunda doğruluk kaynağı DEĞİLDİR — güvenli
             normalleştirmeyi hata gibi göstermemek için ayrıldı. */
          dropped: errors.slice(),
          born: offer.born, expires: offer.expires};
}

/* Bir antlaşma maddesi ZATEN yürürlükte mi? (ilişki çiftliği önlemi) */
function treatyAlreadyActive(a, b, it){
  /* FAZ 86C.2: hedefle zaten savaştaysa warOn yeni etki üretmez. */
  if (it && it.t === 'warOn'){
    const t = G.emps[it.target];
    return !!(t && a.war && a.war[t.id]);
  }

  if (!a || !b || !it) return false;
  switch(it.t){
    case 'peace':   return !a.war[b.id];
    case 'nap':     return !(a.war&&a.war[b.id]) && !(b.war&&b.war[a.id]) &&
                           !!(a.nap && a.nap[b.id] > G.day);
    case 'pact':    return !(a.war&&a.war[b.id]) && !(b.war&&b.war[a.id]) &&
                           !!(a.pact && a.pact[b.id]);
    case 'ally':    return !(a.war&&a.war[b.id]) && !(b.war&&b.war[a.id]) &&
                           !!a.ally[b.id];
    case 'spynet':  return !!(a.spynet && a.spynet[b.id]);
    case 'intel':   return !!(b.visionFrom && b.visionFrom[a.id]);
    case 'passage': return !!(a.passage && a.passage[b.id]);
    default:        return false;
  }
}

/* ── 2) GEÇERLİLİK (SAF, NEDENLİ) ──
   Kaynak ve haraç yükümlülüklerini TOPLAM üzerinden sınar. */
function dealValidity(offer){
  const n = normalizeDeal(offer);
  /* ═══ FAZ 86C: FATAL HATA → TEKLİFİN TAMAMI REDDEDİLİR ═══
     Hatalı maddeyi sessizce atıp kalanı uygulamak YASAK. */
  if (n.errors && n.errors.length)
    return {ok:false, norm:n, reasons:n.errors.slice(),
            giveFail:[], wantFail:[], newEffect:false, fatal:n.errors.slice()};
  if (n.from === null || n.to === null)
    return {ok:false, norm:n, reasons:['Teklif geçersiz'],
            giveFail:[], wantFail:[], newEffect:false, fatal:['Teklif geçersiz']};
  const a = G.emps[n.from], b = G.emps[n.to];
  const reasons = [], giveFail = [], wantFail = [];
  if (!a || !b || a.dead || b.dead)
    return {ok:false, norm:n, reasons:['Taraflardan biri geçersiz'],
            giveFail, wantFail, newEffect:false};

  const yan = (veren, alan, items, fail) => {
    /* TOPLAM kaynak/haraç yükümlülüğü */
    const resTop = {}, tribTop = {};
    for (const it of items){
      if (it.t === 'res')     resTop[it.r]  = (resTop[it.r]  || 0) + it.v;
      if (it.t === 'tribute') tribTop[it.r] = (tribTop[it.r] || 0) + it.v;
    }
    for (const r in resTop){
      const stok = veren.res[r] || 0;
      if (stok < resTop[r]){
        const m = (RES[r] ? RES[r].n : r) + ': toplam ' + Math.round(resTop[r]) +
                  ' gerekiyor, stok ' + Math.round(stok);
        fail.push(m); reasons.push(veren.name + ' → ' + m);
      }
      if(!Number.isFinite(stok) || Math.abs((alan.res[r]||0)+resTop[r])>Number.MAX_SAFE_INTEGER){
        const m='Kaynak bakiyesi güvenli sayı sınırını aşıyor';fail.push(m);reasons.push(m);
      }
    }
    for (const r in tribTop){
      const stok = Math.max(0,(veren.res[r]||0)-(resTop[r]||0)-(r==='etk'&&veren===a?dealCost(n):0));
      if (tribTop[r] > dealMonthlyCapacity(veren,r,stok)){
        const m = (RES[r] ? RES[r].n : r) + ' haracı taşınamıyor';
        fail.push(m); reasons.push(veren.name + ' → ' + m);
      }
    }
    for (const it of items){
      let hata = null;
      switch(it.t){
        case 'sys': {
          const sy = G.sys[it.id];
          if (!sy || sy.owner !== veren.id) hata = 'sistem artık ona ait değil';
          else if (veren.home === it.id)    hata = 'başkent verilemez';
          break;
        }
        case 'tech': if (!veren.techs[it.id]) hata = 'teknoloji elinde değil'; else if(!researchAccess(alan,it.id).ok)hata=researchAccess(alan,it.id).why; break;
        case 'lux':  if (!(veren.luxOwn && veren.luxOwn[it.k])) hata = 'lüks mal elinde değil'; break;
        case 'peace': if (!veren.war[alan.id]) hata = 'zaten savaşta değilsiniz'; else if(!canPeace(veren,alan))hata='barış mümkün değil'; break;
        case 'ally': if (typeof canAlly === 'function' && !canAlly(veren, alan))
                       hata = 'ittifak mümkün değil'; break;
        case 'pact': {const gate=pactAccess(veren,alan);if(!gate.ok)hata=gate.why;break;}
        case 'warJoin': {const g=warSupportGate(veren,alan,it);if(!g.ok)hata=g.why;break;}
        case 'warOn': {
          /* FAZ 86C.2: saf söz kapısı — geçici yetki aranmaz. */
          const t = G.emps[it.target];
          const pr = canPromiseWarOn(veren, t);
          if (!pr.ok) hata = pr.why;
          break;
        }
        case 'peaceWith': {
          const t = G.emps[it.target];
          if (!t || t.dead) hata = 'hedef devlet yok';
          else if (!veren.war[t.id]) hata = 'o devletle zaten savaşta değil';
          else if (typeof canPeace === 'function' && !canPeace(veren, t))
            hata = 'o devletle barış mümkün değil';
          break;
        }
      }
      if (hata){
        const m = (DEAL_KINDS[it.t] ? DEAL_KINDS[it.t].n : it.t) + ': ' + hata;
        fail.push(m); reasons.push(veren.name + ' → ' + m);
      }
    }
  };
  /* ═══ FAZ 86C.2 — GÖREV 1A ═══
     ÖLÇÜLEN HATA: teslim/uygunluk kontrolleri hâlâ `n.give/n.want`
     üzerindeydi. "Zaten barıştayken redundant peace + yeni 10 mineral"
     paketinde effectiveGive=[res] olmasına rağmen quote FALSE dönüyor,
     gerekçe "Barış: zaten savaşta değilsiniz" oluyordu — redundant
     madde ikinci kez HATA üretiyordu.
     Fatal biçim/katalog doğrulaması normalizeDeal'de tüm GÖRÜNEN
     teklif üzerinde kalır; uygulanabilirlik ise YALNIZ effective
     plan üzerinden yürür. */
  yan(a, b, n.effectiveGive, giveFail);
  yan(b, a, n.effectiveWant, wantFail);

  /* ═══ FAZ 86C — GÖREV B: PLANLANAN SON DURUMA GÖRE DOĞRULAMA ═══
     Maddeleri sırayla mutasyona uğratarak değil, teklifin PLANLANAN
     nihai diplomatik durumunu hesaplayarak sınarız. Böylece madde
     sırası sonucu değiştirmez: "peace + nap" ile "nap + peace" aynı
     geçerli sonucu verir; savaş sürerken YALNIZ nap geçersizdir. */
  const hepsi = n.effectiveGive.concat(n.effectiveWant);
  if(hepsi.some(it=>it.t==='freight')){const why=Commerce.quote(n);if(why)reasons.push(why);}
  const plan = {
    savas: !!a.war[b.id],
    pact:  !!(a.pact && a.pact[b.id]),
    ally:  !!a.ally[b.id]
  };
  for (const it of hepsi){
    if (it.t === 'peace') plan.savas = false;
    if (it.t === 'pact') plan.pact = true;
    if (it.t === 'ally') plan.ally = true;
  }
  const planHata = m => { reasons.push(m); };
  for (const it of hepsi){
    switch(it.t){
      case 'nap':
        if (plan.savas) planHata(
          'Saldırmazlık: savaş sürerken imzalanamaz — pakete barış ekle');
        break;
      case 'pact':
        if (plan.savas) planHata(
          'Ticaret anlaşması: savaş sürerken imzalanamaz — pakete barış ekle');
        break;
      case 'ally':
        if (plan.savas) planHata('İttifak: savaş sürerken imzalanamaz — pakete barış ekle');
        if (typeof canAlly === 'function' && !canAlly(a, b) && !plan.savas)
          {/* zaten madde bazlı kontrolde yakalandı */}
        break;
      case 'passage':
        if (plan.savas) planHata('Geçiş hakkı: savaş sürerken verilemez');
        break;
    }
  }

  /* YENİ ETKİ VAR MI? Boş teklif ve yürürlükteki antlaşmanın
     tekrarı ilişki üretemez. */
  let newEffect = false;
  const bakim = (veren, alan, items) => {
    for (const it of items){
      if (DEAL_TREATY_COST[it.t] !== undefined || it.t === 'passage' || it.t === 'intel'){
        if (!treatyAlreadyActive(veren, alan, it)) newEffect = true;
      } else newEffect = true;          // maddi madde daima yeni etkidir
    }
  };
  bakim(a, b, n.effectiveGive); bakim(b, a, n.effectiveWant);
  if (!n.give.length && !n.want.length)
    reasons.push('Teklif boş — hiçbir madde yok');
  else if (!newEffect)
    reasons.push('Bütün maddeler zaten yürürlükte — yeni etki yok');

  const ok = reasons.length === 0;
  return {ok, norm:n, reasons, giveFail, wantFail, newEffect};
}
/* Eski boolean yol — ince sarmalayıcı, ayrı formül KOPYASI değil. */
/* ═══ FAZ 86C.1: KATI UYUMLULUK SARMALAYICISI ═══
   ÖLÇÜLEN ZAFİYET: eski hâl yalnız `v.giveFail.length === 0` dönüyordu
   ve beş ayrı senaryoda YANLIŞ POZİTİF üretiyordu — savaşta yalnız NAP,
   fatal bilinmeyen madde, tamamen redundant antlaşma, yetersiz Etki ve
   süresi dolmuş teklif. Artık tek doğruluk kaynağı dealQuote'tur.
   Hiçbir kritik karar bu yardımcının kısmi sonucuna dayanmaz. */
function canDeliver(e, items, other, offer){
  if (!e || !other || e.id === other.id) return false;
  /* Ömür alanları teklif nesnesinde yaşar; parça sınanırken de
     taşınmalı, aksi hâlde süresi dolmuş teklif "teslim edilebilir"
     görünüyordu (ölçülen 5. yanlış pozitif). */
  const q = dealQuote({from:e.id, to:other.id, give:items, want:[],
                       born:(offer && offer.born), expires:(offer && offer.expires)});
  return q.ok === true;
}
/* Yalnız "bu taraf bu maddeleri fiziksel olarak teslim edebilir mi?"
   sorusunun cevabı gerekiyorsa (maliyet/ömür/redundant hariç). */
function canDeliverItems(e, items, other){
  if (!e || !other || e.id === other.id) return false;
  const v = dealValidity({from:e.id, to:other.id, give:items, want:[]});
  return v.giveFail.length === 0;
}

/* ── 3) TEKLİF ÖZETİ (SAF) ── uygulanabilirlik + maliyet bölümü. */
function dealQuote(offer){
  const v = dealValidity(offer);
  const a = G.emps[v.norm.from], b = G.emps[v.norm.to];
  const cost = dealCost(v.norm);
  const outgoing=(v.norm.effectiveGive||[]).filter(it=>it.t==='res'&&it.r==='etk').reduce((n,it)=>n+it.v,0);
  const afford = !!a && (a.res.etk || 0) >= cost+outgoing;
  const bayat = dealExpired(offer);
  const reasons = v.reasons.slice();
  if (a && !afford) reasons.push('Gönderen tarafta yetersiz Etki (' + cost + ' ◈ gerekir)');
  if (bayat)   reasons.push('Teklifin süresi doldu');
  return {ok: v.ok && afford && !bayat, norm:v.norm, valid:v.ok,
          reasons, giveFail:v.giveFail, wantFail:v.wantFail,
          newEffect:v.newEffect, cost, costWho: a ? a.id : null,
          affordable:afford, expired:bayat,
          /* FAZ 86C: üç sınıf da dışarı taşınır */
          fatal: v.fatal || [],
          normalizations: v.norm.normalizations || [],
          redundant: v.norm.redundant || [],
          dropped:v.norm.dropped};
}

/* ── TEKLİF ÖMRÜ (18 ay / 540 gün) ── */
const DEAL_OFFER_LIFE = 540;
/* 87D: oyuncunun aynı şartlara verdiği ret 27 ay hatırlanır.
   Barışın mevcut 15+12 aylık politikasından ayrı; fırsat/AI değerlendirme
   katsayısı değildir. Damga ve madde sırası şartları değiştirmez. */
const PLAYER_OFFER_REFUSAL_DAYS = 810;
function playerOfferTermsKey(offer){
  const o = encodeOffer(offer);
  if (!o || o.to !== 0 || o.from === 0) return null;
  const terms = list => list.map(it=>JSON.stringify(it)).sort();
  return JSON.stringify([o.from,o.to,terms(o.give),terms(o.want)]);
}
function playerOfferWait(offer){
  const key = playerOfferTermsKey(offer);
  if (!key || !G.p || !Array.isArray(G.p.offerRefusals)) return 0;
  return G.p.offerRefusals.reduce((n,r)=>r && r.key===key && Number.isFinite(r.until)
    ? Math.max(n,r.until-G.day) : n,0);
}
function recordPlayerOfferRefusal(offer){
  const key = playerOfferTermsKey(offer), o = offer && G.emps[offer.from];
  if (!key || !G.p || G.p!==G.emps[0] || !o || o.dead || o.wild ||
      dealExpired(offer) || playerOfferWait(offer)>0) return false;
  const records = Array.isArray(G.p.offerRefusals) ? G.p.offerRefusals : [];
  G.p.offerRefusals = records.filter(r=>r && typeof r.key==='string' &&
    Number.isFinite(r.until) && r.until>G.day && r.key!==key).slice(-63);
  G.p.offerRefusals.push({key,until:G.day+PLAYER_OFFER_REFUSAL_DAYS});
  // Aynı şartların eski kutu kopyalarını kaldır; farklı teklifler korunur.
  G.inbox = (G.inbox || []).filter(n=>n.kind!=='aideal' || playerOfferTermsKey(n.data)!==key);
  if(typeof DiplomaticInbox!=='undefined')for(const r of DiplomaticInbox.state().records)if(r.status==='pending'&&r.kind==='aideal'&&playerOfferTermsKey(r.note?.data)===key){r.status='rejected';r.finished=G.day;}
  return true;
}
function dealExpired(offer){
  if (!offer) return false;
  const exp = Number(offer.expires);
  if (isFinite(exp)) return G.day > exp;
  /* GERİYE UYUM: eski tekliflerde `expires` yok. `born` varsa
     deterministik olarak born+540 kullanılır; ikisi de yoksa
     teklif süresiz sayılır (eski davranış korunur). */
  const born = Number(offer.born);
  if (isFinite(born)) return G.day > born + DEAL_OFFER_LIFE;
  return false;
}
function dealTimeLeft(offer){
  if (!offer) return null;
  const exp = Number(offer.expires);
  const born = Number(offer.born);
  const son = isFinite(exp) ? exp : (isFinite(born) ? born + DEAL_OFFER_LIFE : null);
  if (son === null) return null;
  return Math.max(0, Math.round((son - G.day) / 30));
}

/* ── 4) ATOMİK UYGULAMA ──
   executeDeal DIŞARIDAN veya bozuk kayıt üzerinden çağrılsa bile
   kendi sınırında tüm guard'ları TEKRAR doğrular. */
/* ═══════════════════════════════════════════════════════════════════
   FAZ 86C — GÖREV E: DÜZ +6 İLİŞKİ İSTİSMARININ KAPATILMASI

   ÖLÇÜLEN ESKİ DAVRANIŞ: her başarılı anlaşma KOŞULSUZ +6 veriyordu.
   Dengeli takas da, 1 birimlik sembolik hediye de aynı ödülü alıyordu.

   YENİ: goodwill YALNIZ tek yönlü GERÇEK hediyeden doğar ve alıcının
   aylık gelirine göre ölçeklenir (mutlak sayı değil — 100 mineral
   erken ekonomide büyük, geç ekonomide önemsizdir).
     netFayda = alıcıya giden değer − alıcının verdiği değer
     oran     = netFayda / max(20, alıcının aylık toplam geliri × 6)
     goodwill = clamp(floor(oran × 6), 0, 4)
   Eşik gerekçesi: 6 aylık gelire denk bir hediye tam 4 puan; altıda
   biri 1 puan; çok küçük hediye 0 üretir. Antlaşmalar kendi ilişki
   etkilerini applyItems içinde zaten uyguluyor — burada TEKRAR
   eklenmez (çift sayım yok). Aynı devlet çifti arasında goodwill
   12 ayda bir kazanılabilir; cooldown damgası imparatorluk verisinde
   (e.giftAt) tutulur, yani v8 kaydıyla KALICIDIR. */
function dealGiftValue(alan, veren, n){
  /* Alıcının aldığı maddi değer − verdiği maddi değer (saf). */
  let alinan = 0, verilen = 0;
  const say = (items, kaynak, hedef) => {
    let t = 0;
    for (const it of items){
      if (it.t === 'res')     t += it.v;
      else if (it.t === 'tribute') t += it.v * 6;
      else if (it.t === 'tech')    t += 60;
      else if (it.t === 'lux')     t += 40;
      else if (it.t === 'sys')     t += 150;
    }
    return t;
  };
  const _g = n.effectiveGive || n.give, _w = n.effectiveWant || n.want;
  if (n.from === veren.id){ alinan = say(_g); verilen = say(_w); }
  else                    { alinan = say(_w); verilen = say(_g); }
  return alinan - verilen;
}
function dealGoodwill(alan, veren, n){
  const net = dealGiftValue(alan, veren, n);
  if (net <= 0) return 0;
  let gelir = 0;
  for (const r in (alan.inc || {})) gelir += Math.max(0, alan.inc[r] || 0);
  const olcek = Math.max(20, gelir * 6);
  return clamp(Math.floor((net / olcek) * 6), 0, 4);
}
const GIFT_COOLDOWN_MONTHS = 12;
function giftOnCooldown(a, b){
  const t = a.giftAt && a.giftAt[b.id];
  return (t !== undefined) && ((G.memAge || 0) - t) < GIFT_COOLDOWN_MONTHS;
}

/* 86C.6 — ANLAŞMA İŞLEM SINIRI
   86C.2'nin derin kopyası iç içe nesne kimliğini, alias bağlantılarını
   ve 12 seviyeden derin mutasyonları korumuyordu. Son recalcMods da
   rollback sınırının dışındaydı. Aşağıdaki günlük bu yolları kapsar;
   UI/audio commit sonrasında ayrı, geri alınmayan sunum etkileridir.
   Kapsam ve gerçek üretim testleri: TRANSACTION-KAPSAMI.md. */
/* 86C.6: tersinir nesne grafiği günlüğü. Kopyalardan yeni nesne üretmez;
   her alanın ÖZGÜN referansını saklar. Paylaşılan bağlantılar, döngüler,
   diziden çıkarılmış nesneler ve 12 seviyeden derin veri korunur.
   Kapsam: aşağıdaki kökler ve bunların eriştiği oyun verisi. DOM, UI,
   fonksiyon gövdeleri ve kataloglar işlem verisi değildir. */
const DEAL_TX_ROOTS = ['emps','p','sys','fleets','feds','council',
  'economyHistory','chainQueue','seenChains','fedUid','fedFounding','commerce','news','diplomaticInbox','construction','_95eFaults','fallStats','sabStats','log','inbox','inboxUid','warLedger','settlements','jointOps','_structAt','_structIdx'];
const DEAL_TX_AUTH = ['_dealAuth','_warAuth','_warWhy','_sideBuf'];
let _dealTxActive = false;
let _warLaunchBuffer=null;
/* 96F.5: keep the complete reversible graph, but enumerate each object's
   keys once. Store descriptors in parallel arrays instead of allocating a
   second keyed object and enumerating it again. Only objects enter the work
   list; primitive values are already retained in their descriptors. No
   cross-transaction cache, getter execution or narrower rollback boundary. */
function txCaptureGraph(values, opaque){
  const seen = new Set(), records = [], pending = values.slice();
  const enqueue = value => { if (value && typeof value === 'object') pending.push(value); };
  while (pending.length){
    const obj = pending.pop();
    if (!obj || typeof obj !== 'object' || seen.has(obj) || (opaque && opaque.has(obj))) continue;
    seen.add(obj);
    const keys = Reflect.ownKeys(obj), props = [];
    const rec = {obj, keys, props, proto:Object.getPrototypeOf(obj)};
    if (obj instanceof Map){
      rec.map = Array.from(obj.entries());
      for (const [k,v] of rec.map){ enqueue(k); enqueue(v); }
    } else if (obj instanceof Set){
      rec.set = Array.from(obj.values()); for (const v of rec.set) enqueue(v);
    } else if (obj instanceof Date) rec.date = obj.getTime();
    else if (obj instanceof ArrayBuffer) rec.bytes = new Uint8Array(obj).slice();
    else if (ArrayBuffer.isView(obj)) enqueue(obj.buffer);
    else if (obj instanceof WeakMap || obj instanceof WeakSet)
      throw new Error('İşlem kökünde desteklenmeyen zayıf koleksiyon');
    for (const k of keys){
      const d = Object.getOwnPropertyDescriptor(obj,k); props.push(d);
      if ('value' in d) enqueue(d.value); // getter çalıştırılmaz
    }
    records.push(rec);
  }
  return records;
}
function txRestoreGraph(records){
  for (const rec of records){
    const obj = rec.obj, keys = rec.keys, props = rec.props;
    if (rec.map){ obj.clear(); for (const [k,v] of rec.map) obj.set(k,v); }
    if (rec.set){ obj.clear(); for (const v of rec.set) obj.add(v); }
    if ('date' in rec) obj.setTime(rec.date);
    if (rec.bytes) new Uint8Array(obj).set(rec.bytes);
    if (Object.getPrototypeOf(obj) !== rec.proto) Object.setPrototypeOf(obj,rec.proto);
    const oldKeys = new Set(keys);
    for (const k of Reflect.ownKeys(obj)) if (!oldKeys.has(k)) delete obj[k];
    // Dizi uzunluğu en son: eski üyeler aynı nesnelerle ve sırayla bağlanır.
    let length = null;
    for (let i=0;i<keys.length;i++){
      if (Array.isArray(obj) && keys[i] === 'length'){ length=props[i]; continue; }
      Object.defineProperty(obj,keys[i],props[i]);
    }
    if (length) Object.defineProperty(obj,'length',length);
  }
}
function dealTxBegin(){
  const roots = new Map(), auth = new Map(), values = [];
  for (const key of DEAL_TX_ROOTS){
    const d = Object.getOwnPropertyDescriptor(G,key);
    roots.set(key,d);
    if (d && 'value' in d) values.push(d.value);
  }
  for (const key of DEAL_TX_AUTH) auth.set(key,Object.getOwnPropertyDescriptor(G,key));
  return {roots,auth,records:txCaptureGraph(values),rng:RND_STATE};
}
function dealTxRollback(tx){
  txRestoreGraph(tx.records);
  for (const [key,d] of tx.roots){
    if (d) Object.defineProperty(G,key,d); else delete G[key];
  }
  rndSeed(tx.rng);
  dealTxRestoreAuth(tx);
  // Yeniden hesaplama YOK: mods/cap/cache de özgün haliyle geri geldi.
}
function dealTxRestoreAuth(tx){
  for (const [key,d] of tx.auth){
    if (d) Object.defineProperty(G,key,d); else delete G[key];
  }
}

/* ── POSTCONDITION: her effective madde gerçekten uygulandı mı? ── */
function dealPostcondition(giver, taker, it){
  const T = (x) => G.emps[x];
  switch(it.t){
    case 'freight': return Commerce.state().contracts.some(c=>!Commerce.closed(c)&&c.legs.some(l=>l.e===giver.id&&l.to===taker.id&&l.r===it.r&&l.v===it.v&&l.source===it.source&&l.target===it.target));
    case 'res':      return true;   // miktar kontrolü akış içinde
    /* applyItems: VEREN tarafın tribute listesine kayıt eklenir. */
    case 'tribute':  return Array.isArray(giver.tribute) &&
                            giver.tribute.some(x => x && x.to === taker.id &&
                                                    x.r === it.r && x.v === it.v);
    case 'sys': {
      const s = G.sys[it.id];
      return !!(s && s.owner === taker.id);
    }
    case 'tech':     return !!taker.techs[it.id];
    /* applyItems: ALAN tarafın luxGrant kaydı verene bağlanır. */
    case 'lux':      return !!(taker.luxGrant && taker.luxGrant[it.k] === giver.id);
    case 'peace':    return !giver.war[taker.id] && !taker.war[giver.id];
    case 'peaceWith': {
      const t = T(it.target);
      return !!(t && !giver.war[t.id] && !t.war[giver.id]);
    }
    case 'nap':      return !!(giver.nap && giver.nap[taker.id] &&
                               taker.nap && taker.nap[giver.id]);
    case 'pact':     return !!(giver.pact && giver.pact[taker.id] &&
                               taker.pact && taker.pact[giver.id]);
    case 'ally':     return !!(giver.ally[taker.id] && taker.ally[giver.id]);
    case 'spynet':   return !!(giver.spynet && giver.spynet[taker.id] &&
                               taker.spynet && taker.spynet[giver.id]);
    case 'warJoin': {const t=T(it.target),f=warLedgerFind(giver.id,it.target),src=(G.warLedger?.fronts||[]).find(x=>x.id===it.front);return !!(t&&f&&src&&f.campaign===src.campaign&&giver.war[t.id]&&t.war[giver.id]);}
    case 'warOn': {
      const t = T(it.target);
      return !!(t && giver.war[t.id] && t.war[giver.id]);
    }
    case 'intel':    return !!(taker.visionFrom && taker.visionFrom[giver.id]);
    /* applyItems: VEREN taraf kendi sınırını alana açar. */
    case 'passage':  return !!(giver.passage && giver.passage[taker.id]);
    default:         return true;
  }
}

/* 86C.6: begin → apply → postcondition → recalc → log → commit.
   Commit öncesindeki üretim hatası kayıtlı oyun grafiğini geri alır.
   Sonrasında UI/audio ayrı ayrı korunur; bu etkiler tersinir değildir. */
function executeDeal(offer, inboxKey=null){
  // İç içe işlem desteklenmiyor; dış işlemin tamponunu yayımlayamaz.
  if (_dealTxActive) return false;
  const archived=typeof DiplomaticInbox!=='undefined'?(inboxKey===null?DiplomaticInbox.findDeal(offer):DiplomaticInbox.state().records.find(r=>r.key===inboxKey)):null;
  if(archived&&(archived.status!=='pending'||G.day>=archived.expires))return false;
  if((offer.give||[]).concat(offer.want||[]).some(x=>x.t==='warJoin'&&x.plan!==undefined))return warPrepareAccept(offer,archived);
  _dealTxActive = true;
  let tx = null;
  const buf = [];
  try {
    if (G._sideBuf) return false; // başka bir tamponun sahipliğini alma
    const q = dealQuote(offer);
    if (!q.ok) return false;
    const n = q.norm, a = G.emps[n.from], b = G.emps[n.to];
    if (!a || !b) return false;
    tx = dealTxBegin();
    G._sideBuf = buf;
    G._dealAuth = true;
    if(n.effectiveGive.concat(n.effectiveWant).some(it=>it.t==='freight'))Commerce.sign(n);
    applyItems(a, b, n.effectiveGive);
    applyItems(b, a, n.effectiveWant);
    if (typeof G._dealFailInject === 'function') G._dealFailInject('after:items');
    a.res.etk = (a.res.etk || 0) - q.cost;
    if (typeof G._dealFailInject === 'function') G._dealFailInject('after:cost');

    const gwB = giftOnCooldown(a, b) ? 0 : dealGoodwill(b, a, n);
    const gwA = giftOnCooldown(b, a) ? 0 : dealGoodwill(a, b, n);
    if (gwB > 0){
      b.rel[a.id] = clamp(b.rel[a.id] + gwB, -100, 100);
      a.giftAt = a.giftAt || {}; a.giftAt[b.id] = (G.memAge || 0);
    }
    if (gwA > 0){
      a.rel[b.id] = clamp(a.rel[b.id] + gwA, -100, 100);
      b.giftAt = b.giftAt || {}; b.giftAt[a.id] = (G.memAge || 0);
    }
    if (typeof G._dealFailInject === 'function') G._dealFailInject('after:goodwill');
    recalcMods(a); recalcMods(b); // son hesaplama da geri alınabilir sınırda
    if (typeof G._dealFailInject === 'function') G._dealFailInject('after:recalc');
    commitSideBuffer(buf);       // kalıcı log, UI/audio yayımlanmadan önce
    if (typeof G._dealFailInject === 'function') G._dealFailInject('after:log');
    if(archived){archived.status='accepted';archived.finished=G.day;}
    if (typeof G._dealFailInject === 'function') G._dealFailInject('son');
  } catch(err){
    if (tx) dealTxRollback(tx);
    return false;
  } finally {
    if (tx) dealTxRestoreAuth(tx);
    _dealTxActive = false;
  }
  // Artık commit edildi. Sunum hatası işlemi reddedilmiş gösteremez;
  // yeniden ücretlendirme, yeniden uygulama veya geri alma yapılmaz.
  if(_warLaunchBuffer)_warLaunchBuffer.push(...buf);else flushSideBuffer(buf);
  return true;
}

/* =====================================================================
   FEDERASYON VE KONSEY
   ===================================================================== */
const FED_LAWS = {
  savunma :{n:'Savunma Paktı', ico:'🛡',
    d:'Bir üyeye savaş açılırsa tüm üyeler otomatik savaşa girer.'},
  arastirma:{n:'Ortak Araştırma Fonu', ico:'🔬',
    d:'Üyeler araştırma çıktısının %10\'unu paylaşır.'},
  ticaret :{n:'Ticaret Birliği', ico:'🤝',
    d:'Üye limanları otomatik olarak birbirine bağlanır.'},
  filo    :{n:'Ortak Filo', ico:'⚑',
    d:'Üyeler ayda 4 alaşımı ortak filo hazinesinde biriktirir; otomatik gemi üretmez.'}
};

/* 95B: political federation data. All timings are game days (30 days/month).
   Existing law effects and production remain in their canonical owners. */
const FED_TYPES={
 askeri:{n:'Askerî Federasyon',ico:'🛡',d:'+12 filo kapasitesi; bakım +4 yüzde puan. Varsayılan ortak savunma; saldırı için ayrı karar.',cap:12,up:.04,ara:1,ene:1,tithe:.05},
 bilimsel:{n:'Bilimsel Federasyon',ico:'🔬',d:'Pozitif araştırma +%8; pozitif enerji −%3. Savaş yardımı varsayılan olarak oylamayla.',cap:0,up:0,ara:1.08,ene:.97,tithe:.05},
 ticaret:{n:'Ticaret Federasyonu',ico:'🤝',d:'Filo bakım değiştiricisi −5 yüzde puan; taban fon kesintisi %4; araştırma −%3. Teslimatsız ticaret geliri eklemez.',cap:0,up:-.05,ara:.97,ene:1,tithe:.04},
 yagmaci:{n:'Yağmacı Federasyon',ico:'⚔',d:'+8 filo kapasitesi; bakım +6 yüzde puan, araştırma −%5, taban fon %6. Gerçek savaş fethinde düşman stokundan koloni başına en çok120 maden/40 alaşım, cephe ve üye başına240/80; aynı koloni bir kez. Savunma ve saldırı oylamayla.',cap:8,up:.06,ara:.95,ene:1,tithe:.06}
};
const FED_MOTIONS={admit:{n:'Üye Kabulü',c:60},expel:{n:'Üye İhracı',c:80},reform:{n:'Tür Reformu',c:150},charter:{n:'Anayasa Değişikliği',c:100},elect:{n:'Başkan Seçimi',c:50},joinWar:{n:'Mevcut Savaşa Katılma',c:0},newWar:{n:'Ortak Savaş İzni',c:0}};
/* 96G extends the existing charter and ballot. Members publish bounded
   representation mandates; foreign applicants are assessed through observed
   intelligence only. Mandates contain no fleet locations, technologies or stocks. */
const FED_BALLOTS={
 equal:{n:'Eşit Temsil',d:'Her üye 1 oy. Küçük devletleri korur; büyük katkıya ek oy vermez.'},
 hegemonic:{n:'Hegemonik',d:'Askerî güç ve savunma kapasitesi ağırlığı artırır. Küçük üyelerin nüfuzu azalır; tek devlet karar dayatamaz.'},
 economic:{n:'Ekonomik Temsil',d:'Giderler sonrası sürdürülebilir aylık üretim ağırlığı artırır. Stok biriktirmek oy kazandırmaz; zayıf ekonomiler daha az etkili olur.'},
 mixed:{n:'Karma Konsey',d:'Eşit taban, askerî ve ekonomik katkıyı dengeler. Tek uzmanlıkta güçlü devletin üstünlüğünü yumuşatır.'},
 weighted:{n:'Ağırlıklı — eski anayasa',d:'Eski kayıt kuralı: Konsey Mimarı 2, diğer üyeler 1 oy. Kendiliğinden başka rejime dönüşmez.'}
};
function fedBallot(f){return fedCharter(f).ballot||'weighted';}
function fedEconomicMandate(e){
 const inc=e.inc||{},prices={ene:1,min:1,yiy:.6,ala:2,tuk:1.5,ara:1};let gain=0,burden=0;
 for(const [r,p]of Object.entries(prices)){const n=Number.isFinite(inc[r])?inc[r]:0;gain+=Math.max(0,n)*p;burden+=Math.max(0,-n)*p;}
 return Math.sqrt(Math.max(0,gain-burden*2)+1);
}
function fedSelfMandate(e){return {military:Math.sqrt(Math.max(0,totalPower({...e}))+25),economic:fedEconomicMandate(e)};}
function fedRefreshRepresentation(f,force=false){
 if(['weighted','equal'].includes(fedBallot(f)))return;
 const month=Math.floor(G.day/30);if(!force&&f.representation?.month===month)return;
 f.representation={month,by:Object.fromEntries(f.members.filter(id=>G.emps[id]&&!G.emps[id].dead).map(id=>[id,fedSelfMandate(G.emps[id])]))};
}
function fedWeightsFrom(ids,mode,ratings={}){
 if(mode==='weighted')return Object.fromEntries(ids.map(id=>[id,hasCivic(G.emps[id],'council')?2:1]));
 const maxM=Math.max(1,...ids.map(id=>ratings[id]?.military||0)),maxE=Math.max(1,...ids.map(id=>ratings[id]?.economic||0));
 return Object.fromEntries(ids.map(id=>{const r=ratings[id]||{},m=(r.military||0)/maxM,e=(r.economic||0)/maxE;
  const v=mode==='hegemonic'?1+m:mode==='economic'?1+e:mode==='mixed'?1+(m+e)/2:1;
  return [id,Math.round(clamp(v,1,2)*1000)/1000];}));
}
function fedLiveWeights(f,ids=f.members,mode=fedBallot(f)){return fedWeightsFrom(ids,mode,f.representation?.by||{});}
function fedFreezeBallot(f,v,source='opened'){
 if(v.ballotSnapshot)return;
 const ids=[...new Set(v.eligible||f.members)].filter(id=>G.emps[id]&&!G.emps[id].dead&&!(v.motion==='expel'&&id===v.target));
 if(!Array.isArray(v.eligible))v.eligible=ids.slice();
 v.ballotSnapshot={mode:fedBallot(f),weights:fedLiveWeights(f,ids),modern:!!f.politicsVersion||['hegemonic','economic','mixed'].includes(fedBallot(f)),source};
}
function fedVoteRule(f,c=fedVoteCounts(f)){
 const v=f.vote;if(!v)return '';
 const modern=v.ballotSnapshot?.modern,supermajority=v.kind==='motion'&&['charter','reform'].includes(v.motion);
 const heads=v.kind==='motion'||modern?(supermajority?Math.ceil(c.eligible.length*.75):Math.floor(c.eligible.length/2)+1):modern?Math.floor(c.eligible.length/2)+1:0;
 return (supermajority?'En az %75 üye onayı':heads?'Mutlak üye çoğunluğu':'Evet oyları hayırdan fazla')+(heads?' ('+heads+'/'+c.eligible.length+')':'')+
  (modern?(supermajority?' ve en az %75 oy ağırlığı':' ve toplam oy ağırlığının yarısından fazlası'):'; ağırlıklı evet üstünlüğü')+'. Süre sonunda eksik oy çekimserdir.';
}
function fedType(f){return FED_TYPES[f&&f.type]||FED_TYPES.askeri;}
function fedCharter(f){return f&&f.charter||{defense:f&&f.laws&&f.laws.savunma?'auto':'vote',offense:'vote',admission:'allies',ballot:'weighted'};}
function fedDefaultCharter(type){return {defense:type==='askeri'?'auto':'vote',offense:'vote',admission:'allies',ballot:'weighted'};}
function fedDuty(f,kind){return kind==='defense'?!!(f.laws&&f.laws.savunma)||fedCharter(f).defense==='auto':fedCharter(f).offense==='auto';}
function fedDutyText(f){return (fedDuty(f,'defense')?'Yeni saldırılara ortak savunma yükümlülüğü. ':'Savunma yardımı oylamayla. ')+(fedDuty(f,'offense')?'Yalnız saldırı taahhüdünü açıkça kabul eden üyeler yeni saldırılara katılır.':'Otomatik saldırı desteği yok; ayrı oylama/taahhüt gerekir.');}
function fedCharterKey(f){return JSON.stringify([f.type||'askeri',fedCharter(f),Object.keys(f.laws||{}).filter(k=>f.laws[k]).sort()]);}
function fedPoliticalRecord(f,event,data={}){f.history=f.history||[];f.history.push({day:G.day,year:G.year,month:G.month,event,...data});if(f.history.length>32)f.history.splice(0,f.history.length-32);if(typeof GalacticNews!=='undefined')GalacticNews.political(f,event,data);}
/* 96G-D2: reuse the bounded political history, not a second memory table.
   Store public context and declared opposition. Each AI reconsiders only
   its own position; no foreign treasury or hidden forces are inspected. */
function fedRetryContext(f){
 return JSON.stringify([f.members.filter(id=>G.emps[id]&&!G.emps[id].dead).slice().sort((a,b)=>a-b),f.type,fedCharterKey(f),Object.keys(f.laws||{}).sort()]);
}
function fedLawRetryAllowed(f,law,proposer=null){
 const row=(f.history||[]).slice().reverse().find(x=>x?.event==='vote'&&x.law===law&&!x.passed&&typeof x.retry?.context==='string'&&['eligible','yes','no'].every(k=>Array.isArray(x.retry[k])));
 if(!row||row.retry.context!==fedRetryContext(f))return true;
 const r=row.retry,eligible=r.eligible.filter(id=>f.members.includes(id)&&G.emps[id]&&!G.emps[id].dead);
 const weights=fedLiveWeights(f,eligible),total=eligible.reduce((n,id)=>n+(weights[id]||1),0),yes=eligible.filter(id=>r.yes.includes(id));
 if((!r.modern||yes.length>eligible.length/2)&&yes.reduce((n,id)=>n+(weights[id]||1),0)>total/2)return true;
 for(const id of r.no){const e=G.emps[id];if(e?.ai&&!e.dead&&f.members.includes(id)&&aiFedVoteAssessment(e,f,{kind:FED_INNER_LAWS[law]?'inner':'basic',law,proposer:proposer?.id??null}).score>=.5)return true;}
 return false;
}
/* BETA-BOARD.1: one bounded FIFO for existing federation ballots. No fee or
   political effect is applied while waiting. Opening reuses the canonical gates. */
const FED_AGENDA_OPENING=new Set();
function fedAgendaKey(kind,law,o={}){if(kind==='application'||kind==='motion'&&o.kind==='admit')return JSON.stringify(['admission',o.target]);return JSON.stringify([kind,law||'',!!o.repeal,o.kind||'',o.target??null,kind==='war'?(o.sponsor??o.proposer??null):o.sponsor??null,o.type??null,o.field??null,o.value??null]);}
function fedAgendaLabel(r){return r.kind==='law'?((FED_LAWS[r.law]||FED_INNER_LAWS[r.law])?.n||r.law)+(r.options.repeal?' (kaldırma)':''):r.kind==='war'?'Savaş İzni':FED_MOTIONS[r.options.kind]?.n||'Üyelik Başvurusu';}
function fedAgendaCheck(f,kind,law,o={}){
 if(FED_AGENDA_OPENING.has(f))return {ok:true};
 const key=fedAgendaKey(kind,law,o),items=f.agenda?.items||[];
 const emergency=kind==='motion'&&fedEmergencyId(f,null,o.kind,o);if(emergency&&f.agenda?.history.some(r=>r.defenseFront===emergency))return {ok:false,why:'Bu savunma olayı zaten gündeme alındı'};
 if(items.length>=12)return {ok:false,why:'Gündem kuyruğu dolu (12 öneri)'};
 if(items.some(r=>r.key===key))return {ok:false,why:'Aynı öneri zaten kuyrukta'};
 const v=f.vote;if(v&&fedAgendaKey(v.kind==='war'?'war':v.kind==='motion'?'motion':'law',v.law,{...v,kind:v.motion})===key)return {ok:false,why:'Aynı öneri zaten oylanıyor'};
 return {ok:true};
}
function fedAgendaWaiting(f){return !FED_AGENDA_OPENING.has(f)&&!!(f.vote||f.lawVote||f.agenda?.items.length);}
function fedAgendaEnqueue(f,e,kind,law,o={}){
 const q=fedAgendaCheck(f,kind,law,o);if(!q.ok)return q;
 const old=f.agenda;if((old?.items||[]).filter(r=>r.by===e.id).length>=3)return {ok:false,why:'Kendi en fazla üç bekleyen önerin olabilir'};
 return fedChange(()=>{const a=f.agenda||(f.agenda={v:1,next:1,items:[],history:[]});
 if(a.items.filter(r=>r.by===e.id).length>=3)return {ok:false,why:'Kendi en fazla üç bekleyen önerin olabilir'};
 const row={id:a.next++,by:e.id,kind,law,options:{...o},key:fedAgendaKey(kind,law,o),created:G.day,expires:G.day+360,status:'waiting'};
 const emergency=kind==='motion'&&fedEmergencyId(f,e,o.kind,o);if(emergency)row.defenseFront=emergency;
 a.items.push(row);const position=fedAgendaOrder(f).indexOf(row)+1;return {ok:true,pending:true,queued:true,id:row.id,position,why:(emergency?'Acil savunma':'FIFO gündem')+' kuyruğuna eklendi; sıra '+position+'. Bedel yalnız açılışta.'};});
}
function fedAgendaArchive(f,row,status,why){row.status=status;row.why=String(why).slice(0,240);row.updated=G.day;const a=f.agenda;a.history.push(row);while(a.history.length>32){const i=a.history.findIndex(r=>r.status!=='active');a.history.splice(i<0?0:i,1);}}
function withdrawFedAgenda(e,fid,id){
 const f=fedOf(fid),a=f?.agenda,row=a?.items.find(r=>r.id===id);
 if(!e||G.emps[e.id]!==e||e.dead||!row||row.by!==e.id||!f.members.includes(e.id)&&row.kind!=='application')return {ok:false,why:'Yalnız kendi bekleyen önerini geri çekebilirsin'};
 return fedChange(()=>{a.items=a.items.filter(r=>r!==row);fedAgendaArchive(f,row,'withdrawn','Öneren geri çekti; bedel kesilmedi');return {ok:true};});
}
function fedAdvanceAgenda(f){
 if(!f?.agenda||FED_AGENDA_OPENING.has(f)||fedOf(f.id)!==f||f.vote||f.lawVote)return;
 FED_AGENDA_OPENING.add(f);
 try{for(let n=0;n<12&&f.agenda.items.length&&!f.vote;n++){
  const row=fedAgendaOrder(f)[0];f.agenda.items.splice(f.agenda.items.indexOf(row),1);const e=G.emps[row.kind==='application'?row.options.sponsor:row.by];let q;
  if(!e||e.dead||!f.members.includes(e.id))q={ok:false,why:'Öneren artık yaşayan bir üye değil'};
  else if(row.expires<=G.day)q={ok:false,why:'Kuyrukta bekleme süresi (360 gün) doldu'};
  else if(row.defenseFront&&fedEmergencyId(f,e,row.options.kind,row.options)!==row.defenseFront)q={ok:false,why:'Acil savunmanın kaynak cephesi sona erdi veya değişti'};
  else q=row.kind==='law'?canFedLaw(e,row.law,!!row.options.repeal):row.kind==='war'?canFedWarRequest(e,G.emps[row.options.target]):row.kind==='application'?canRequestFederation(G.emps[row.options.applicant],e):canFedMotion(e,row.options.kind,row.options);
  if(q.ok&&q.fed!==f)q={ok:false,why:'Federasyon değişti'};
  if(!q.ok){fedAgendaArchive(f,row,row.expires<=G.day?'expired':'invalid',q.why||'Koşullar değişti');continue;}
  const r=row.kind==='law'?proposeFedLaw(e,row.law,!!row.options.repeal):row.kind==='war'?proposeFedWar(e,G.emps[row.options.target]):row.kind==='application'?requestFederation(G.emps[row.options.applicant],e):proposeFedMotion(e,row.options.kind,row.options);
  if(fedOf(f.id)!==f){const restored=fedOf(f.id);if(restored?.agenda)fedAgendaArchive(restored,row,'invalid',r.why||'İşlem geri alındı; bedel korunur');break;}
  if(r.ok){if(row.defenseFront)f.agenda.emergencyStreak=Math.min(2,(f.agenda.emergencyStreak||0)+1);else if(f.agenda.emergencyStreak)f.agenda.emergencyStreak=0;row.vote=fedVoteToken(f.vote)||f.lastVote?.id;fedAgendaArchive(f,row,f.vote?'active':'resolved',f.vote?'Sıra geldi; oylama açıldı':f.lastVote?.why||'Oylama sonuçlandı');}
  else fedAgendaArchive(f,row,'invalid',r.why||'Oylama açılamadı; bedel kesilmedi');
 }}finally{FED_AGENDA_OPENING.delete(f);}
}
function fedRestoreAgenda(f){
 if(f.agenda===undefined)return;const raw=f.agenda,ids=new Set(),keys=new Set();
 const row=r=>{if(!r||!Number.isSafeInteger(r.id)||r.id<1||r.id>2147483646||ids.has(r.id)||!Number.isInteger(r.by)||!G.emps[r.by]||!['law','war','motion','application'].includes(r.kind)||!Number.isFinite(r.created)||!Number.isFinite(r.expires)||r.expires<=r.created||r.expires>r.created+360)return null;
  const o=r.options;if(!o||typeof o!=='object'||Array.isArray(o))return null;
  const opts={};for(const k of ['target','sponsor','applicant'])if(o[k]!==undefined){if(!Number.isInteger(o[k])||!G.emps[o[k]])return null;opts[k]=o[k];}
  for(const k of ['kind','type','field','value'])if(o[k]!==undefined){if(typeof o[k]!=='string'||o[k].length>32)return null;opts[k]=o[k];}if(o.repeal!==undefined)opts.repeal=!!o.repeal;
  if(r.kind==='law'&&!Object.hasOwn(FED_LAWS,r.law)&&!Object.hasOwn(FED_INNER_LAWS,r.law)||r.kind==='motion'&&!Object.hasOwn(FED_MOTIONS,opts.kind)||r.kind==='application'&&(!Number.isInteger(opts.applicant)||!Number.isInteger(opts.target)||!Number.isInteger(opts.sponsor)||opts.applicant!==r.by||opts.target!==opts.applicant)||r.kind==='war'&&!Number.isInteger(opts.target))return null;
  if(r.defenseFront!==undefined&&(!Number.isSafeInteger(r.defenseFront)||r.defenseFront<1||r.kind!=='motion'||opts.kind!=='joinWar'))return null;
  ids.add(r.id);return {...(r.defenseFront?{defenseFront:r.defenseFront}:{}),id:r.id,by:r.by,kind:r.kind,law:r.kind==='law'?r.law:r.kind==='war'?'warPermit':'motion',options:opts,key:fedAgendaKey(r.kind,r.law,opts),created:r.created,expires:r.expires,status:r.status,...(typeof r.why==='string'?{why:r.why.slice(0,240)}:{}),...(Number.isFinite(r.updated)?{updated:r.updated}:{}),...(typeof r.vote==='string'?{vote:r.vote.slice(0,40)}:{}),...(Number.isInteger(r.position)&&r.position>0&&r.position<=12?{position:r.position}:{})};};
 const items=[],history=[];for(const r of (Array.isArray(raw?.items)?raw.items:[]).slice(0,12)){const n=row(r);if(n&&!keys.has(n.key)){keys.add(n.key);n.status='waiting';items.push(n);}}
 for(const r of (Array.isArray(raw?.history)?raw.history:[]).slice(-32)){const n=row(r);if(n&&['active','resolved','invalid','expired','withdrawn'].includes(n.status))history.push(n);}
 f.agenda={...(Number.isInteger(raw.emergencyStreak)&&raw.emergencyStreak>=0&&raw.emergencyStreak<=2?{emergencyStreak:raw.emergencyStreak}:{}),v:1,next:Math.max(Number.isSafeInteger(raw?.next)&&raw.next>0&&raw.next<2147483647?raw.next:1,Math.max(0,...ids)+1),items,history};
}

function fedNormalize(f){
 if(!f||!Array.isArray(f.members))return;
 federationIdentity(f);
 if(!Object.hasOwn(FED_TYPES,f.type)){f.type='askeri';f.charter=fedCharter({...f,charter:null});f.legacyCharter=true;}
 f.charter=f.charter||fedDefaultCharter(f.type);
 if(!Number.isFinite(f.founded))f.founded=G.day;
 if(!Number.isFinite(f.typeSince))f.typeSince=G.day;
 if(!f.dutySince)f.dutySince={defense:0,offense:G.day};
 if(!f.members.includes(f.leader)||!G.emps[f.leader]||G.emps[f.leader].dead){
  const previous=f.leader;
  f.leader=f.members.includes(f.founder)&&!G.emps[f.founder]?.dead?f.founder:f.members.filter(id=>G.emps[id]&&!G.emps[id].dead).sort((a,b)=>a-b)[0];
  if(G.emps[f.leader]){for(const fl of G.fleets)if(fl.federal&&fl.fedId===f.id)fl.e=f.leader;G.emps[f.leader]._powAt=-1;}
  if(G.emps[previous])G.emps[previous]._powAt=-1;
 }
 f.invites=f.invites||{};f.decisions=f.decisions||{};f.dutyConsent=f.dutyConsent||{};
 if(f.vote&&!f.vote.ballotSnapshot)fedFreezeBallot(f,f.vote,'legacy-load');
 if(f.reform&&(!Object.hasOwn(FED_TYPES,f.reform.type)||!Number.isFinite(f.reform.at)))delete f.reform;
}
function fedSyncDuties(f,before){
 f.dutySince=f.dutySince||{defense:0,offense:0};
 for(const k of ['defense','offense'])if(!before[k]&&fedDuty(f,k)){f.dutySince[k]=G.day;if(k==='defense')f.defenseFrontCutoff=G.warLedger?.next||1;}
}
function fedReformTick(f){
 if(!f.reform||G.day<f.reform.at)return;
 const before={defense:fedDuty(f,'defense'),offense:fedDuty(f,'offense')},next=f.reform.type;
 f.type=next;f.typeSince=G.day;
 // A reform's new default applies only if members kept the former default;
 // explicit constitutional choices and all 15 laws remain in force.
 if(f.reform.defaultDefense)f.charter.defense=fedDefaultCharter(next).defense;
 f.legacyCharter=false;delete f.reform;fedSyncDuties(f,before);
 fedPoliticalRecord(f,'reformComplete',{type:next});for(const id of f.members)recalcMods(G.emps[id]);
 if(f.members.includes(0))say(f.name+' — '+fedType(f).n+' geçişi tamamlandı','sci');
}
function fedRemoveMember(f,id,reason){
 if(!f.members.includes(id))return false;
 const old=f.members.slice();f.members=f.members.filter(x=>x!==id);
 for(const peer of old)if(peer!==id&&G.emps[peer]&&G.emps[id]){G.emps[id].ally[peer]=false;G.emps[peer].ally[id]=false;}
 delete (f.dutyConsent||{})[id];if(G.emps[id])G.emps[id]._fedLeaveUntil=G.day+720;
 fedPoliticalRecord(f,reason,{target:id});fedNormalize(f);
 for(const x of old)if(G.emps[x]&&!G.emps[x].dead)recalcMods(G.emps[x]);return true;
}
function leaveFederation(e){const f=e&&findFed(e);if(!f)return {ok:false,why:'Federasyon üyesi değilsin'};fedRemoveMember(f,e.id,'leave');updateFederations();return {ok:true};}
function fedDissolve(f){
 if(typeof GalacticNews!=='undefined')GalacticNews.political(f,'dissolved');
 const ids=f.members.slice();G.feds=G.feds.filter(x=>x!==f);
 for(const fl of G.fleets)if(fl.federal&&fl.fedId===f.id){delete fl.federal;delete fl.fedId;}
 for(const id of ids)if(G.emps[id]){G.emps[id]._fedLeaveUntil=G.day+720;recalcMods(G.emps[id]);}
}
function fedAdmissionGate(f,o,ballot=false){
 if(!o||G.emps[o.id]!==o||o.dead||o.wild||o.crisisSide||isPurifier(o)||isVassal(o)||findFed(o))return {ok:false,why:'Aday bağımsız ve uygun değil'};
 if((o._fedLeaveUntil||0)>G.day)return {ok:false,why:'Son ayrılış sonrası bekleme sürüyor'};
 if(f.members.some(id=>!G.emps[id]||G.emps[id].dead||o.war[id]||G.emps[id].war[o.id]||diploBlocked(o,G.emps[id])))return {ok:false,why:'Bir üyeyle savaş veya doktrin engeli var'};
 if(!ballot&&fedCharter(f).admission==='allies'&&!f.members.every(id=>o.ally[id]&&G.emps[id].ally[o.id]))return {ok:false,why:'Anayasa bütün üyelerle karşılıklı ittifak istiyor'};
 return {ok:true};
}
function acceptFedInvite(o,fid){
 const f=fedOf(fid),inv=f&&f.invites&&f.invites[o.id];
 if(!inv||inv.expires<=G.day||inv.terms!==fedCharterKey(f))return {ok:false,why:'Davetin süresi veya yükümlülükleri değişti'};
 const gate=fedAdmissionGate(f,o,inv.admission==='vote');if(!gate.ok)return gate;
 return fedChange(()=>{
 const old=f.members.slice();f.members.push(o.id);delete f.invites[o.id];
 fedAdmissionResult(f,inv.vote,'accepted','Kabul edildi; devlet federasyona katıldı.');
 if(o.id===0&&typeof DiplomaticInbox!=='undefined')DiplomaticInbox.settleSource('invite',fid,String(inv.expires),'accepted');
 for(const id of old){const e=G.emps[id];o.ally[id]=e.ally[o.id]=true;o.contact[id]=e.contact[o.id]=true;clearBilateralEmbargo(o,e);}
 f.dutyConsent[o.id]={offense:fedDuty(f,'offense'),since:G.day};fedPoliticalRecord(f,'join',{target:o.id});
 for(const id of f.members)recalcMods(G.emps[id]);fedRefreshRepresentation(f,true);return {ok:true};
 });
}
function rejectFedInvite(o,fid,why='Aday daveti reddetti'){
 const f=fedOf(fid),inv=f?.invites?.[o?.id];if(!inv)return {ok:false,why:'Geçerli davet yok'};
 if(o.id===0&&typeof DiplomaticInbox!=='undefined')DiplomaticInbox.settleSource('invite',fid,String(inv.expires),'rejected');
 fedAdmissionResult(f,inv.vote,'rejected',why);delete f.invites[o.id];f.requestAfter=f.requestAfter||{};f.requestAfter['admit:'+o.id]=G.day+360;return {ok:true};
}
// 96E: applications enter the existing admission ballot, addressed via any member.
function canRequestFederation(e,via){
 if(!e||G.emps[e.id]!==e||!via||G.emps[via.id]!==via||via.dead||e===via||!e.contact[via.id]||!via.contact[e.id])return {ok:false,why:'Karşılıklı temas ve yaşayan bir üye gerekli'};
 const f=findFed(via);if(!f)return {ok:false,why:'Hedef devlet federasyon üyesi değil'};
 const q=canFedMotion(via,'admit',{target:e.id},true);if(!q.ok)return q;
 const aq=fedAgendaCheck(f,'application','motion',{kind:'admit',target:e.id,applicant:e.id});if(!aq.ok)return aq;
 if((f.requestAfter?.['admit:'+e.id]||0)>G.day)return {ok:false,why:'Aynı üyelik başvurusu için bekleme süresi var'};
 if((e.res.etk||0)<60)return {ok:false,why:'Başvuru için 60 Etki gerekir'};
 return {ok:true,fed:f};
}
function requestFederation(e,via){
 const q=canRequestFederation(e,via);if(!q.ok)return q;
 if(fedAgendaWaiting(q.fed))return fedAgendaEnqueue(q.fed,e,'application','motion',{kind:'admit',target:e.id,applicant:e.id,sponsor:via.id});
 const result=fedChange(()=>{fedNormalize(q.fed);e.res.etk-=60;q.fed.requestAfter=q.fed.requestAfter||{};q.fed.requestAfter['admit:'+e.id]=G.day+180;
  return fedOpenVote(q.fed,'motion',via,{kind:'admit',target:e.id,applicant:e.id});});
 if(result.ok)fedPresentVote(q.fed,result);return result;
}
function fedAdmissionResult(f,token,status,why){
 const row=f.admissionResults?.[String(token)];if(!row)return;
 row.status=status;row.why=why;row.updated=G.day;
 if(typeof DiplomaticInbox!=='undefined'){
  for(const r of DiplomaticInbox.state().records)if(r.kind==='fedrequest'&&r.fid===f.id&&r.token===String(token)){
   r.sub=why;if(status!=='pending'){r.status=status;r.finished=G.day;}
  }
 }
}
function fedTrackAdmission(f,v){
 f.admissionResults=f.admissionResults||{};
 f.admissionResults[String(v.id)]={target:v.target,status:'pending',why:'Üyelik başvurusu federasyon oylamasında.',updated:G.day};
 const keys=Object.keys(f.admissionResults);for(const k of keys.slice(0,-64))if(f.admissionResults[k].status!=='pending')delete f.admissionResults[k];
 if(typeof DiplomaticInbox!=='undefined'&&(v.target===0||f.members.includes(0))){
  const from=v.target===0?v.proposer:v.target;
  DiplomaticInbox.source('fedrequest','admission:'+f.id+':'+v.id,from,f.id,String(v.id),v.expires+180,'Federasyon üyeliği — '+f.name,'Üyelik başvurusu federasyon oylamasında.');
 }
}
function fedMotionOptions(kind,o){
 const out={kind};for(const k of ['target','sponsor','type','field','value','applicant'])if(o[k]!==undefined)out[k]=o[k];return out;
}
function canFedMotion(e,kind,options={},resolving=false){
 const M=Object.hasOwn(FED_MOTIONS,kind)&&FED_MOTIONS[kind],f=e&&findFed(e);
 if(!M||!e||G.emps[e.id]!==e||e.dead||e.wild||!f||fedOf(f.id)!==f||f.members.length<2)return {ok:false,why:'Geçerli federasyon üyesi ve karar gerekli'};
 if(!resolving){const aq=fedAgendaCheck(f,'motion','motion',fedMotionOptions(kind,options));if(!aq.ok)return aq;}
 if(!resolving&&(e.res.etk||0)<M.c)return {ok:false,why:M.c+' Etki gerekir'};
 const emergency=fedEmergencyId(f,e,kind,options);
 if(options.defenseFront&&emergency!==options.defenseFront)return {ok:false,why:'Savunma cephesi sona erdi veya aynı tarafların başka savaşı başladı'};
 const key=kind+':'+(options.target??options.type??options.field??'')+(emergency?':'+emergency:'');
 if(!resolving&&(f.requestAfter?.[key]||0)>G.day)return {ok:false,why:'Aynı öneri için bekleme süresi var'};
 const target=G.emps[options.target],live=[...new Set(f.members)].filter(id=>G.emps[id]&&!G.emps[id].dead);
 if(live.length<2)return {ok:false,why:'En az iki yaşayan üye gerekli'};
 if(kind==='admit'){
  if(!e.contact[target?.id])return {ok:false,why:'Adayla temas yok'};
  const gate=fedAdmissionGate(f,target,true);if(!gate.ok)return gate;
  if(f.invites?.[target.id]&&f.invites[target.id].expires>G.day)return {ok:false,why:'Adayın yanıtı bekleniyor'};
 }
 if(kind==='expel'&&(!target||target.dead||target.id===e.id||!live.includes(target.id)||live.length<3))return {ok:false,why:'İhraç için hedef dışındaki en az iki üye gerekir'};
 if(kind==='elect'&&(!target||target.dead||!f.members.includes(target.id)||target.id===f.leader))return {ok:false,why:'Başka bir yaşayan üye seç'};
 if(kind==='reform'){
  if(!Object.hasOwn(FED_TYPES,options.type)||options.type===(f.type||'askeri'))return {ok:false,why:'Farklı geçerli bir tür seç'};
  if(f.reform)return {ok:false,why:'Tür geçişi zaten sürüyor'};
  if(!resolving&&(f.reformAfter||0)>G.day)return {ok:false,why:'Son reformdan sonra 120 ay beklenir'};
 }
 if(kind==='charter'){
  const values={defense:['auto','vote'],offense:['auto','vote'],admission:['allies','contact'],ballot:['equal','hegemonic','economic','mixed']};
  if(!Object.hasOwn(values,options.field)||!values[options.field].includes(options.value)||fedCharter(f)[options.field]===options.value)return {ok:false,why:'Farklı geçerli anayasa kuralı seç'};
 }
 if(kind==='joinWar'||kind==='newWar'){
  if(!target||target.dead||target.wild||target.crisisSide||f.members.includes(target.id)||!e.contact[target.id])return {ok:false,why:'Bilinen yaşayan dış hedef gerekli'};
  const sponsor=G.emps[options.sponsor??e.id];
  if(!sponsor||sponsor.dead||!f.members.includes(sponsor.id)||kind==='joinWar'&&!sponsor.war[target.id]||kind==='newWar'&&e.war[target.id])return {ok:false,why:'Savaş veya desteklenen üye artık geçerli değil'};
  if(kind==='newWar'){const gate=canPromiseWarOn(e,target,true);if(!gate.ok)return gate;}
 }
 return {ok:true,fed:f,cost:M.c,key,...(emergency?{defenseFront:emergency}:{})};
}
function proposeFedMotion(e,kind,options={}){
 const q=canFedMotion(e,kind,options);if(!q.ok)return q;
 if(fedAgendaWaiting(q.fed))return fedAgendaEnqueue(q.fed,e,'motion','motion',fedMotionOptions(kind,options));
 if(q.defenseFront&&!FED_AGENDA_OPENING.has(q.fed)){const r=fedAgendaEnqueue(q.fed,e,'motion','motion',fedMotionOptions(kind,options));if(r.ok){fedAdvanceAgenda(q.fed);return {...r,queued:false,pending:!!q.fed.vote};}return r;}
 const result=fedChange(()=>{fedNormalize(q.fed);e.res.etk-=q.cost;q.fed.requestAfter=q.fed.requestAfter||{};q.fed.requestAfter[q.key]=G.day+(kind==='reform'?360:180);return fedOpenVote(q.fed,'motion',e,{...fedMotionOptions(kind,options),...(q.defenseFront?{defenseFront:q.defenseFront}:{})});});
 fedPresentVote(q.fed,result);return result;
}
function fedMotionLabel(v){
 const M=FED_MOTIONS[v.motion];if(!M)return null;
 const suffix=v.motion==='reform'?' — '+(FED_TYPES[v.type]?.n||'?'):v.motion==='charter'?' — '+v.field+' / '+v.value:'';
 return {n:M.n+suffix,ico:'🏛',d:v.motion==='reform'?'En az %75 üye onayı; 12 ay geçiş; 120 ay reform beklemesi. Yeni yükümlülükler eski savaşlara uygulanmaz.':v.motion==='charter'?'En az %75 üye onayı. Yeni saldırı yükümlülüğü yalnız açıkça onay veren üyeye uygulanır.':v.motion==='expel'?'Hedef oy kullanamaz. Kalan seçmenlerin mutlak çoğunluğu gerekir.':'Uygun üyelerin mutlak çoğunluğu gerekir. Üyelikte adayın ayrıca kabulü; savaşta ayrıca uygulama gerekir.'};
}
function fedApplyMotion(f,v,c){
 if(v.motion==='admit'){
  f.invites[v.target]={expires:G.day+180,terms:fedCharterKey(f),by:v.proposer,vote:String(v.id),admission:'vote'};
  const o=G.emps[v.target];
  fedAdmissionResult(f,v.id,'pending','Üye oylaması kabul edildi; adayın yükümlülükleri kabul etmesi bekleniyor.');
  if(o.ai){const q=aiFedWilling(o,G.emps[v.proposer],f.type,f);if(q.ok)acceptFedInvite(o,f.id);else rejectFedInvite(o,f.id,q.why);}
 }
 if(v.motion==='expel')fedRemoveMember(f,v.target,'expel');
 if(v.motion==='elect'){f.leader=v.target;for(const fl of G.fleets)if(fl.federal&&fl.fedId===f.id)fl.e=v.target;}
 if(v.motion==='reform'){f.reform={type:v.type,at:G.day+360,defaultDefense:fedCharter(f).defense===fedDefaultCharter(f.type).defense};f.reformAfter=G.day+3600;}
 if(v.motion==='charter'){
  const before={defense:fedDuty(f,'defense'),offense:fedDuty(f,'offense')};f.charter={...fedCharter(f),[v.field]:v.value};if(v.field==='ballot'){f.politicsVersion=96;fedRefreshRepresentation(f,true);}fedSyncDuties(f,before);
  if(v.field==='offense')for(const id of f.members)f.dutyConsent[id]={offense:v.value==='auto'&&v.yes.includes(id),since:G.day};
 }
 if(v.motion==='joinWar'||v.motion==='newWar')f.decisions[fedVoteToken(v)]={id:fedVoteToken(v),kind:v.motion,sponsor:v.sponsor??v.proposer,target:v.target,by:v.proposer,...(v.defenseFront?{defenseFront:v.defenseFront}:{}),approved:v.yes.filter(id=>c.eligible.includes(id)),expires:G.day+180,state:'ready'};
 fedPoliticalRecord(f,'motion',{kind:v.motion,target:v.target,type:v.type});
}
function fedSupportGate(e,target,voluntary=true){
 if(!e||!target||e.dead||target.dead||e===target||e.war[target.id]||e.ally[target.id]||sovereignPair(e,target)||(e.nap?.[target.id]||0)>G.day)return {ok:false,why:'Savaş, müttefiklik, saldırmazlık veya vasallık koşulu değişti'};
 if(hasCivic(e,'shadow')||hasCivic(e,'universal')||voluntary&&councilBlocksWar(e,target))return {ok:false,why:'Doktrin veya Konsey savaş engeli'};
 return voluntary?canPromiseWarOn(e,target,true):{ok:true};
}
function fedJoinSide(f,e,target,sponsor){
 if(!fedSupportGate(e,target).ok)return false;
 f.warPermits=f.warPermits||{};const key=e.id+'>'+target.id,old=f.warPermits[key];f.warPermits[key]={by:e.id,target:target.id,expires:G.day+1,collective:true};
 const auth=G._warAuth,why=G._warWhy;let ok=false;
 try{warAuthorize(e,target,{n:'Federasyonun kabul edilmiş savaş kararı'});ok=declareWar(e,target,{sponsor,enemy:target.id,kind:'federation'});}finally{G._warAuth=auth;G._warWhy=why;if(!ok){if(old)f.warPermits[key]=old;else delete f.warPermits[key];}}
 return ok;
}
function executeFedDecision(e,fid,id){
 const f=fedOf(fid),d=f?.decisions?.[id];
 if(!f||!e||!f.members.includes(e.id)||!d||d.state!=='ready'||d.expires<=G.day||!(e.id===d.by||e.id===f.leader))return {ok:false,why:'Karar veya uygulama yetkisi geçerli değil'};
 const target=G.emps[d.target],sponsor=G.emps[d.sponsor];
 if(d.defenseFront&&fedEmergencyId(f,e,'joinWar',{target:d.target,sponsor:d.sponsor})!==d.defenseFront)return {ok:false,why:'Acil savunma kaynağı artık geçerli değil'};
 if(!target||target.dead||f.members.includes(target.id)||!sponsor||sponsor.dead||!f.members.includes(sponsor.id)||d.kind==='joinWar'&&!sponsor.war[target.id])return {ok:false,why:'Savaş veya desteklenen üye artık geçerli değil'};
 const participants=d.approved.filter(id=>f.members.includes(id)&&G.emps[id]&&!G.emps[id].dead);
 let joined=[];
 if(d.kind==='newWar'){
  const actor=G.emps[d.by];if(!participants.includes(actor.id)||!fedSupportGate(actor,target).ok||!aiFedHelp(actor,target,true))return {ok:false,why:'Önerenin savaş koşulları değişti'};
  if(fedJoinSide(f,actor,target,actor.id))joined.push(actor.id);else return {ok:false,why:'Savaş ilanı uygulanamadı'};
 }
 const blocked=[];for(const id2 of participants){const member=G.emps[id2];if(member.war[target.id])continue;if(!aiFedHelp(member,target,true)){blocked.push({id:id2,why:'Bilinen ulaşabilir askerî yardım rotası yok'});continue;}if(fedJoinSide(f,member,target,d.sponsor))joined.push(id2);}
 d.blocked=blocked;if(!joined.length&&participants.some(id=>!G.emps[id].war[target.id]))return {ok:false,why:'Geçerli ve ulaşabilir katılımcı kalmadı',blocked};
 if(e.id===0&&typeof DiplomaticInbox!=='undefined')DiplomaticInbox.settleSource('decision',fid,id,'accepted');
 d.state='applied';d.applied=G.day;d.joined=joined;fedPoliticalRecord(f,'warDecision',{target:d.target,joined});return {ok:true,joined};
}
function fedAttack(a,b,support){
 if(support)return;const f=findFed(a);if(!f||!fedDuty(f,'offense')||G.day<(f.dutySince?.offense||0))return;
 for(const id of f.members)if(id!==a.id&&f.dutyConsent?.[id]?.offense)fedJoinSide(f,G.emps[id],b,a.id);
}

function findFed(e){
  if (!G.feds) return null;
  return G.feds.find(f => f.members.includes(e.id)) || null;
}
function fedOf(id){
  if (!G.feds) return null;
  return G.feds.find(f => f.id === id) || null;
}
function fedName(random,type='askeri'){
 const stream=random||mulberry32(identityHash('fed-name:'+G.seed+':'+(G.fedUid||0)));
 const take=xs=>xs[Math.floor(stream()*xs.length)];
 const root=take(['Aster','Zenit','Meridyen','Vega','Ufuk','Ekinoks','Kutupyıldızı','Aurora','Orion','Helis','Nova','Eos']);
 const forms={askeri:['Savunma Paktı','Muhafız Birliği','Yıldız Kalkanı','Ortak Cephe'],bilimsel:['Keşif Birliği','Bilgi Topluluğu','Araştırma Konseyi','Gözlemevleri Ağı'],ticaret:['Ticaret Ligi','Serbest Limanlar','Refah Birliği','Yollar Konsorsiyumu'],yagmaci:['Akın Birliği','Yağma Paktı','Korsan Avcıları','Savaş Ortaklığı']};
 return uniqueIdentityName(root+' '+take(forms[type]||forms.askeri),Object.fromEntries((G.feds||[]).map(f=>[f.name,1])));
}

/* Oyuncu/AI kendi federasyonunu kurabilir: müttefikleri davet eder,
   üyeler otomatik birbirine müttefik olur. Etki maliyeti vardır. */
/* BETA-FED-FOUND.0: immutable, explicit founding consent. Existing member
   admission and AI-only autonomous founding keep their own paths. */
function fedFoundHuman(e){return !!e&&(e.ai===false||e===G.p&&e.ai!==true||typeof __mpHumanVoter==='function'&&__mpHumanVoter(e.id));}
function fedFoundState(){return G.fedFounding||(G.fedFounding={v:1,next:1,proposals:[]});}
function fedFoundTerms(p){return p.type+'|'+p.ballot+'|'+p.members.join(',')+(p.revision?'|r'+p.revision:'');}
function fedFoundGet(id){return G.fedFounding?.proposals.find(p=>p.id===+id)||null;}
function fedFoundCandidate(e,o){
  const reasons=[];
  if(!e||!o||o===e||o.dead||o.wild||o.crisisSide||isVassal(o)||isPurifier(o))reasons.push('Bağımsız, yaşayan ve uygun ortak gerekli');
  else{
    if(findFed(o))reasons.push('Başka federasyonun üyesi');
    if(!e.contact[o.id]||!o.contact[e.id])reasons.push('Karşılıklı temas gerekli');
    if(!e.ally[o.id]||!o.ally[e.id])reasons.push('Karşılıklı ittifak gerekli');
    if(e.war[o.id]||o.war[e.id])reasons.push('Kurucuyla savaşta');
    if((o._fedLeaveUntil||0)>G.day)reasons.push('Federasyondan ayrılış beklemesi sürüyor');
  }
  return {ok:!reasons.length,why:reasons.join(' · ')};
}
function fedFoundRead(fn){
  const objects=[G,...G.emps,...G.fleets,...G.sys],saved=objects.map(o=>Object.fromEntries(Object.keys(o).filter(k=>k.startsWith('_')).map(k=>[k,Object.getOwnPropertyDescriptor(o,k)])));
  try{return fn();}finally{objects.forEach((o,i)=>{for(const k of Object.keys(o))if(k.startsWith('_')&&!Object.hasOwn(saved[i],k))delete o[k];for(const [k,d]of Object.entries(saved[i]))Object.defineProperty(o,k,d);});}
}
function fedFoundQuote(e,type,ballot,selected){return fedFoundRead(()=>fedFoundQuoteRaw(e,type,ballot,selected));}
function fedFoundQuoteRaw(e,type,ballot,selected){
  const reasons=[],members=[e?.id,...(Array.isArray(selected)?selected:[])],cost=e?fedFoundCost(e):220;
  if(!e||G.emps[e.id]!==e||e.dead||e.wild||e.crisisSide||isVassal(e)||isPurifier(e)||findFed(e)||(e._fedLeaveUntil||0)>G.day)reasons.push('Kurucu bağımsız ve federasyonsuz olmalı');
  if(!Object.hasOwn(FED_TYPES,type)||!Object.hasOwn(FED_BALLOTS,ballot)||ballot==='weighted')reasons.push('Geçerli tür ve oy rejimi gerekli');
  if(!Array.isArray(selected)||selected.length>48||new Set(members).size!==members.length||members.some(id=>!Number.isInteger(id)||!G.emps[id]))reasons.push('Geçerli, benzersiz kurucu listesi seç');
  const humans=members.filter(id=>fedFoundHuman(G.emps[id])).length,min=humans>=2?2:3;
  if(members.length<min)reasons.push(humans>=2?'En az iki açık rızalı insan kurucu gerekli':'Tek insanlı kuruluşta en az iki AI ortak gerekli');
  if(e&&(e.res.etk||0)<cost)reasons.push(cost+' Etki gerekli');
  const candidates=e?G.emps.filter(o=>o!==e&&!o.wild&&!o.crisisSide&&e.contact[o.id]).map(o=>({id:o.id,h:fedFoundHuman(o),...fedFoundCandidate(e,o)})):[];
  if(Object.hasOwn(FED_TYPES,type)&&Object.hasOwn(FED_BALLOTS,ballot))for(const c of candidates)if(c.ok&&!c.h){const a=fedFoundAssessment({...G.emps[c.id]},e,{type,ballot,members:[...new Set([...members,c.id])].filter(id=>G.emps[id]&&(id===e.id||e.contact[id]))});const ids=[...new Set([...members,c.id])].filter(id=>G.emps[id]&&(id===e.id||e.contact[id])),regime=aiFedRegimeScore({...G.emps[c.id]},ballot,ids);c.approach='Tür: '+(aiFedAffinity(G.emps[c.id],type)>=.5?'Olumlu':'Çekinceli')+' · Oy rejimi: '+(regime.score>=.5?'Olumlu':'Çekinceli')+' · '+(a.ok?'Genel kabul eğilimi: ':'Genel ret eğilimi: ')+a.why;}
  for(const id of Array.isArray(selected)?selected:[]){const q=candidates.find(x=>x.id===id);if(!q?.ok)reasons.push((e?.contact[id]?G.emps[id]?.name:'Bilinmeyen aday')+': '+(q?.why||'Uygun aday değil'));}
  if(members.every(id=>id===e?.id||e?.contact[id]))for(const a of members)for(const b of members)if(a!==b&&G.emps[a]?.war[b])reasons.push('Seçilen kurucular birbiriyle savaşta');
  return {ok:!reasons.length,why:reasons.join(' · '),reasons,candidates,cost,members,min};
}
function fedFoundAssessment(o,e,p){
  const q=fedFoundCandidate(e,o);if(!q.ok)return q;
  if(fedFoundHuman(o))return {ok:false,why:'İnsan oyuncunun açık yanıtı bekleniyor'};
  if(p.type==='yagmaci'&&warPreparationState(warPreparation(o.aiStrategy?.coalition?.plan)||{state:'none'})==='pending')return {ok:false,why:'Devam eden koşullu savaş taahhüdü önce sonuçlanmalı'};
  // Existing strategic evaluator; all selected peers contribute through its
  // existing admission / regime / known-power logic. No new strategic RNG.
  for(const id of p.members)if(id!==o.id&&(o.war[id]||(o.rel[id]||0)<-35))return {ok:false,why:'Kurucular arasındaki savaş veya düşmanlık uygun değil'};
  return aiFedWilling(o,e,p.type,{members:p.members,cohesion:70,type:p.type,charter:{...fedDefaultCharter(p.type),ballot:p.ballot}},p.ballot,p.members);
}
function fedFoundValid(p){
  if(!p||p.status!=='pending')return {ok:false,why:'Kuruluş süreci artık beklemiyor'};
  if(G.day>=p.expires)return {ok:false,why:'Kuruluş davetinin süresi doldu'};
  return fedFoundQuote(G.emps[p.by],p.type,p.ballot,p.members.filter(id=>id!==p.by));
}
function fedFoundPropose(e,type,ballot,selected){
  const q=fedFoundQuote(e,type,ballot,selected);if(!q.ok)return q;
  const st=fedFoundState(),members=[e.id,...selected.slice().sort((a,b)=>a-b)];
  const old=st.proposals.find(p=>p.status==='pending'&&p.by===e.id);if(old)return {ok:false,why:'Önce mevcut kuruluş sürecini iptal et'};
  if(st.proposals.filter(p=>p.status==='pending').length>=16)return {ok:false,why:'Bekleyen kuruluş sınırına ulaşıldı'};
  const p={id:st.next++,by:e.id,type,ballot,members,opened:G.day,expires:G.day+150,status:'pending',replies:{}};
  p.replies[e.id]={status:'accepted',terms:fedFoundTerms(p),day:G.day,why:'Kuruluş şartlarını önerdi'};
  for(const id of members)if(id!==e.id){const o=G.emps[id];const a=fedFoundHuman(o)?null:fedFoundAssessment(o,e,p);p.replies[id]={terms:fedFoundTerms(p),status:a?(a.ok?'accepted':'rejected'):'pending',day:G.day,why:a?String(a.why).slice(0,300):'İnsan yanıtı bekleniyor'};}
  st.proposals.push(p);st.proposals=st.proposals.filter(x=>x.status==='pending').concat(st.proposals.filter(x=>x.status!=='pending').slice(-48));
  return {ok:true,id:p.id};
}
function fedFoundReply(e,id,accept,revision=0){
  const p=fedFoundGet(id);
  if(!p||revision!==(p.revision||0)||!fedFoundHuman(e)||e.id===p.by||!p.members.includes(e.id)||p.replies[e.id]?.status!=='pending')return {ok:false,why:'Bu davet için yanıt yetkisi yok veya karar verilmiş'};
  const q=fedFoundValid(p);if(!q.ok)return {ok:false,why:G.day>=p.expires?'Kuruluş davetinin süresi doldu':'Kurucu veya ortakların kuruluş koşulları değişti'};
  p.replies[e.id]={terms:fedFoundTerms(p),status:accept?'accepted':'rejected',day:G.day,why:accept?'Kuruluş şartlarını açıkça kabul etti':'Kuruluş davetini reddetti'};
  return {ok:true};
}
function fedFoundCancel(e,id){const p=fedFoundGet(id);if(!p||p.by!==e.id||p.status!=='pending')return {ok:false,why:'İptal yetkisi yok'};p.status='cancelled';p.finished=G.day;return {ok:true};}
function fedFoundFinish(e,id,revision=0){
  const p=fedFoundGet(id);if(!p||p.by!==e.id||revision!==(p.revision||0))return {ok:false,why:'Son kuruluş onayı yalnız öneren kurucunun güncel şartlarla'};
  const q=fedFoundValid(p);if(!q.ok)return q;
  for(const member of p.members)if(p.replies[member]?.status!=='accepted'||p.replies[member].terms!==fedFoundTerms(p))return {ok:false,why:'Seçilen bütün kurucuların güncel kabulü gerekli'};
  return foundFederation(e,p.type,p.ballot,p.id);
}
function fedFoundTick(){
  for(const p of G.fedFounding?.proposals||[])if(p.status==='pending'){
    const q=fedFoundValid(p);if(!q.ok){p.status=G.day>=p.expires?'expired':'invalid';p.why=q.why;p.finished=G.day;}
  }
}
function fedFoundRestore(raw){
  if(!raw||raw.v!==1||!Number.isSafeInteger(raw.next)||!Array.isArray(raw.proposals)||raw.proposals.length>64)return null;
  const out={v:1,next:Math.max(1,raw.next),proposals:[]},seen=new Set();
  for(const p of raw.proposals){if(!p||!Number.isSafeInteger(p.id)||p.id<1||seen.has(p.id)||!Object.hasOwn(FED_TYPES,p.type)||!Object.hasOwn(FED_BALLOTS,p.ballot)||p.ballot==='weighted'||!Array.isArray(p.members)||p.members.length<2||p.members.length>49||new Set(p.members).size!==p.members.length||!p.members.includes(p.by)||p.members.some(id=>!Number.isInteger(id)||!G.emps[id])||!Number.isFinite(p.opened)||!Number.isFinite(p.expires)||p.expires<=p.opened||!['pending','founded','cancelled','expired','invalid'].includes(p.status))continue;
    const replies={};for(const id of p.members){const r=p.replies?.[id];if(r&&['pending','accepted','rejected'].includes(r.status)&&Number.isFinite(r.day))replies[id]=p.revision?fedFoundCleanReply(r):{status:r.status,terms:String(r.terms||'').slice(0,400),day:r.day,why:String(r.why||'').slice(0,300)};}
    const extension=fedFoundRestoreEdits(p);if(!extension)continue;
    seen.add(p.id);out.proposals.push({id:p.id,by:p.by,type:p.type,ballot:p.ballot,members:p.members.slice(),opened:p.opened,expires:p.expires,status:p.status,replies,...extension,...(Number.isInteger(p.fid)?{fid:p.fid}:{}),...(Number.isFinite(p.finished)?{finished:p.finished}:{}),...(typeof p.why==='string'?{why:p.why.slice(0,600)}:{})});out.next=Math.max(out.next,p.id+1);
  }
  return out;
}

function fedFoundCost(e){
  return hasCivic(e,'council') ? 130 : 220;
}
function fedFounderCandidate(e,o,type,ballot='equal',founders=null){
  const reasons=[];
  if(!o||o===e||o.dead||o.wild||o.crisisSide||isPurifier(o)||isVassal(o))reasons.push('Bağımsız ve uygun devlet gerekli');
  else {
    if(findFed(o))reasons.push('Başka federasyonun üyesi');
    if(!e.contact[o.id]||!o.contact[e.id])reasons.push('Karşılıklı diplomatik temas gerekli');
    if(!e.ally[o.id]||!o.ally[e.id])reasons.push('Karşılıklı ittifak gerekli');
    if(e.war[o.id]||o.war[e.id])reasons.push('Kurucuyla savaşta');
    if((o._fedLeaveUntil||0)>G.day)reasons.push('Ayrılış beklemesi: '+Math.ceil((o._fedLeaveUntil-G.day)/30)+' ay');
    if(e.id!==0&&o.id===0)reasons.push('Oyuncunun açık üyelik onayı gerekli');
    if(!reasons.length){const consent=aiFedWilling(o,e,type,null,ballot,founders);if(!consent.ok)reasons.push(consent.why);}
  }
  return {ok:!reasons.length,reasons,why:reasons.join(' · ')};
}
function canFoundFed(e,type='askeri',ballot='equal'){
  if(!Object.hasOwn(FED_BALLOTS,ballot)||ballot==='weighted')return {ok:false,why:'Geçerli yeni oy rejimi seç',reasons:['Geçerli yeni oy rejimi seç'],allies:[],candidates:[],cost:e?fedFoundCost(e):220};
  const founders=[e?.id,...G.emps.filter(o=>o!==e&&e?.ally?.[o.id]&&e.contact?.[o.id]&&!o.dead&&!o.wild).map(o=>o.id)];
  const reasons=[],allies=[],candidates=[],valid=!!e&&G.emps[e.id]===e;
  const cost=valid?fedFoundCost(e):220;
  if(!valid||e.dead||e.wild||e.crisisSide||isPurifier(e)||isVassal(e)||!Object.hasOwn(FED_TYPES,type))
    return {ok:false,why:'Kurucu ve tür uygun değil',reasons:['Kurucu ve tür uygun değil'],allies,candidates,cost};
  if(findFed(e))reasons.push('Zaten bir federasyonun var.');
  if((e._fedLeaveUntil||0)>G.day)reasons.push('Ayrılış sonrası 24 ay bekleme sürüyor');
  for(const o of G.emps)if(o!==e&&!o.dead&&!o.wild&&e.contact[o.id]&&e.ally[o.id]){
    const q=fedFounderCandidate(e,o,type,ballot,founders);candidates.push({id:o.id,...q});if(q.ok)allies.push(o);
  }
  if(allies.length<2)reasons.push('En az 2 bağımsız, kabul eden AI müttefik gerekir (şu an '+allies.length+').');
  if((e.res.etk||0)<cost)reasons.push(cost+' Etki gerekir (mevcut '+Math.floor(e.res.etk||0)+').');
  if(allies.some(a=>allies.some(b=>a!==b&&(a.war[b.id]||b.war[a.id]))))reasons.push('Kurucu adayları birbiriyle savaşta');
  return {ok:!reasons.length,why:reasons.join(' · '),reasons,allies,candidates,cost};
}
function foundFederation(e,type='askeri',ballot='equal',proposalId=null){
  const proposal=proposalId===null?null:fedFoundGet(proposalId);
  if(fedFoundHuman(e)&&!proposal)return {ok:false,why:'Önce seçilen ortaklara kuruluş daveti gönder ve açık kabulleri topla'};
  if(proposal&&(proposal.by!==e.id||proposal.type!==type||proposal.ballot!==ballot||proposal.members.some(id=>proposal.replies[id]?.status!=='accepted'||proposal.replies[id].terms!==fedFoundTerms(proposal))))return {ok:false,why:'Kuruluş rızası geçersiz'};
  const q=proposal?fedFoundValid(proposal):canFoundFed(e,type,ballot);if(!q.ok)return q;
  if(proposal)for(const id of proposal.members)if(id!==e.id&&!fedFoundHuman(G.emps[id])){const a=fedFoundAssessment(G.emps[id],e,proposal);if(!a.ok)return {ok:false,why:a.why};}
  const result=fedChange(()=>{
  const members=proposal?proposal.members.slice():[e.id,...q.allies.map(o=>o.id)];e.res.etk-=q.cost;
  const f={id:(G.fedUid=(G.fedUid||0)+1),name:fedName(null,type),type,charter:{...fedDefaultCharter(type),ballot},politicsVersion:96,leader:e.id,founder:e.id,
    members,laws:{},treasury:0,fund:{ala:0,ene:0},nextVote:G.day+60,vote:null,founded:G.day,typeSince:G.day,
    dutySince:{defense:G.day,offense:G.day},defenseFrontCutoff:G.warLedger?.next||1,dutyConsent:{},invites:{},decisions:{},cohesion:70};
  G.feds=G.feds||[];G.feds.push(f);federationIdentity(f);
  for(const id of members){f.dutyConsent[id]={offense:false,since:G.day};for(const peer of members)if(id!==peer){
    const a=G.emps[id],b=G.emps[peer];a.ally[peer]=true;a.contact[peer]=true;clearBilateralEmbargo(a,b);a.rel[peer]=Math.max(a.rel[peer]||0,45);}}
  fedRefreshRepresentation(f,true);fedPoliticalRecord(f,'founded',{type,ballot});for(const id of members)recalcMods(G.emps[id]);
  if(typeof facEvent==='function')facEvent(e,'ally');if(proposal){proposal.status='founded';proposal.fid=f.id;proposal.finished=G.day;}return {ok:true,fed:f};
  });
  if(result.ok&&result.fed.members.includes(0))say('FEDERASYON KURULDU — '+result.fed.name+' · '+fedType(result.fed).n,'win');
  return result;
}
/* Maintenance only: no silent founding or admission from alliance topology. */
function updateFederations(){
  G.feds=G.feds||[];const occupied=new Set();
  for(const f of [...G.feds]){
    if(!f||!Array.isArray(f.members)){G.feds=G.feds.filter(x=>x!==f);continue;}
    const before=f.members.slice();
    f.members=[...new Set(f.members)].filter(id=>G.emps[id]&&!G.emps[id].dead&&!occupied.has(id));
    fedNormalize(f);
    for(const id of f.members.slice()){
      const e=G.emps[id],others=f.members.filter(x=>x!==id);
      if(others.some(x=>e.war[x])||others.length&&!others.some(x=>e.ally[x]&&G.emps[x].ally[id]))fedRemoveMember(f,id,'bondLost');
    }
    if(f.members.length<2){fedDissolve(f);continue;}
    f.members.forEach(id=>occupied.add(id));fedNormalize(f);fedReformTick(f);fedRefreshRepresentation(f);
    for(const id of before)if(!f.members.includes(id)&&G.emps[id]&&!G.emps[id].dead)recalcMods(G.emps[id]);
    for(const [id,inv]of Object.entries(f.invites))if(!G.emps[id]||G.emps[id].dead||inv.expires<=G.day||findFed(G.emps[id])||inv.terms!==fedCharterKey(f)){
      fedAdmissionResult(f,inv.vote,inv.expires<=G.day?'expired':'invalid',inv.expires<=G.day?'Davetin süresi doldu.':'Aday veya federasyon yükümlülükleri değişti.');delete f.invites[id];
    }
    for(const [id,d]of Object.entries(f.decisions))if(d.expires<=G.day){fedPoliticalRecord(f,'decisionExpired',{id});delete f.decisions[id];}
    fedPruneWarPermits(f);
  }
}

/* GÜVENLİK AĞI: ittifak ve savaş aynı anda var olamaz.
   Herhangi bir yol bu çelişkiyi üretirse ay tikinde temizlenir. */
function fixDiploConflicts(){
  for (const a of G.emps){
    if (a.dead || a.wild) continue;
    for (const b of G.emps){
      if (b.dead || b.wild || b.id === a.id) continue;
      if (a.ally[b.id] && a.war[b.id]){
        // ittifak kazanır: savaş iptal
        a.war[b.id] = false; b.war[a.id] = false;
        warLedgerSync('alliance-conflict',null);
        a.peaceAt = a.peaceAt || {}; b.peaceAt = b.peaceAt || {};
        a.peaceAt[b.id] = G.day; b.peaceAt[a.id] = G.day;
        if (a.id === 0 || b.id === 0)
          say('İttifak savaşı geçersiz kıldı — ' + (a.id===0?b.name:a.name), 'win');
      }
      // tek yönlü ittifak da düzeltilir
      if (a.ally[b.id] !== b.ally[a.id]){
        const v = a.ally[b.id] && b.ally[a.id];
        a.ally[b.id] = v; b.ally[a.id] = v;
      }
    }
  }
}

/* federasyon yasalarının etkileri */
function fedTick(){
  fedFoundTick();
  fixDiploConflicts();
  updateFederations();
  if(typeof aiFederationPolitics==='function')aiFederationPolitics();
  if (!G.feds) return;
  for (const f of G.feds){
    // ortak filo bağışı
    if (f.laws.filo){
      for (const id of f.members){
        const e = G.emps[id];
        if (!e || e.dead) continue;
        const give = Math.min(4, e.res.ala);
        e.res.ala -= give; f.treasury += give;
      }
    }
    // ortak araştırma fonu
    if (f.laws.arastirma){
      let pool = 0;
      for (const id of f.members){
        const e = G.emps[id];
        if (!e || e.dead) continue;
        const cut = (e.inc.ara || 0) * .10;
        pool += cut;
      }
      const share = pool / Math.max(1, f.members.length);
      for (const id of f.members){
        const e = G.emps[id];
        if (e && !e.dead) e.res.ara += share;
      }
    }
    // oylama zamanı
    if (f.vote) finishFedVote(f);
    fedAdvanceAgenda(f);
    if (!f.vote && G.day >= f.nextVote){
      startFedVote(f);
    }
  }
}

/* 91E: tek gündem, sabit seçmen listesi, açık oyuncu oyu. Eski v8
   gündemleri kimliksiz okunabilir; salt sorgular kayıt/RNG değiştirmez. */
function fedHasLaw(e, key){
  const f = e && findFed(e);
  return !!(f && f.laws && f.laws[key]);
}
/* 91E.1: izin yalnız tek saldırgan/hedef çiftine aittir. Savunma tespiti
   metin etiketine değil, o savaşın başlangıcında kaydedilen role dayanır. */
function fedDefensiveWar(a, b){
  if (!a || !b) return false;
  const f = findFed(a);
  return G.emps.some(v => {
    if (!v || v.dead || !v.war[b.id]) return false;
    const d = v.warDefense && v.warDefense[b.id];
    if (!d || !d.defensive || d.since !== (v.warSince && v.warSince[b.id])) return false;
    const front=warLedgerFind(v.id,b.id);
    const federationDuty = f && fedDuty(f,'defense') && f.members.includes(v.id) && (v.warSince?.[b.id]??-Infinity)>=(f.dutySince?.defense||0) && (!f.defenseFrontCutoff||front&&front.id>=f.defenseFrontCutoff);
    const subjectDuty = v.overlord === a.id && vassalDuty(v,'protect') ||
      (a.overlord != null && vassalDuty(a,'join',b) && (a.overlord===v.id||a.overlord===v.overlord));
    return !!(federationDuty || subjectDuty);
  });
}
function fedWarAllowed(a, b){
  if (!a || !b) return false;
  const f = findFed(a);
  if (!f || !f.laws || !f.laws.savasOnay || a.war[b.id] || b.wild || b.crisisSide) return true;
  if (fedDefensiveWar(a,b)) return true;
  const p = f.warPermits && f.warPermits[a.id + '>' + b.id];
  return !!(p && p.expires > G.day && p.by === a.id && p.target === b.id &&
    f.members.includes(a.id) && !f.members.includes(b.id));
}
function fedPruneWarPermits(f){
  for (const key of Object.keys(f.warPermits || {})){
    const p = f.warPermits[key];
    if ((!f.laws.savasOnay && !p.collective) || p.expires <= G.day || !f.members.includes(p.by) ||
        f.members.includes(p.target) || !G.emps[p.target] || G.emps[p.target].dead ||
        !G.emps[p.by] || G.emps[p.by].dead) delete f.warPermits[key];
  }
}
function canFedWarRequest(a, b, resolving = false){
  if (!a || G.emps[a.id] !== a || a.dead || !b || G.emps[b.id] !== b || b.dead)
    return {ok:false, why:'Geçerli üye ve hedef gerekli'};
  const f = findFed(a);
  if (!f || !f.laws || !f.laws.savasOnay) return {ok:false, why:'Savaş Onayı yasası yürürlükte değil'};
  if (f.members.includes(b.id)) return {ok:false, why:'Federasyon üyesine saldırı izni istenemez'};
  if (a.war[b.id] || b.war[a.id]) return {ok:false, why:'Savaş zaten sürüyor'};
  if (a.ally[b.id]) return {ok:false, why:'Hedef müttefikin; önce ittifakı yönet'};
  if (hasCivic(a,'universal')) return {ok:false, why:'Doktrinin savaş ilanını yasaklıyor'};
  const base = canPromiseWarOn(a,b,true);
  if (!base.ok) return base;
  if (!resolving){
    if (fedWarAllowed(a,b)) return {ok:false, why:'Geçerli izin veya savunma hakkın var'};
    const aq=fedAgendaCheck(f,'war','warPermit',{target:b.id,sponsor:a.id});if(!aq.ok)return aq;
    if ((f.warRequestAfter && f.warRequestAfter[a.id + '>' + b.id] || 0) > G.day)
      return {ok:false, why:'Aynı savaş izni yeniden önerilmeden önce 90 gün beklenir'};
  }
  return {ok:true, fed:f};
}
function proposeFedWar(a, b){
  const gate = canFedWarRequest(a,b);
  if (!gate.ok) return gate;
  const f = gate.fed;
  if(fedAgendaWaiting(f))return fedAgendaEnqueue(f,a,'war','warPermit',{target:b.id,sponsor:a.id});
  const result = fedChange(() => {
    f.warRequestAfter = f.warRequestAfter || {};
    f.warRequestAfter[a.id + '>' + b.id] = G.day + 90;
    return fedOpenVote(f, 'warPermit', a, {target:b.id});
  });
  fedPresentVote(f, result);
  return result;
}
function fedVoteLaw(v){
  if (!v) return null;
  if(v.kind==='motion')return fedMotionLabel(v);
  if (v.kind === 'war') return {n:'Savaş İzni', ico:'⚔', d:'Yalnız öneren üyenin seçilen hedefe bir kez savaş ilan etmesine izin verir. Kabul sonrası 180 gün içinde kullanılmalıdır; savaş kendiliğinden başlamaz.'};
  if (Object.prototype.hasOwnProperty.call(FED_INNER_LAWS, v.law)) return FED_INNER_LAWS[v.law];
  return Object.prototype.hasOwnProperty.call(FED_LAWS, v.law) ? FED_LAWS[v.law] : null;
}
function fedVoteToken(v){ return v ? String(v.id || ('legacy:' + v.law)) : ''; }
function fedVoteCounts(f){
  const v = f.vote || {}, seen = new Set();
  const eligible = [...new Set(v.eligible || f.members)].filter(id =>
    f.members.includes(id) && G.emps[id] && !G.emps[id].dead && !(v.kind==='motion'&&v.motion==='expel'&&id===v.target));
  const raw=v.ballotSnapshot?.weights||fedLiveWeights(f,eligible),weights=Object.fromEntries(eligible.map(id=>[id,Number.isFinite(raw[id])&&raw[id]>=1&&raw[id]<=2?raw[id]:1]));
  let yes = 0, no = 0;
  for (const [list, positive] of [[v.yes || [], true], [v.no || [], false]]){
    for (const id of list){
      if (!eligible.includes(id) || seen.has(id)) continue;
      seen.add(id);
      const weight = Number.isFinite(weights[id])&&weights[id]>=1&&weights[id]<=2?weights[id]:1;
      if (positive) yes += weight; else no += weight;
    }
  }
  return {yes:Math.round(yes*1000)/1000,no:Math.round(no*1000)/1000,weights,total:eligible.reduce((n,id)=>n+(weights[id]||1),0),eligible,voted:[...seen],waiting:eligible.filter(id => !seen.has(id))};
}
function fedChange(fn){
  const tx = dealTxBegin();
  try { return fn(); }
  catch (err){
    dealTxRollback(tx);
    sideBufferError('yasa işlemi', err, 'fed-transaction');
    return {ok:false, why:'Oylama uygulanamadı; önceki durum korundu'};
  }
}
function fedResolveVote(f){
  const v = f.vote, c = fedVoteCounts(f);
  if (c.waiting.length && !(Number.isFinite(v.expires) && G.day >= v.expires))
    return {ok:true, pending:true};
  const warGate = v.kind === 'war' ? canFedWarRequest(G.emps[v.proposer], G.emps[v.target], true) : {ok:true};
  if (v.kind === 'war' && warGate.ok && warGate.fed !== f){ warGate.ok = false; warGate.why = 'Öneren üye federasyondan ayrıldı'; }
  const motionGate=v.kind==='motion'?canFedMotion(G.emps[v.proposer],v.motion,v,true):{ok:true};
  if(motionGate.ok&&v.kind==='motion'&&motionGate.fed!==f){motionGate.ok=false;motionGate.why='Öneren üye ayrıldı';}
  const yesHeads=c.eligible.filter(id=>v.yes.includes(id)).length;
  const modern=v.ballotSnapshot?.modern;
  const quorum=v.kind==='motion'?(v.motion==='reform'||v.motion==='charter'?Math.ceil(c.eligible.length*.75):Math.floor(c.eligible.length/2)+1):modern?Math.floor(c.eligible.length/2)+1:0;
  const weightQuorum=!modern||(v.kind==='motion'&&['reform','charter'].includes(v.motion)?c.yes+1e-8>=c.total*.75:c.yes>c.total/2+1e-8);
  const passed = warGate.ok && motionGate.ok && weightQuorum && c.yes > c.no && c.eligible.length > 0 && yesHeads>=quorum;
  f.lastVote = {id:fedVoteToken(v), law:v.law, kind:v.kind || 'basic',
    reasons:v.reasons,assessments:v.assessments,ballotSnapshot:v.ballotSnapshot,rule:fedVoteRule(f,c),proposer:v.proposer, target:v.target, sponsor:v.sponsor, motion:v.motion,type:v.type,field:v.field,value:v.value, repeal:!!v.repeal, invalid:!warGate.ok?warGate.why:!motionGate.ok?motionGate.why:'',yesMembers:v.yes.filter(id=>c.eligible.includes(id)),noMembers:v.no.filter(id=>c.eligible.includes(id)),
    day:G.day,passed,yes:c.yes,no:c.no,abstain:c.waiting.length,why:passed?'Gerekli üye ve oy çoğunluğu sağlandı':!warGate.ok?warGate.why:!motionGate.ok?motionGate.why:fedVoteRule(f,c)};
  f.vote = null;
  const queued=f.agenda?.history.find(r=>r.status==='active'&&r.vote===fedVoteToken(v));if(queued){queued.status='resolved';queued.updated=G.day;queued.why=f.lastVote.why;}
  if(v.kind==='motion'&&v.motion==='admit'&&!passed)fedAdmissionResult(f,v.id,!motionGate.ok?'invalid':c.waiting.length&&G.day>=v.expires?'expired':'rejected',motionGate.why||(c.waiting.length&&G.day>=v.expires?'Oylama süresi doldu; gereken çoğunluk yok. ':'')+'Üye oylaması reddetti: '+c.yes+' evet / '+c.no+' hayır; mutlak üye çoğunluğu gerekli. '+(v.no||[]).slice(0,3).map(id=>v.reasons?.[id]||'Üye ret oyu').join(' / '));
  fedPoliticalRecord(f,'vote',{kind:v.kind||'basic',law:v.law,passed,yes:c.yes,no:c.no,
    ...(!passed&&!v.repeal&&['basic','inner'].includes(v.kind)?{retry:{context:fedRetryContext(f),modern:!!v.ballotSnapshot?.modern,eligible:c.eligible.slice(),yes:v.yes.filter(id=>c.eligible.includes(id)),no:v.no.filter(id=>c.eligible.includes(id)),reasons:v.reasons}}:{})});
  f.nextVote = G.day + 180;
  if (passed){
    f.laws = f.laws || {};
    if(v.kind==='motion'){fedApplyMotion(f,v,c);}
    else if (v.kind === 'war'){
      f.warPermits = f.warPermits || {};
      f.warPermits[v.proposer + '>' + v.target] = {by:v.proposer, target:v.target, expires:G.day+180};
    } else if (v.repeal){
      delete f.laws[v.law];
      if (v.law === 'savasOnay') f.warPermits = {};
    } else {
      for (const k of fedLawConflicts(f,v.law)) delete f.laws[k];
      const before={defense:fedDuty(f,'defense'),offense:fedDuty(f,'offense')};
      f.laws[v.law] = {since:G.memAge || 0, by:v.proposer};fedSyncDuties(f,before);
    }
  }
  if (FED_INNER_LAWS[v.law]) f.cohesion = clamp(fedCohesion(f) +
    (passed ? (v.repeal ? 0 : (v.law === 'serbest' ? 8 : 4)) : -3), 0, 100);
  if (passed) for (const id of f.members) if (G.emps[id] && !G.emps[id].dead){
    const e=G.emps[id];recalcMods(e);
    if(e.ai){
      e.aiFedReview={day:G.day,law:v.law,motion:v.motion||null,opposed:v.no.includes(id)};
      // Reassess preparation inside the existing objective engine. Losing a
      // vote never cancels dues, consent records or legal war obligations.
      if(e.aiStrategy?.objective&&aiEconomyPlan(e).critical)e.aiStrategy.objective.nextReview=Math.min(e.aiStrategy.objective.nextReview||G.day,G.day);
    }
  }
  return {ok:true, pending:false, gecti:passed, evet:c.yes, hayir:c.no};
}
function fedPresentVote(f, result){
  if (!result.ok || !f.members.includes(0)) return;
  try {
    if (result.pending){
      if (f.vote && fedVoteCounts(f).waiting.includes(0)) UI.fedVote(f);
    } else {
      const v = f.lastVote, L = fedVoteLaw(v);
      const buf = [{tur:'say', scope:'fed-presentation', cls:v.passed ? 'win' : '',
        msg:'Federasyon oylaması: ' + L.n + (v.repeal ? ' (kaldırma)' : '') + ' — ' + (v.passed ? 'KABUL' : 'RED') +
          ' (' + v.yes + ' evet / ' + v.no + ' hayır / ' + v.abstain + ' çekimser)'}];
      if (G._sideBuf) G._sideBuf.push(...buf);
      else { commitSideBuffer(buf); flushSideBuffer(buf); }
    }
  } catch (err){ sideBufferError('oylama sunumu', err, 'fed-presentation'); }
}
function fedOpenVote(f, law, proposer, options = {}){
  const inner = !!FED_INNER_LAWS[law];
  f.voteSeq = Math.max(f.voteSeq || 0, Number(f.vote && f.vote.id) || 0) + 1;
  const v = f.vote = {id:f.voteSeq, law, kind:law==='motion'?'motion':law === 'warPermit' ? 'war' : inner ? 'inner' : 'basic',
    ...(law==='motion'?{applicant:options.applicant,motion:options.kind,type:options.type,field:options.field,value:options.value,sponsor:options.sponsor}:{}),
    ...(options.defenseFront?{defenseFront:options.defenseFront}:{}),
    repeal:!!options.repeal, target:options.target,
    proposer:proposer ? proposer.id : null, opened:G.day, expires:G.day + 90,
    eligible:[...new Set(f.members)].filter(id => G.emps[id] && !G.emps[id].dead && !(law==='motion'&&options.kind==='expel'&&id===options.target)), yes:[], no:[]};
  fedRefreshRepresentation(f);fedFreezeBallot(f,v);
  f.nextVote = G.day + 180;
  v.reasons={};v.assessments={};
  if(v.kind==='motion'&&v.motion==='admit')fedTrackAdmission(f,v);
  for (const id of v.eligible){
    if (id === 0) continue; // Oyuncunun oyu asla kura veya öneriyle verilmez.
    const e = G.emps[id];
    if(proposer&&id===proposer.id&&v.applicant===undefined){v.yes.push(id);v.reasons[id]='Öneriyi kendi sundu; açık öneri onayı';continue;}
    const assessment=aiFedVoteAssessment(e,f,v);v.assessments[id]=assessment;v.reasons[id]=assessment.why;
    // Preserve the old shared RNG schedule for pre-existing vote actions.
    // The reserved value never decides a vote; new regime proposals reserve none.
    if(!(v.kind==='motion'&&v.motion==='admit')&&!(v.kind==='motion'&&v.motion==='charter'&&v.field==='ballot')){rnd();v.legacyRngSlots=(v.legacyRngSlots||0)+1;}
    (assessment.score>=.5?v.yes:v.no).push(id);
  }
  return fedResolveVote(f);
}
function startFedVote(f){
  if (!f || fedOf(f.id) !== f || f.vote) return {ok:false, why:'Gündem dolu veya federasyon yok'};
  const open = Object.keys(FED_LAWS).filter(k => !(f.laws && f.laws[k]));
  if (!open.length) return {ok:false, why:'Tüm temel yasalar yürürlükte'};
  const result = fedChange(() => {
    const law=open[Math.floor(rnd()*open.length)];
    if(!fedLawRetryAllowed(f,law)){
      // Keep the existing shared RNG schedule for the redundant basic ballot.
      // Reserved samples never choose a vote or grant approval.
      for(const id of [...new Set(f.members)])if(id!==0&&G.emps[id]&&!G.emps[id].dead)rnd();
      f.nextVote=G.day+180;return {ok:false,deferred:true,why:'Yakın ret gerekçeleri ve oy dengesi değişmedi; aynı gündem bekliyor'};
    }
    return fedOpenVote(f,law,null);
  });
  fedPresentVote(f, result);
  return result;
}
function finishFedVote(f){
  if (!f || fedOf(f.id) !== f || !f.vote || !fedVoteLaw(f.vote)) return {ok:false};
  const c = fedVoteCounts(f);
  if (c.waiting.length && !(Number.isFinite(f.vote.expires) && G.day >= f.vote.expires))
    return {ok:true, pending:true};
  const result = fedChange(() => fedResolveVote(f));
  fedPresentVote(f, result);fedAdvanceAgenda(f);
  return result;
}
function castFedVote(e, fid, token, yes){
  const f = fedOf(fid), v = f && f.vote;
  if (!e || G.emps[e.id] !== e || e.dead || typeof yes !== 'boolean' || !v ||
      !fedVoteLaw(v) || fedVoteToken(v) !== String(token)) return {ok:false, why:'Oylama artık geçerli değil'};
  if (Number.isFinite(v.expires) && G.day >= v.expires) return {ok:false, why:'Oy süresi doldu'};
  if (!fedVoteCounts(f).waiting.includes(e.id)) return {ok:false, why:'Bu gündemde oy hakkın yok veya zaten kullandın'};
  const result = fedChange(() => {
    (yes ? v.yes : v.no).push(e.id);
    return fedResolveVote(f);
  });
  if(result.ok&&e.id===0&&typeof DiplomaticInbox!=='undefined')DiplomaticInbox.settleSource('fedvote',fid,token,yes?'accepted':'rejected');
  fedPresentVote(f, result);fedAdvanceAgenda(f);
  return result;
}

/* savunma paktı: bir üyeye savaş açılırsa hepsi girer */
function fedDefend(attacker, victim){
  const f = findFed(victim);
  if (!f || !fedDuty(f,'defense')) return;
  // A date can contain multiple decisions: the existing ledger sequence
  // distinguishes a war declared before a same-day constitutional change.
  const front=warLedgerFind(attacker.id,victim.id);
  if(f.defenseFrontCutoff&&(!front||front.id<f.defenseFrontCutoff))return;
  for (const id of f.members){
    if (id === victim.id) continue;
    const m = G.emps[id];
    if (!m || m.dead || m.war[attacker.id]) continue;
    if (m.ally[attacker.id]) continue;          // müttefikine savaş açtırmayız
    if (m.id === attacker.id) continue;
    if(!fedSupportGate(m,attacker,false).ok)continue;
    m._lastCB = {n:'Savunma Paktı Yükümlülüğü'};
    warAuthorize(m, attacker, m._lastCB);
    declareWar(m, attacker, {sponsor:victim.id, enemy:attacker.id, kind:'federation'});
    warAuthClear();
    if (id === 0) say('Federasyon savunma paktı seni savaşa soktu — ' + attacker.name, 'war');
  }
}
/* =====================================================================
   CASUSLUK VE İSTİHBARAT
   ===================================================================== */
const INTEL_LEVELS = [
  {n:'YABANCI',  d:'Sadece adını ve kaç sistemi olduğunu biliyorsun. Filo gücü tahmini çok kaba.'},
  {n:'TANIDIK',  d:'Filo gücünü ±%25 bandında görürsün, koloni sayısını bilirsin.'},
  {n:'İZLENİYOR',d:'Teknolojileri, civic\'leri ve lüks malları görünür. Operasyon yapabilirsin.'},
  {n:'SIZILMIŞ', d:'Savaş planlarını, kaynak durumunu ve hedeflerini görürsün.'}
];

const OPS = {
  calTech :{n:'Teknoloji Çal',      ico:'✦', lvl:2, cost:{etk:60},  risk:.35,
            d:'Rastgele bir teknolojisini kopyalar.'},
  sabotaj :{n:'Tersane Sabotajı',   ico:'💥', lvl:2, cost:{etk:50, ala:120}, risk:.40,
            d:'Bir sistemindeki üretim kuyruğunu ve savunmasını felç eder.'},
  isyan   :{n:'İsyan Kışkırt',      ico:'🔥', lvl:3, cost:{etk:110}, risk:.50,
            d:'Bir kolonisinin istikrarını çökertir.'},
  yalan   :{n:'Sahte İstihbarat',   ico:'🎭', lvl:2, cost:{etk:70},  risk:.25,
            d:'Gücünü olduğundan farklı gösterir; AI kararlarını buna göre alır.'},
  kervan  :{n:'Kervan İstihbaratı', ico:'🚚', lvl:1, cost:{etk:40},  risk:.20,
            d:'Ticaret rotalarını öğrenirsin; yağma şansın belirgin artar.'},

  /* ── FAZ 10: DERİN OPERASYONLAR ──
     Mevcut runOp/intelOf/spyCap altyapısını kullanır; yeni sistem
     kurulmaz. Hepsi stratejik seçim gerektirir, hepsinin bedeli var. */
  hazine  :{n:'Hazine Baskını',     ico:'💰', lvl:2, cost:{etk:55},  risk:.38,
            d:'Hedefin kaynak stoğunun bir kısmını çalar. Zengin düşmanı fakirleştirir.'},
  filoPlan:{n:'Filo Planlarını Çal', ico:'📡', lvl:2, cost:{etk:65},  risk:.30,
            d:'Filolarının konumu ve gücü 5 yıl boyunca sana açık kalır; ' +
              'muharebede ilk atışı sen yaparsın.'},
  suikast :{n:'Suikast',            ico:'🗡', lvl:3, cost:{etk:130}, risk:.58,
            d:'Bir fraksiyon liderini ortadan kaldırır: hedefin iç siyaseti ' +
              'kaosa sürüklenir, istikrar ve etki üretimi çöker.'},
  ambargoKir:{n:'Ambargo Kaçakçılığı', ico:'📦', lvl:1, cost:{etk:45}, risk:.22,
            d:'Sana uygulanan ambargolardan birini 4 yıl boyunca delersin; ' +
              'o hattan ticaret yeniden akar.'},
  sorusturma:{n:'Derin Soruşturma', ico:'🔎', lvl:1, cost:{etk:70}, risk:.10,
            d:'HEDEFİN üstüne yıkılmış bir iftirayı çöz. Gerçek fail ortaya ' +
              'çıkarsa kin ona döner ve hedefle aran düzelir. Kendi açık ' +
              'dosyalarını da aydınlatabilir.'},
  sahteKanit:{n:'Sahte Kanıt Yerleştir', ico:'🎭', lvl:2, cost:{etk:85}, risk:.42,
            d:'Galakside faili meçhul kalmış eski bir operasyonun suçunu HEDEFİN ' +
              'üstüne yık. Mağdur devlet hedefe kin duyar ve savaş nedeni kazanır. ' +
              'İfşa olursa üç devlet birden sana düşman kesilir.'},
  tersaneVir:{n:'Tersane Virüsü',   ico:'🦠', lvl:3, cost:{etk:95, ala:80}, risk:.45,
            d:'Gemi inşa hızını 3 yıl boyunca yarıya düşürür. ' +
              'Savaş öncesi hazırlığı çökertmenin en sessiz yolu.'}
};

/* FAZ 86A: SAF OKUMA. Eskiden `e.intel = {}` yazarak render sırasında
   oyun verisini değiştiriyordu. Yazan yollar ensureIntel() kullanır. */
function intelOf(e, id){
  return clamp((e.intel && e.intel[id]) || 0, 0, 3);
}
function ensureIntel(e){ if (!e.intel) e.intel = {}; return e.intel; }
function spyCap(e){
  let n = 1;
  if (e.mods.sensor > 0) n++;
  if (hasCivic(e, 'shadow')) n += 2;
  if (hasCivic(e, 'panopt')) n++;
  return n;
}
function spiesUsed(e){
  let n = 0;
  for (const k in (e.spy||{})) if (e.spy[k]) n++;
  return n;
}
/* 87A: arayüz ve yürütme aynı hedef kapısını kullanır; saf ön kontrol. */
function spyTargetCheck(e, target){
  if (!e || !G.emps || G.emps[e.id] !== e || e.dead || e.wild || !e.res)
    return {ok:false, why:'Aktif ajan devleti bulunamadı'};
  if (!target || G.emps[target.id] !== target || target.dead || target.wild || target.id === e.id)
    return {ok:false, why:'Hedef geçersiz'};
  if (!e.contact || !e.contact[target.id])
    return {ok:false, why:'Hedefle temas kurulmadı'};
  return {ok:true, why:''};
}
function spyAssignQuote(e, id){
  if (!Number.isInteger(id) || id < 0) return {ok:false, why:'Hedef geçersiz'};
  /* Eski/hedefsiz bir atama da geri çekilebilsin; yeni atama olamaz. */
  if (e && G.emps && G.emps[e.id] === e && !e.dead && e.spy && e.spy[id])
    return {ok:true, withdraw:true, why:''};
  const q = spyTargetCheck(e, G.emps && G.emps[id]);
  if (!q.ok) return q;
  return spiesUsed(e) < spyCap(e) ? {ok:true, withdraw:false, why:''}
    : {ok:false, why:'Boşta casusun yok — birini geri çek'};
}
function assignSpy(e, id){
  const q = spyAssignQuote(e, id);
  if (!q.ok) return false;
  e.spy = e.spy || {};
  e.spy[id] = !q.withdraw;
  return true;
}

/* aylık istihbarat ilerlemesi */
function spyTick(){
  for (const e of G.emps){
    if (e.dead || e.wild) continue;
    e.intel = e.intel || {};
    e.intelP = e.intelP || {};
    for (const o of G.emps){
      if (o.dead || o.wild || o.id === e.id) continue;
      let rate = 0;
      if (e.contact[o.id]) rate += .28;                       // temas yavaşça öğretir
      if (envoyStatus(e,o.id).active) rate += .35;              // elçi gözlem yapar
      if (e.spy && e.spy[o.id]) rate += 1.5;                  // casus hızlı
      if (hasCivic(e, 'shadow')) rate *= 1.5;
      // karşı istihbarat savunması
      if (hasCivic(o, 'counter')) rate *= .35;
      const sensors = o.mods.sensor || 0;
      rate *= clamp(1 - sensors * .12, .4, 1);
      if (rate <= 0) continue;
      e.intelP[o.id] = (e.intelP[o.id] || 0) + rate;
      const need = 12;
      while (e.intelP[o.id] >= need && intelOf(e, o.id) < 3){
        e.intelP[o.id] -= need;
        e.intel[o.id] = intelOf(e, o.id) + 1;
        if (e.id === 0) say('İstihbarat seviyesi arttı — ' + o.name + ' (' +
                            INTEL_LEVELS[e.intel[o.id]].n + ')', 'sci');
      }
      // casus yakalanma riski
      if (e.spy && e.spy[o.id] && !hasCivic(e, 'shadow') && rnd() < .035){
        e.spy[o.id] = false;
        e.rel[o.id] = clamp(e.rel[o.id] - 25, -100, 100);
        o.rel[e.id] = clamp(o.rel[e.id] - 25, -100, 100);
        remember(o, e.id, 'casusYakalan');
        if (e.id === 0) say('CASUSUN YAKALANDI — ' + o.name + ' (ilişki −25)', 'war');
        else if (o.id === 0) say(e.name + ' casusu yakalandı', 'win');
      }
    }
  }
}

/* görünen güç — istihbarat seviyesine ve sahte bilgiye göre bulanık */
function shownPower(viewer, target){
  const lvl = intelOf(viewer,target.id);
  const plans=viewer.fleetIntel&&viewer.fleetIntel[target.id]>G.day;
  let real;
  if(viewer===target||lvl>=3||plans)real=totalPower(target);
  else{
    const v=aiView(viewer);let visible=0;
    for(const f of G.fleets)if(f.e===target.id&&f.ships.length&&v.ctx.visible.has(f.mv?f.mv.to:f.sys))visible+=fleetPower(f);
    const footprint=Object.values(v.systems).filter(s=>s.owner===target.id).length;
    const remembered=viewer.aiIntel&&viewer.aiIntel.powers&&viewer.aiIntel.powers[target.id];
    const recent=remembered&&G.day-remembered.day<=720?remembered.value:0;
    real=Math.max(visible,recent,120+footprint*160+Math.max(0,G.year-2210)*80);
  }
  /* FAZ 10: Filo Planlarını Çal — çalınmış planlar sahte istihbaratı
     etkisiz kılar ve gerçek gücü kesin olarak gösterir. */
  if (viewer.fleetIntel && viewer.fleetIntel[target.id] > G.day)
    return {v: Math.round(real), exact: true, band: 0};
  // hedef bize sahte bilgi yediriyorsa çarpıt
  const fake0 = target.fakeTo && target.fakeTo[viewer.id];
  const fake=fake0&&(!Number.isFinite(fake0.until)||fake0.until>G.day)?fake0:null;
  const bias = fake ? fake.mul : 1;
  if (lvl >= 3) return {v: Math.round(real * bias), exact: !fake, band: 0};
  const band = lvl === 2 ? .12 : lvl === 1 ? .25 : .6;
  const seed = (target.id * 7919 + viewer.id * 131 + Math.floor(G.day / 90)) % 1000;
  const jitter = ((seed / 1000) - .5) * 2 * band;
  return {v: Math.round(real * bias * (1 + jitter)), exact: false, band};
}
function powerLabel(viewer, target){
  const s = shownPower(viewer, target);
  if (s.exact) return fmt(s.v);
  const lo = Math.round(s.v * (1 - s.band)), hi = Math.round(s.v * (1 + s.band));
  return intelOf(viewer, target.id) === 0 ? '≈' + fmt(s.v) + ' ?' : fmt(lo) + '–' + fmt(hi);
}

/* operasyon yürüt */
/* ═══════════════════════════════════════════════════════════════════
   FAZ 86A — TEK KANONİK, SAF OPERASYON ÖN KONTROLÜ

   ÖLÇÜLEN SORUNLAR:
   · runOp maliyeti kesip RNG'yi tüketip HİTLOG yazdıktan SONRA
     uygulanabilir hedef arıyordu. Ölçüm: calTech/sabotaj/isyan/
     hazine/suikast/ambargoKir/sorusturma/sahteKanit hedefsizken de
     kaynak harcadı, rnd() tüketti ve ok:true döndü.
   · opsMenu TABAN maliyet (opCost çarpanı yok) ve TABAN risk
     (shadow/counter yok) gösteriyordu — ekrandaki sayı gerçek
     kesintiyle uyuşmuyordu.
   · ambargoKir kullanıcının seçtiği hedefi YOK SAYIP ambargo
     uygulayanlar arasından rastgele üçüncü devlet seçiyordu; hitLog
     ise seçilen hedefi mağdur yazıyordu.

   opQuote RNG TÜKETMEZ ve oyun durumunu DEĞİŞTİRMEZ. runOp ve UI
   aynı kanonik sonucu kullanır; arayüz formül kopyalamaz. */
function opCostOf(e, OP){
  const kat = 1 + ((e.mods && e.mods.opCost) || 0);
  const out = {};
  for (const r in OP.cost) out[r] = Math.round(OP.cost[r] * kat);
  return out;
}
function opRiskOf(e, target, OP){
  let risk = OP.risk;
  if (hasCivic(e, 'shadow')) risk *= .4;
  if (hasCivic(target, 'counter')) risk = Math.min(.9, risk * 1.8);
  return risk;
}
/* Operasyonun uygulanabileceği gerçek hedef var mı? RNG kullanmaz. */
function opViable(e, target, key){
  switch(key){
    case 'calTech': {
      const av = Object.keys(target.techs || {}).filter(t => !e.techs[t] && TECHS[t] && researchAccess(e,t).ok);
      return av.length ? {ok:true, n:av.length, d:av.length + ' çalınabilir teknoloji'}
                       : {ok:false, why:'Çalınacak yeni teknolojisi yok'};
    }
    case 'sabotaj': {
      const owned = G.sys.filter(sy => sy.owner === target.id &&
        (sy.queue.length || sysDefense(sy) > 0));
      return owned.length ? {ok:true, n:owned.length, d:owned.length + ' sabote edilebilir sistem'}
                          : {ok:false, why:'Sabote edilecek tesisi yok'};
    }
    case 'isyan': {
      const cols = (target.colonies || []).filter(c =>
        G.sys[c.s] && G.sys[c.s].planets[c.p] && G.sys[c.s].planets[c.p].col);
      return cols.length ? {ok:true, n:cols.length, d:cols.length + ' kışkırtılabilir koloni'}
                         : {ok:false, why:'Kışkırtılacak kolonisi yok'};
    }
    case 'hazine': {
      const zengin = ['min','ene','ala','ara'].filter(r => (target.res[r] || 0) >= 60);
      return zengin.length ? {ok:true, n:zengin.length, d:zengin.length + ' yağmalanabilir stok'}
                           : {ok:false, why:'Hazinesi baskına değmeyecek kadar boş'};
    }
    case 'suikast':
      return (target.factions && target.factions.length)
        ? {ok:true, n:target.factions.length, d:target.factions.length + ' fraksiyon lideri'}
        : {ok:false, why:'Örgütlü bir siyasi yapısı yok'};
    case 'ambargoKir': {
      /* FAZ 86A DOĞRULUK: artık SEÇİLEN hedefin gerçekten ambargo
         uygulayan devlet olması şartı. Rastgele üçüncü devlet seçilmez. */
      const uygular = (typeof embargoOn === 'function') && embargoOn(target, e.id);
      if (!uygular) return {ok:false, why:'Bu devlet sana ambargo uygulamıyor'};
      if (e.smuggle && e.smuggle[target.id] > G.day)
        return {ok:false, why:'Bu hat zaten delinmiş durumda'};
      return {ok:true, n:1, d:'ambargo hattı açılabilir'};
    }
    case 'sorusturma': {
      const benim = (e.hitLog || []).filter(w =>
        w.known && w.by === target.id && w.framed !== undefined && w.framed !== e.id);
      if (benim.length) return {ok:true, n:benim.length, d:'kendi dosyanda ' + benim.length + ' iftira'};
      let n = 0;
      for (const v of G.emps){
        if (v.dead || v.wild || v.id === e.id) continue;
        n += (v.hitLog || []).filter(w => w.known && w.by === target.id &&
          w.framed !== undefined && w.framed !== v.id).length;
      }
      return n ? {ok:true, n, d:n + ' çözülebilir iftira dosyası'}
               : {ok:false, why:'Çözülecek iftira dosyası bulunamadı'};
    }
    case 'sahteKanit': {
      const magdurlar = G.emps.filter(v => !v.dead && !v.wild &&
        v.id !== e.id && v.id !== target.id &&
        v.contact[target.id] && (v.hitLog || []).some(w => !w.known));
      return magdurlar.length
        ? {ok:true, n:magdurlar.length, d:magdurlar.length + ' açık dosyalı mağdur'}
        : {ok:false, why:'Üstüne yıkılacak açık dosya yok'};
    }
    /* yalan · kervan · filoPlan · tersaneVir: hedefin kendisi yeterli */
    default: return {ok:true, n:1, d:'hedef uygun'};
  }
}
/* Yakalanmayan ama etkisi gözlenebilen operasyon için mağdura
   gösterilecek metin. FAİL BİLGİSİ İÇERMEZ — yalnız gözlemlenebilir
   kategori. Operasyonun niteliği gereği iz bırakmayanlar için genel
   kategori döner. */
const OP_VICTIM_HINT = {
  calTech   : 'Araştırma arşivlerinde izinsiz erişim izi bulundu — fail bilinmiyor',
  sabotaj   : 'Şüpheli tersane kesintisi tespit edildi — fail bilinmiyor',
  isyan     : 'Bir kolonide örgütlü kışkırtma saptandı — fail bilinmiyor',
  hazine    : 'Hazineden açıklanamayan bir kaynak çıkışı var — fail bilinmiyor',
  suikast   : 'Bir fraksiyon lideri suikaste kurban gitti — fail bilinmiyor',
  tersaneVir: 'Tersane sistemlerinde kötücül kod bulundu — fail bilinmiyor',
  filoPlan  : 'Filo planlarının sızdırıldığına dair belirti var — fail bilinmiyor',
  yalan     : 'İstihbarat raporlarında tutarsızlık saptandı — fail bilinmiyor',
  kervan    : 'Ticaret rotalarının izlendiğine dair belirti var — fail bilinmiyor',
  sahteKanit: 'Aleyhine yerleştirilmiş kanıt şüphesi doğdu — fail bilinmiyor'
};
function opVictimHint(key){
  return OP_VICTIM_HINT[key] ||
    'Şüpheli bir istihbarat faaliyeti tespit edildi — fail bilinmiyor';
}
function opQuote(e, target, key){
  const OP = Object.prototype.hasOwnProperty.call(OPS, key) ? OPS[key] : null;
  if (!OP) return {ok:false, why:'Bilinmeyen operasyon', key};
  const q = {key, op:OP, name:OP.n, ico:OP.ico, desc:OP.d,
             lvlNeed:OP.lvl, lvlHave:0, cost:{}, afford:false,
             risk:0, riskPct:0, viable:false, viableDesc:'',
             ok:false, why:''};
  const hedef = spyTargetCheck(e, target);
  if (!hedef.ok){ q.why = hedef.why; return q; }
  q.lvlHave = intelOf(e, target.id);
  q.cost    = opCostOf(e, OP);
  q.afford  = Object.keys(q.cost).every(r => (e.res[r] || 0) >= q.cost[r]);
  q.risk    = opRiskOf(e, target, OP);
  q.riskPct = Math.round(q.risk * 100);
  if (q.lvlHave < OP.lvl){
    q.why = 'Yetersiz istihbarat seviyesi (' + INTEL_LEVELS[OP.lvl].n + ' gerekli)';
    return q;
  }
  /* Kilitli kartta gizli teknoloji/stok/koloni sayıları sızmasın. */
  const v   = opViable(e, target, key);
  q.viable  = v.ok; q.viableDesc = v.ok ? v.d : '';
  if (!q.afford){ q.why = 'Yetersiz kaynak'; return q; }
  if (!v.ok){ q.why = v.why; return q; }
  q.ok = true;
  return q;
}

/* 87A: görev kuyruğu değil, mevcut alanların salt okunur süreli etki özeti.
   Rakibin gizli alanlarını okumaz; yalnız aktörün kendi kazanımlarıdır. */
function opActiveEffects(e, target){
  if (!spyTargetCheck(e, target).ok) return [];
  const id = target.id, out = [];
  const add = (key, name, until) => {
    if (Number.isFinite(until) && until > G.day)
      out.push({key, name, until, days:Math.ceil(until - G.day)});
  };
  add('yalan', 'Yanıltıcı güç raporu', e.fakeTo && e.fakeTo[id] && e.fakeTo[id].until);
  add('kervan', 'Ticaret rotası bilgisi', e.routeIntel && e.routeIntel[id]);
  add('filoPlan', 'Filo planı erişimi', e.fleetIntel && e.fleetIntel[id]);
  add('ambargoKir', 'Kaçak ticaret hattı', e.smuggle && e.smuggle[id]);
  return out;
}

function runOp(e, target, key){
  const OP = Object.prototype.hasOwnProperty.call(OPS, key) ? OPS[key] : null;
  if (!OP) return {ok:false, msg:'Bilinmeyen operasyon'};
  /* ═══ FAZ 86A: TEK KANONİK KAPI ═══
     Kaynak kesilmeden, RNG tüketilmeden ve hitLog yazılmadan ÖNCE
     bütün ön koşullar (seviye · gerçek maliyet · uygulanabilir hedef)
     opQuote ile sınanır. Eskiden uygulanabilir hedef switch içinde
     aranıyordu ve bulunamasa bile bedel ödenmiş oluyordu. */
  const q = opQuote(e, target, key);
  if (!q.ok) return {ok:false, msg:q.why, why:q.why, quote:q};

  /* FAZ 48: DÜRÜST ekseni casusluğu pahalılaştırır — opQuote'un
     hesapladığı GERÇEK maliyet kesilir (ekranda gösterilenle aynı). */
  for (const r in q.cost) e.res[r] -= q.cost[r];

  const risk = q.risk;
  const caught = rnd() < risk;

  let msg = '';
  switch(key){
    case 'calTech': {
      const av = Object.keys(target.techs || {}).filter(t => !e.techs[t] && TECHS[t] && researchAccess(e,t).ok);
      if (!av.length){ msg = 'Çalınacak yeni teknoloji bulunamadı.'; break; }
      const id = av[Math.floor(rnd()*av.length)];
      grantResearchTech(e,id,'espionage'); recalcMods(e);
      msg = TECHS[id].n + ' teknolojisi çalındı!';
      break;
    }
    case 'sabotaj': {
      const owned = G.sys.filter(sy => sy.owner === target.id && (sy.queue.length || sysDefense(sy) > 0));
      if (!owned.length){ msg = 'Sabote edilecek tesis bulunamadı.'; break; }
      const sy = owned[Math.floor(rnd()*owned.length)];
      sy.queue.length = 0;
      for (const p of sy.planets) if (p.col && p.col.b.kale) p.col.b.kale = Math.max(0, p.col.b.kale - 1);
      sy.def = sysDefense(sy);
      msg = sy.name + ' sistemindeki üretim ve savunma felç edildi.';
      break;
    }
    case 'isyan': {
      const cols = target.colonies.filter(c => G.sys[c.s].planets[c.p].col);
      if (!cols.length){ msg = 'Hedef koloni yok.'; break; }
      const c = cols[Math.floor(rnd()*cols.length)];
      const pl = G.sys[c.s].planets[c.p];
      pl.col.stab = clamp(pl.col.stab - 45, 0, 100);
      msg = pl.col.name + ' kolonisinde isyan patladı (istikrar −45).';
      break;
    }
    case 'yalan': {
      e.fakeTo = e.fakeTo || {};
      const mul = rnd() < .5 ? .45 : 1.9;
      e.fakeTo[target.id] = {mul, until: G.day + 720};
      msg = mul < 1 ? 'Zayıf görünüyorsun — saldırıya davetiye çıkardın.'
                    : 'Güçlü görünüyorsun — sana saldırmaya cesaret edemeyecekler.';
      break;
    }
    case 'kervan': {
      e.routeIntel = e.routeIntel || {};
      e.routeIntel[target.id] = G.day + 1080;
      msg = target.name + ' ticaret rotaları haritalandı — yağma şansın arttı.';
      break;
    }

    /* ── FAZ 10 OPERASYONLARI ── */
    case 'hazine': {
      const alinabilir = ['min','ene','ala','ara'];
      let toplam = 0, dokum = [];
      for (const r of alinabilir){
        const stok = target.res[r] || 0;
        if (stok < 60) continue;
        /* Stoğun %12-20'si; hedef ne kadar zenginse o kadar çok */
        const pay = stok * (.12 + rnd() * .08);
        target.res[r] -= pay;
        e.res[r] = (e.res[r] || 0) + pay;
        toplam += pay;
        dokum.push(Math.round(pay) + ' ' + (RES[r] ? RES[r].n : r));
      }
      msg = toplam > 0
        ? 'Hazine basıldı: ' + dokum.join(', ') + ' ele geçirildi.'
        : 'Hazineleri zaten boştu — alacak bir şey yok.';
      break;
    }
    case 'filoPlan': {
      e.fleetIntel = e.fleetIntel || {};
      e.fleetIntel[target.id] = G.day + 1800;      // 5 yıl
      msg = target.name + ' filo planları ele geçirildi — konumları ve ' +
            'gerçek güçleri sana açık, muharebede ilk atış senin.';
      break;
    }
    case 'suikast': {
      if (!target.factions || !target.factions.length){
        msg = 'Hedefin örgütlü bir siyasi yapısı yok.'; break;
      }
      /* En güçlü fraksiyonun lideri hedef alınır */
      const fac = target.factions.slice().sort((a,b) => b.pow - a.pow)[0];
      const eskiAd = fac.lider || 'lider';
      if (typeof facLeaderName === 'function') fac.lider = facLeaderName(target);
      fac.mood = clamp(fac.mood - 30, 0, 100);
      /* Suikast tüm fraksiyonları sarsar: iç siyaset kilitlenir */
      for (const f2 of target.factions) f2.mood = clamp(f2.mood - 12, 0, 100);
      target.stabHit = (target.stabHit || 0) + 18;
      target.res.etk = Math.max(0, (target.res.etk || 0) * .55);
      for (const c of target.colonies){
        const pl = G.sys[c.s] && G.sys[c.s].planets[c.p];
        if (pl && pl.col) pl.col.stab = clamp(pl.col.stab - 22, 0, 100);
      }
      msg = eskiAd + ' suikaste kurban gitti — ' + target.name +
            ' iç siyaseti kaosa sürüklendi (istikrar −22, etki yarılandı).';
      break;
    }
    case 'ambargoKir': {
      /* ═══ FAZ 86A DOĞRULUK ONARIMI ═══
         Eskiden ambargo uygulayanlar arasından rnd() ile RASTGELE
         üçüncü bir devlet seçiliyordu; oyuncunun seçtiği hedef yok
         sayılıyor, hitLog ise seçilen hedefi mağdur yazıyordu — yani
         delinen hat ile suçlanan devlet farklı olabiliyordu.
         Artık yalnız SEÇİLEN hedefin hattı delinir; uygunluk zaten
         opQuote/opViable tarafından garanti edilmiştir. */
      e.smuggle = e.smuggle || {};
      e.smuggle[target.id] = G.day + 1440;         // 4 yıl
      e._trAt = -1; target._trAt = -1;
      msg = target.name + ' ambargosu delindi — o hattan ticaret yeniden akıyor.';
      break;
    }
    /* ── FAZ 16: DERİN SORUŞTURMA ──
       w.framed verisini açığa çıkarır. Faz 15'te kurduğumuz iftira
       zincirinin karşı hamlesi: gerçek fail ortaya çıkar, kin yön
       değiştirir. Kendi dosyalarımızı da aydınlatabilir. */
    case 'sorusturma': {
      /* Önce KENDİ dosyalarımızda hedefe atılmış iftira var mı? */
      let dosya = null, magdur = null;
      const benimIftira = (e.hitLog || []).filter(w =>
        w.known && w.by === target.id && w.framed !== undefined && w.framed !== e.id);
      if (benimIftira.length){
        dosya = benimIftira[Math.floor(rnd() * benimIftira.length)];
        magdur = e;
      } else {
        /* Başka bir devletin, hedefe yıkılmış iftirasını çöz */
        const adaylar = [];
        for (const v of G.emps){
          if (v.dead || v.wild || v.id === e.id) continue;
          for (const w of (v.hitLog || []))
            if (w.known && w.by === target.id && w.framed !== undefined && w.framed !== v.id)
              adaylar.push({v, w});
        }
        if (adaylar.length){
          const sec = adaylar[Math.floor(rnd() * adaylar.length)];
          dosya = sec.w; magdur = sec.v;
        }
      }

      if (!dosya){
        /* İftira yok — hiç değilse kendi açık dosyalarımızdan birini çöz */
        const acik = (e.hitLog || []).filter(w => !w.known);
        if (!acik.length){ msg = 'Soruşturulacak şüpheli dosya bulunamadı.'; break; }
        const d2 = acik[Math.floor(rnd() * acik.length)];
        if (d2.by === undefined){ msg = 'Dosya soğuk — iz bulunamadı.'; break; }
        d2.known = true; d2.foundAt = G.memAge || 0;
        const fail = G.emps[d2.by];
        if (fail) remember(e, fail.id, 'komplo');
        msg = fail ? ('Açık dosya çözüldü — fail ' + fail.name) : 'Dosya çözüldü.';
        break;
      }

      /* İFTİRA ÇÖZÜLDÜ — gerçek fail ortaya çıkıyor */
      const gercek = G.emps[dosya.framed];
      dosya.by = dosya.framed;
      delete dosya.framed;
      dosya.foundAt = G.memAge || 0;

      /* Kin yön değiştirir: iftiraya uğrayan temize çıkar */
      forgetMemoryEvent(magdur, target.id, dosya.source);
      magdur.rel[target.id] = clamp(magdur.rel[target.id] + 28, -100, 100);
      if (gercek && !gercek.dead){
        remember(magdur, gercek.id, 'sahteBayrak');
        magdur.rel[gercek.id] = clamp(magdur.rel[gercek.id] - 34, -100, 100);
        /* Gerçeği ortaya çıkaran taraf itibar kazanır */
        target.rel[e.id] = clamp(target.rel[e.id] + 18, -100, 100);
        if (typeof remember === 'function') remember(target, e.id, 'yardimEtti');
      }
      msg = (gercek ? gercek.name : 'Biri') + ' iftira atmış — ' +
            target.name + ' suçsuz çıktı' +
            (magdur.id === 0 ? ' (senin dosyandı)' : ', ' + magdur.name + ' gerçeği öğrendi');
      if (magdur.id === 0 && gercek)
        say('GERÇEK ORTAYA ÇIKTI — asıl fail ' + gercek.name + ', ' +
            target.name + ' değilmiş', 'win');
      break;
    }

    /* ── FAZ 15: SAHTE KANIT ──
       Yeni bir komplo kurmaz; ZATEN OLMUŞ ama faili bulunamamış bir
       dosyayı hedefin üstüne yıkar. Mevcut hitLog altyapısını
       kullanır — sıfırdan kayıt sistemi kurulmaz. */
    case 'sahteKanit': {
      /* Kimin açık dosyası var? Hedefi tanıyan ve bize düşman olmayan
         bir devletin çözülmemiş kaydını arıyoruz. */
      const magdurlar = G.emps.filter(v => !v.dead && !v.wild &&
        v.id !== e.id && v.id !== target.id &&
        v.contact[target.id] && (v.hitLog || []).some(w => !w.known));
      if (!magdurlar.length){
        msg = 'Galakside üstüne yıkılacak açık dosya bulunamadı.';
        break;
      }
      /* En inandırıcı mağdur: hedeften zaten hoşlanmayan */
      magdurlar.sort((a, b) => (a.rel[target.id] || 0) - (b.rel[target.id] || 0));
      const magdur = magdurlar[0];
      const acik = (magdur.hitLog || []).filter(w => !w.known);
      const dosya = acik[Math.floor(rnd() * acik.length)];

      /* Kanıt yerleştirildi: dosya "çözülmüş" görünür, fail HEDEFTİR */
      dosya.known = true;
      dosya.by = target.id;
      dosya.foundAt = G.memAge || 0;
      dosya.framed = e.id;                      // gerçeği yalnız biz biliriz
      dosya.source = memoryEvent(e);

      const OPad = (typeof OPS !== 'undefined' && OPS[dosya.k]) ? OPS[dosya.k].n : 'bir operasyon';
      remember(magdur, target.id, 'komplo', dosya.source);
      magdur.rel[target.id] = clamp(magdur.rel[target.id] - 32, -100, 100);
      target.rel[magdur.id] = clamp(target.rel[magdur.id] - 10, -100, 100);

      if (magdur.id === 0)
        say('İSTİHBARAT: ' + OPad + ' dosyası çözüldü — fail ' + target.name, 'war');
      msg = magdur.name + ' artık o eski ' + OPad + ' operasyonunun failinin ' +
            target.name + ' olduğuna inanıyor.';
      break;
    }
    case 'tersaneVir': {
      target.virusUntil = G.day + 1080;            // 3 yıl
      recalcMods(target);
      msg = target.name + ' tersanelerine virüs bulaştırıldı — ' +
            'gemi inşa hızı 3 yıl boyunca yarı yarıya düştü.';
      break;
    }
  }
  /* ── FAZ 11: MAĞDUR KAYDI ──
     e.opLog faili tutuyordu; mağdur tarafında hiçbir iz yoktu.
     Artık hedef de kayıt tutar — ama YAKALANMADIYSA failin kimliği
     gizli kalır (bilinmeyen sabotaj). Karşı istihbarat sonradan
     çözebilir; bu, Faz 4'teki counterIntel mantığıyla aynı ruhtadır. */
  target.hitLog = target.hitLog || [];
  target.hitLog.push({
    t: (G.memAge || 0), k: key, by: e.id,
    caught: caught, known: caught          // yakalandıysa fail bilinir
  });
  if (target.hitLog.length > 30) target.hitLog.shift();

  if (caught){
    /* Sahte kanıt ifşası en ağır suçtur: iftiraya uğrayan hedef ve
       kandırılan mağdur birlikte gerçeği öğrenir. */
    if (key === 'sahteKanit'){
      remember(target, e.id, 'sahteBayrak');
      for (const v of G.emps){
        if (v.dead || v.wild || v.id === e.id) continue;
        const yalan = (v.hitLog || []).filter(w => w.framed === e.id);
        if (!yalan.length) continue;
        for (const w of yalan){
          forgetMemoryEvent(v, w.by, w.source);
          w.known = false; delete w.by; delete w.framed;
        }
        remember(v, e.id, 'sahteBayrak');
        v.rel[e.id] = clamp(v.rel[e.id] - 30, -100, 100);
        if (v.id === 0) say('SAHTE KANIT ORTAYA ÇIKTI — asıl fail ' + e.name, 'war');
      }
    }
    remember(target, e.id, key === 'sabotaj' ? 'sabotaj' : 'casusYakalan');
    e.rel[target.id] = clamp(e.rel[target.id] - 30, -100, 100);
    target.rel[e.id] = clamp(target.rel[e.id] - 30, -100, 100);
    msg += ' Ancak operasyon ifşa oldu — ilişki −30.';
    if (target.id === 0)
      say('CASUSLUK YAKALANDI — ' + e.name + ' sana "' + OP.n + '" operasyonu çekti', 'war');
    if (target.ai && target.rel[e.id] < -60 && rnd() < .3) declareWar(target, e);
  } else if (target.id === 0){
    /* ═══ FAZ 86A: GÖZLEMLENEBİLİR MAĞDUR GERİ BİLDİRİMİ ═══
       Eskiden her yakalanmayan operasyon için tek bir belirsiz
       "Bir şeyler ters gidiyor" mesajı vardı. Artık ETKİLENEN alan
       açıklanır, FAİL açıklanmaz. */
    say((typeof opVictimHint === 'function')
        ? opVictimHint(key)
        : 'Şüpheli bir istihbarat faaliyeti tespit edildi — fail bilinmiyor', 'war');
  }
  /* ═══ FAZ 86A: MERKEZÎ OPERASYON KAYDI ═══
     Ölçüm: oyuncunun standart runOp operasyonları e.opLog'a HİÇ
     yazılmıyordu (yalnız aiOpsTick kendi ek yazımını yapıyordu).
     Kayıt artık burada, aktör kim olursa olsun TAM BİR KEZ tutulur;
     aiOpsTick'teki ek yazım kaldırıldı (çift kayıt olmaz). */
  e.opLog = e.opLog || [];
  e.opLog.push({t:(G.memAge || 0), k:key, o:target.id, caught:caught,
                actorSummary:(msg || '').slice(0, 120)});
  if (e.opLog.length > 20) e.opLog.shift();
  if(e.id===0||target.id===0&&caught)recordNews({category:'espionage',scope:'player',empires:[e.id,target.id],title:'Casusluk — '+OP.n,text:e.id===0?msg:'Yakalanan operasyon: '+OP.n});
  return {ok:true, msg, caught, key, target:target.id, quote:q};
}

/* sahte bilgi süresi dolunca temizle */
function fakeTick(){
  for (const e of G.emps){
    if (!e.fakeTo) continue;
    for (const k in e.fakeTo) if (e.fakeTo[k].until < G.day) delete e.fakeTo[k];
  }
}
/* =====================================================================
   FRAKSİYONLAR — İÇ POLİTİKA
   Oyuncu fraksiyonları YÖNETMEZ. Memnuniyet asla kendiliğinden
   değişmez; yalnızca somut eylemlerden etkilenir ve her değişimin
   sebebi kaydedilir. Fraksiyonlar ceza vermez, SEÇİM yaptırır.
   ===================================================================== */
const FACTIONS = {
  asker:{n:'Askerî Kurul', ico:'⚔', col:'#ff5f6d',
    ister:'Savaş, fetih, güçlü donanma',
    good:{dmgMul:.12, hullMul:.06, capFlat:14},
    bad :{dmgMul:-.08, upMul:.10},
    d:'Filoların büyümesini ve düşmanların ezilmesini bekler.'},
  bilim:{n:'Bilim Konseyi', ico:'🔬', col:'#8b7bff',
    ister:'Araştırma, keşif, anomali',
    good:{araMul:.14, sensor:1},
    bad :{araMul:-.10},
    d:'Bilginin her şeyden önce geldiğine inanır.'},
  tuccar:{n:'Tüccar Loncası', ico:'💰', col:'#f2d452',
    ister:'Ticaret, koloni, barış',
    good:{eneMul:.14, minMul:.06},
    bad :{eneMul:-.10, upMul:.08},
    d:'Kâr eden bir imparatorluk isterler; savaş masraftır.'},
  halk:{n:'Halk Meclisi', ico:'🏛', col:'#65e08a',
    ister:'İstikrar, refah, tüketim malı',
    good:{growMul:.14, stab:8, yiyMul:.08},
    bad :{stab:-12, growMul:-.08},
    d:'Halkın karnı doysun, kolonilerde huzur olsun.'},
  inanc:{n:'İnanç Düzeni', ico:'⛪', col:'#ff9b3d',
    ister:'Etki, birlik, ruhani üstünlük',
    good:{etkFlat:2.2, stab:6, dipMul:.10},
    bad :{etkFlat:-1.2, stab:-8},
    d:'İmparatorluğun kutsal bir amacı olduğuna inanır.'}
};

const FAC_LEADER_A = ['Yüce','Kıdemli','Baş','Kadim','Onurlu','Sert','Bilge','Yüksek'];
const FAC_LEADER_B = ['Vorn','Kessa','Thal','Miren','Zoltan','Aeryn','Draka','Vesh','Oram','Lyssa','Karn','Ish'];

function facLeaderName(){
  return pick(rnd, FAC_LEADER_A) + ' ' + pick(rnd, FAC_LEADER_B);
}

/* ---------------------------------------------------------------
   Hangi fraksiyonlar doğar? Irkın etiğine göre belirlenir —
   militarist bir devlette Askerî Kurul kaçınılmazdır, Halk Meclisi
   ise egaliter devletlerde güçlüdür.
   --------------------------------------------------------------- */
function initFactions(e){
  const race = RACES[e.race];
  // kovan zihni ve makine zekâsında fraksiyon olmaz: tek irade
  if (race.dip === 0 || race.bio === 'makine'){
    e.factions = null;
    e.unity = 70;
    return;
  }
  const et = e.ethics || {mil:0, aut:0, mat:0};
  const score = {
    asker : 30 + (et.mil||0)*14,
    bilim : 28 + (et.mat||0)*13,
    tuccar: 28 + (race.win === 'ekonomi' ? 22 : 0) - (et.mil||0)*5,
    halk  : 28 - (et.aut||0)*13,
    inanc : 26 - (et.mat||0)*13
  };
  const keys = Object.keys(score).sort((a,b)=>score[b]-score[a]).slice(0,3);
  const raw = keys.map(k=>Math.max(12, score[k]));
  const tot = raw.reduce((a,b)=>a+b,0);
  const baseMood = 50 + (hasPerk(e,'consensus') ? 20 : 0);
  e.factions = keys.map((k,i)=>({
    k, pow: Math.round(raw[i]/tot*100), mood: baseMood,
    leader: facLeaderName(), demand: null, log: []
  }));
  // toplam tam 100 olsun
  const diff = 100 - e.factions.reduce((a,f)=>a+f.pow,0);
  e.factions[0].pow += diff;
  return e.factions;
}

function facPowerMul(e){
  // Mutlak Otorite fraksiyonları bastırır
  return hasPerk(e,'noCoup') ? .6 : 1;
}

/* 91B: güç payları yüzde dağılımıdır. Ayrı ayrı Math.round toplamı
   99/101 yapıyordu; darbe +10 ağırlıktan sonra 110 bırakabiliyordu.
   En büyük küsurat yöntemi, eşitlikte mevcut sıra: tam 100, ek RNG yok.
   Fraksiyon dizisi/nesneleri yerinde kalır. */
function normalizeFactionShares(factions){
  if (!factions || !factions.length) return;
  const total = factions.reduce((sum, f) => sum + f.pow, 0);
  const shares = factions.map((f, i) => {
    const exact = total > 0 ? f.pow / total * 100 : 100 / factions.length;
    f.pow = Math.floor(exact);
    return {f, i, fraction:exact - f.pow};
  });
  let remaining = 100 - factions.reduce((sum, f) => sum + f.pow, 0);
  shares.sort((a, b) => b.fraction - a.fraction || a.i - b.i);
  for (let i = 0; i < remaining; i++) shares[i].f.pow++;
}

/* memnuniyeti SEBEBİYLE birlikte değiştir */
function facMoodDelta(e, mood, amount){
  const adjusted = amount < 0 && hasPerk(e,'consensus') ? amount * .6 : amount;
  return clamp(mood + adjusted, 0, 100) - mood;
}
function facShift(e, key, amount, reason){
  if (!e.factions) return;
  const f = e.factions.find(x=>x.k===key);
  if (!f) return;
  const amt = facMoodDelta(e, f.mood, amount);
  f.mood += amt;
  f.log.unshift({t:reason, v:Math.round(amt), d:G.day});
  if (f.log.length > 6) f.log.pop();
  if (e.id === 0 && Math.abs(amt) >= 6){
    say(FACTIONS[key].n + ' ' + (amt>0?'+':'') + Math.round(amt) + ' — ' + reason,
        amt > 0 ? 'win' : 'war');
  }
}

/* imparatorluk eylemlerini fraksiyonlara duyur */
function facEvent(e, kind, extra){
  if (!e || !e.factions) return;
  switch(kind){
    case 'war':
      facShift(e, 'asker', +10, 'savaş ilanı');
      facShift(e, 'tuccar', -8, 'savaş ticareti vurur');
      facShift(e, 'halk', -6, 'halk savaş istemiyor');
      break;
    case 'peace':
      facShift(e, 'asker', -7, 'barış imzalandı');
      facShift(e, 'tuccar', +8, 'ticaret yolları açıldı');
      facShift(e, 'halk', +7, 'halk barışa sevindi');
      break;
    case 'colony':
      facShift(e, 'tuccar', +6, 'yeni koloni kuruldu');
      facShift(e, 'halk', +3, 'yeni yurt');
      break;
    case 'tech':
      facShift(e, 'bilim', +6, 'araştırma tamamlandı');
      break;
    case 'conquest':
      facShift(e, 'asker', +9, 'sistem fethedildi');
      facShift(e, 'inanc', +4, 'zafer kutsandı');
      break;
    case 'lost':
      facShift(e, 'asker', -10, 'sistem kaybedildi');
      facShift(e, 'halk', -8, 'halk paniğe kapıldı');
      facShift(e, 'inanc', -6, 'inanç sarsıldı');
      break;
    case 'ally':
      facShift(e, 'tuccar', +7, 'ittifak ticareti güçlendirir');
      facShift(e, 'asker', -4, 'askerler bağımlılık sevmez');
      break;
    case 'shortage':
      facShift(e, 'halk', -7, 'tüketim malı kıtlığı');
      break;
    case 'influence':
      facShift(e, 'inanc', +5, 'etki birikti');
      break;
    case 'fleetLoss':
      facShift(e, 'asker', -8, 'filo yok edildi');
      break;
    case 'struct':
      facShift(e, 'bilim', +4, 'uzay yapısı tamamlandı');
      facShift(e, 'tuccar', +3, 'altyapı yatırımı');
      break;
  }
}

/* fraksiyon modifikatörleri: güç payı × memnuniyet */
function facMods(e){
  const out = {};
  if (!e.factions) return out;
  const pm = facPowerMul(e);
  for (const f of e.factions){
    const F = FACTIONS[f.k];
    const w = (f.pow / 100) * pm;
    if (f.mood >= 60){
      const s = w * ((f.mood - 60) / 40);
      for (const k in F.good) out[k] = (out[k]||0) + F.good[k]*s;
    } else if (f.mood <= 35){
      const s = w * ((35 - f.mood) / 35);
      for (const k in F.bad) out[k] = (out[k]||0) + F.bad[k]*s;
    }
  }
  return out;
}

/* ---------------------------------------------------------------
   Aylık fraksiyon tiki: güç payı memnuniyete göre kayar,
   kızgın ve güçlü fraksiyon dayatma yapar, çok güçlenirse darbe.
   --------------------------------------------------------------- */
function facTick(){
  for (const e of G.emps){
    if (e.dead || e.wild) continue;
    if (!e.factions){
      // kovan/makine: tek eksenli uyum
      if (e.unity === undefined) e.unity = 70;
      const target = 70 + (e.crisis ? -25 : 0) + (e.shortage ? -12 : 0);
      e.unity = clamp(e.unity + clamp(target - e.unity, -2, 2), 0, 100);
      continue;
    }
    /* ═══════════════════════════════════════════════════════════
       FAZ 78B — HİZİP MORALİ OYUNCUYA TEPKİ VERİR
       ÖLÇÜM: 180 ay boyunca moral 50'de ÇAKILI KALIYORDU — güç
       payı moralden besleniyor ama morali besleyen hiçbir şey
       yoktu. Sistem teknik olarak çalışıyor, hikâyesel olarak
       ölüydü.

       Artık her hizip devletin durumuna bakıyor. Tepki YAVAŞ
       (ayda en çok ±0.8) ki bu bir bildirim yağmuruna değil,
       arka planda usulca dolan bir sayaca dönüşsün. */
    {
      let savasN = 0, uzunSavas = 0;
      for (const w in e.war){
        if (!e.war[w] || !G.emps[w] || G.emps[w].wild) continue;
        savasN++;
        if ((e.warExh && e.warExh[w] || 0) > 60) uzunSavas++;
      }
      const kriz = !!e.crisis, darlik = !!e.shortage;
      const araGelir = (e.inc && e.inc.ara) || 0;
      const eneGelir = (e.inc && e.inc.ene) || 0;
      let ortStab = 0, colN = 0;
      for (const c of (e.colonies || [])){
        const sy = G.sys[c.s], pl = sy && sy.planets[c.p];
        if (pl && pl.col){ ortStab += pl.col.stab; colN++; }
      }
      ortStab = colN ? ortStab / colN : 60;

      for (const f of e.factions){
        let d = 0;
        switch (f.k){
          case 'asker':                       // savaş ister, barış küstürür
            d = savasN ? .55 : -.35;
            if (uzunSavas) d += .25;          // uzun savaş onları besler
            break;
          case 'bilim':                       // araştırma ve barış ister
            d = (araGelir > 12 ? .45 : -.25) + (savasN ? -.35 : .20);
            break;
          case 'tuccar':                      // enerji akışı ve barış ister
            d = (eneGelir > 8 ? .45 : -.30) + (savasN ? -.40 : .15);
            break;
          case 'halk':                        // istikrar ve barış ister
            d = (ortStab > 60 ? .40 : -.35) + (uzunSavas ? -.45 : 0);
            break;
          case 'inanc':                       // istikrar ister, krizde küser
            d = (ortStab > 55 ? .35 : -.30) + (kriz ? -.40 : 0);
            break;
        }
        if (darlik) d -= .30;                 // kıtlık herkesi küstürür
        if (kriz && f.k !== 'inanc') d -= .15;

        /* ═══ KALİBRASYON (ölçümle) ═══
           İlk deneme ±0.8/ay idi: 120 ayda moral 0 ve 100'e
           ÇAKILIYORDU — "düşük yoğunluk" değil, uca savrulma.
           İki fren eklendi:
             · adım ±0.30'a indirildi (120 ayda en çok ±36)
             · merkeze geri çekim: uçlara yaklaştıkça direnç artar,
               böylece hiçbir hizip kalıcı olarak 0/100'de kilitlenmez
           Sonuç: sayaç yavaşça dolar, oyuncu eğilimi hisseder ama
           tek bir kararla her şey tersine dönmez. */
        d = clamp(d, -.30, .30);
        d += (50 - f.mood) * .008;            // merkeze usul çekim
        f.mood = clamp(f.mood + d, 5, 95);    // uçlar 5-95, asla kilitlenmez
      }
    }

    // memnuniyet güç payını çeker: memnun fraksiyon güçlenir
    let shift = 0;
    for (const f of e.factions){
      /* FAZ 78B: güç kayması da yavaşlatıldı (.012 → .005) —
         moral kalibre edilince pay da daha yumuşak hareket etmeli. */
      const pull = (f.mood - 50) * .005;
      f.pow = clamp(f.pow + pull, 5, 80);
      shift += pull;
    }
    // toplamı 100'e normalize et
    normalizeFactionShares(e.factions);

    // dayatma: kızgın VE güçlü fraksiyon talep iletir
    for (const f of e.factions){
      if (f.demand){
        f.demand.left -= 1;
        if (f.demand.left <= 0){
          const done = facCheckDemand(e, f);
          if (done){ facShift(e, f.k, +18, 'talep karşılandı'); }
          else { facShift(e, f.k, -14, 'talep karşılanmadı'); }
          f.demand = null;
        }
        continue;
      }
      if (f.mood < 32 && f.pow > 24 && rnd() < .16){
        f.demand = facMakeDemand(e, f);
        if (f.demand && e.id === 0) UI.facDemand(f);
      }
    }

    // darbe: çok güçlü ve çok kızgın → ideoloji zorla kayar
    if (!hasPerk(e,'noCoup')){
      const rebel = e.factions.find(f => f.pow >= 55 && f.mood <= 20);
      if (rebel && rnd() < .12) facCoup(e, rebel);
    }
    recalcMods(e);
  }
}

function facMakeDemand(e, f){
  const now = G.day;
  switch(f.k){
    case 'asker': {
      const target = fleetUsage(e) + 12;
      return {t:'fleet', v:target, left:36, txt:'Filo gücünü ' + target + ' birime çıkar'};
    }
    case 'bilim': {
      const target = Object.keys(e.techs).length + 3;
      return {t:'tech', v:target, left:36, txt:target + ' teknolojiye ulaş'};
    }
    case 'tuccar': {
      const target = e.colonies.length + 2;
      return {t:'colony', v:target, left:48, txt:target + ' koloniye ulaş'};
    }
    case 'halk': {
      return {t:'stab', v:60, left:36, txt:'Tüm kolonilerde istikrarı 60 üstüne çıkar'};
    }
    case 'inanc': {
      const target = Math.round(e.res.etk + 250);
      return {t:'etk', v:target, left:36, txt:target + ' etki biriktir'};
    }
  }
  return null;
}
function facCheckDemand(e, f){
  const d = f.demand;
  if (!d) return false;
  switch(d.t){
    case 'fleet':  return fleetUsage(e) >= d.v;
    case 'tech':   return Object.keys(e.techs).length >= d.v;
    case 'colony': return e.colonies.length >= d.v;
    case 'etk':    return e.res.etk >= d.v;
    case 'stab': {
      let ok = true;
      for (const c of e.colonies){
        const pl = G.sys[c.s].planets[c.p];
        if (pl.col && pl.col.stab < d.v) ok = false;
      }
      return ok;
    }
  }
  return false;
}

/* darbe: fraksiyon ideolojiyi kendi yönüne çeker */
function facCoup(e, f){
  const et = e.ethics || {mil:0, aut:0, mat:0};
  let axis = 'aut', dir = 1, label = '';
  switch(f.k){
    case 'asker':  axis='mil'; dir= 1; label='militarist'; break;
    case 'halk':   axis='aut'; dir=-1; label='egaliter';   break;
    case 'bilim':  axis='mat'; dir= 1; label='materyalist';break;
    case 'inanc':  axis='mat'; dir=-1; label='ruhani';     break;
    case 'tuccar': axis='mil'; dir=-1; label='pasifist';   break;
  }
  const before = et[axis] || 0;
  et[axis] = clamp(before + dir * 2, -ETHIC_MAX, ETHIC_MAX);
  // bütçe aşımını başka eksenden düş
  let spent = Math.abs(et.mil) + Math.abs(et.aut) + Math.abs(et.mat);
  const others = ['mil','aut','mat'].filter(a=>a!==axis);
  for (const a of others){
    while (spent > ETHIC_BUDGET && et[a] !== 0){ et[a] -= Math.sign(et[a]); spent--; }
  }
  e.ethics = et;
  f.mood = 55;
  f.pow = clamp(f.pow + 10, 5, 80);
  normalizeFactionShares(e.factions);
  // diğer fraksiyonlar öfkelenir
  for (const o of e.factions) if (o !== f) o.mood = clamp(o.mood - 18, 0, 100);
  recalcMods(e);
  if (e.id === 0){
    UI.facCoup(f, label);
  } else {
    say(e.name + ' iç darbe yaşadı — yönetim ' + label + ' çizgiye kaydı', 'war');
  }
}

/* ---------- İDEOLOJİ REFORMU ----------
   Oyuncu büyük bir etki maliyetiyle ideolojisini kaydırabilir.
   Darbeye cevap vermenin ve gönüllü taviz vermenin yolu budur. */
const REFORM_COST = 400;
const REFORM_COOLDOWN = 10 * 360;      // 10 yıl

function canReform(e){
  if ((e.res.etk||0) < REFORM_COST)
    return {ok:false, why:REFORM_COST + ' etki gerekir (şu an ' + Math.round(e.res.etk) + ').'};
  const last = (e.lastReform === undefined) ? -99999 : e.lastReform;   // 0 falsy tuzağı
  const left = Math.ceil((last + REFORM_COOLDOWN - G.day) / 360);
  if (left > 0) return {ok:false, why:'Bir sonraki reform için ' + left + ' yıl beklemelisin.'};
  return {ok:true};
}
function doReform(e, axis, dir){
  const chk = canReform(e);
  if (!chk.ok) return chk;
  const et = e.ethics || {mil:0, aut:0, mat:0};
  const cur = et[axis] || 0;
  const next = clamp(cur + dir, -ETHIC_MAX, ETHIC_MAX);
  if (next === cur) return {ok:false, why:'Bu eksen zaten uçta.'};
  // bütçe kontrolü
  let spent = Math.abs(next) + Math.abs(et.mil) + Math.abs(et.aut) + Math.abs(et.mat) - Math.abs(cur);
  if (spent > ETHIC_BUDGET){
    // başka eksenden düşür
    const others = ['mil','aut','mat'].filter(a=>a!==axis)
      .sort((a,b)=>Math.abs(et[a]) - Math.abs(et[b]));
    for (const a of others){
      while (spent > ETHIC_BUDGET && et[a] !== 0){ et[a] -= Math.sign(et[a]); spent--; }
    }
  }
  if (spent > ETHIC_BUDGET) return {ok:false, why:'İdeoloji bütçesi yetersiz.'};
  et[axis] = next;
  e.ethics = et;
  e.res.etk -= REFORM_COST;
  e.lastReform = G.day;
  // fraksiyonlar tepki verir
  if (e.factions){
    const like = {asker:'mil', halk:'aut', bilim:'mat', inanc:'mat', tuccar:'mil'};
    const wantDir = {asker:1, halk:-1, bilim:1, inanc:-1, tuccar:-1};
    for (const f of e.factions){
      if (like[f.k] !== axis) continue;
      const good = (wantDir[f.k] === dir);
      facShift(e, f.k, good ? +20 : -16, 'ideoloji reformu');
    }
  }
  recalcMods(e);
  return {ok:true, from:cur, to:next};
}

/* fraksiyon özeti — arayüz için */
function facSummary(e){
  if (!e.factions) return null;
  return e.factions.map(f=>({
    ...f, def:FACTIONS[f.k],
    state: f.mood >= 60 ? 'memnun' : f.mood <= 35 ? 'kızgın' : 'kararsız'
  }));
}
/* =====================================================================
   SAVAŞ HEDEFLERİ · SAVAŞ YORGUNLUĞU · GEZEGEN KARAKTERİ
   ===================================================================== */

/* ---------- SAVAŞ HEDEFLERİ (Casus Belli) ----------
   Savaş ilan ederken ne için savaştığını seçersin. Hedefe yaklaştıkça
   "savaş puanı" birikir; müzakerede karşı taraf bunu tanır ve barışa
   daha yatkın olur. Hedefsiz savaş amaçsız sürüklenir.            */
const WAR_GOALS = {
  boyun:{n:'Boyun Eğdirme', ico:'👑', etk:45,
    d:'Düşmanı yok etme, boyunduruk altına al. Başkentini kuşat ve ' +
      'filosunu yarıya indir — sonra vasalın olur.',
    setup(e, foe){ return {home: foe.home, base: Math.max(1, totalPower(foe))}; },
    prog(e, foe, g){
      const sy = G.sys[g.home];
      let p = 0;
      /* Yarısı askerî çöküş, yarısı başkent baskısı */
      /* Askerî çöküş (yarıya inen filo) tek başına %50 ilerleme sağlar.
         Başkenti FETHETMEK şart değil — KUŞATMAK da yeter; yoksa
         toplam puan 0.8'de takılıyor ve boyunduruk asla kurulamıyordu. */
      const now = totalPower(foe);
      p += clamp(1 - now / Math.max(1, g.base * .5), 0, 1) * .5;
      if (sy){
        if (sy.owner === e.id) p += .6;
        else if (G.fleets.some(f => f.e === e.id && f.sys === g.home && isArmed(f))) p += .5;
      }
      return clamp(p, 0, 1);
    },
    txt(e, foe, g){
      const sy = G.sys[g.home];
      const now = totalPower(foe);
      const askeri = Math.round(clamp(1 - now / Math.max(1, g.base), 0, 1) * 100);
      const bas = sy && sy.owner === e.id ? 'başkent alındı'
                : (sy && G.fleets.some(f => f.e === e.id && f.sys === g.home && isArmed(f)))
                  ? 'başkent kuşatmada' : 'başkent serbest';
      return 'filo −%' + askeri + ' · ' + bas;
    }},
  fetih:{n:'Fetih', ico:'⚔', etk:25,
    d:'Düşmanın sınır sistemlerini ele geçir. Hedef: 3 sistem.',
    setup(e, foe){
      const cand = G.sys.filter(sy => sy.owner === foe.id && sy.id !== foe.home)
        .sort((a,b)=>{
          const da = Math.min(...G.sys.filter(x=>x.owner===e.id).map(x=>dist(x,a)).concat([9e9]));
          const db = Math.min(...G.sys.filter(x=>x.owner===e.id).map(x=>dist(x,b)).concat([9e9]));
          return da - db;
        }).slice(0, 3).map(sy=>sy.id);
      // düşmanın başkent dışında sistemi yoksa başkent hedef olur
      if (!cand.length && G.sys[foe.home]) cand.push(foe.home);
      return {targets: cand};
    },
    prog(e, foe, g){
      if (!g.targets || !g.targets.length) return 0;
      const got = g.targets.filter(id => G.sys[id] && G.sys[id].owner === e.id).length;
      return got / g.targets.length;
    },
    txt(e, foe, g){
      const got = (g.targets||[]).filter(id => G.sys[id] && G.sys[id].owner === e.id).length;
      return got + '/' + (g.targets||[]).length + ' sistem alındı';
    }},
  harac:{n:'Haraç', ico:'💰', etk:20,
    d:'Düşmanı yıllık ödemeye zorla. Filosunu %40 imha etmek yeter.',
    setup(e, foe){ return {base: totalPower(foe) || 1}; },
    prog(e, foe, g){
      const now = totalPower(foe);
      return clamp(1 - now / Math.max(1, g.base * .6), 0, 1);
    },
    txt(e, foe, g){
      const now = totalPower(foe);
      const pct = Math.round(clamp(1 - now / Math.max(1, g.base), 0, 1) * 100);
      return 'düşman filosu %' + pct + ' zayıfladı';
    }},
  bilgi:{n:'Bilgi', ico:'✦', etk:20,
    d:'Bir teknolojisini zorla al. Başkentini kuşatmak yeter.',
    setup(e, foe){ return {home: foe.home}; },
    prog(e, foe, g){
      const sy = G.sys[g.home];
      if (!sy) return 0;
      if (sy.owner === e.id) return 1;
      const sieging = G.fleets.some(f => f.e === e.id && f.sys === g.home && isArmed(f));
      return sieging ? .6 : 0;
    },
    txt(e, foe, g){
      const sy = G.sys[g.home];
      if (sy && sy.owner === e.id) return 'başkent ele geçirildi';
      const sieging = G.fleets.some(f => f.e === e.id && f.sys === g.home && isArmed(f));
      return sieging ? 'başkent kuşatma altında' : 'başkente ulaşılmadı';
    }},
  yikim:{n:'Yıkım', ico:'🔥', etk:15,
    d:'Donanmasını kır. Filo gücünün %70\'ini imha et.',
    setup(e, foe){ return {base: Math.max(1, totalPower(foe))}; },
    prog(e, foe, g){
      const now = totalPower(foe);
      return clamp((1 - now / g.base) / .70, 0, 1);
    },
    txt(e, foe, g){
      const now = totalPower(foe);
      return 'filo gücü ' + fmt(g.base) + ' → ' + fmt(now);
    }},
  yoketme:{n:'Yok Etme', ico:'☠', etk:90,
    d:'İmparatorluğu tarihten sil. Çok pahalı; tüm galakside itibar kaybettirir.',
    setup(e, foe){
      for (const o of G.emps){
        if (o.dead || o.wild || o.id === e.id) continue;
        o.rel[e.id] = clamp(o.rel[e.id] - 22, -100, 100);
      }
      return {};
    },
    prog(e, foe){ return foe.dead ? 1 : clamp(1 - sysCount(foe) / 4, 0, .95); },
    txt(e, foe){ return foe.dead ? 'imparatorluk yok edildi' : sysCount(foe) + ' sistemi kaldı'; }}
};

/* Savaş Kahramanı: hedef tamamlanınca tüm fraksiyonlar sevinir.
   Sonsuz Seferberlik: her savaş ilanı kalıcı güç biriktirir. */
/* Boyun eğdirme hedefi dolduğunda vasallık kurulur */
function checkSubjugation(e, foeId){
  if (!e.wg || !e.wg[foeId] || e.wg[foeId].t !== 'boyun') return false;
  if (e.wg[foeId].done) return false;
  if (warGoalProgress(e, foeId) < 1) return false;
  const foe = G.emps[foeId];
  if (!foe || foe.dead) return false;
  e.wg[foeId].done = true;
  /* Tür seçimi: sınır komşusuysa tampon bekçi, uzaksa haraçgüzar */
  const komsu = G.sys.some(sy => sy.owner === foe.id &&
    sy.lanes.some(l => G.sys[l].owner === e.id));
  const prof = e.ai ? aiProfile(e) : {war:.5, eco:.5};
  const tur = (komsu && prof.war > prof.eco) ? 'bekci' : 'haracguzar';
  return subjugate(e, foe, tur);
}

function warGoalCheckReward(e, foeId){
  if (!e.wg || !e.wg[foeId] || e.wg[foeId].rewarded) return;
  if (warGoalProgress(e, foeId) < 1) return;
  e.wg[foeId].rewarded = true;
  if (hasCivic(e,'warhero') && e.factions)
    e.factions.forEach(f => facShift(e, f.k, +15, 'savaş hedefi tamamlandı'));
  if (e.id === 0) say('SAVAŞ HEDEFİ TAMAMLANDI — barış masasında güçlüsün', 'win');
}
function setWarGoal(e, foe, key){
  if (!e || !foe || !fedWarAllowed(e,foe)) return false;
  const G2 = WAR_GOALS[key];
  if (!G2) return false;
  if ((e.res.etk || 0) < G2.etk && !hasPerk(e,'freeWar')) return false;
  if (!hasPerk(e,'freeWar')) e.res.etk -= G2.etk;
  e.wg = e.wg || {};
  const extra = G2.setup ? G2.setup(e, foe) : {};
  e.wg[foe.id] = Object.assign({t:key, start:G.day}, extra);
  warLedgerGoal(warLedgerFind(e.id,foe.id), e.id);
  return true;
}
function warGoalProgress(e, foeId){
  if (!e.wg || !e.wg[foeId]) return 0;
  const foe = G.emps[foeId];
  if (!foe) return 0;
  const g = e.wg[foeId];
  const G2 = WAR_GOALS[g.t];
  if (!G2) return 0;
  return clamp(G2.prog(e, foe, g), 0, 1);
}
function warGoalText(e, foeId){
  if (!e.wg || !e.wg[foeId]) return '';
  const foe = G.emps[foeId], g = e.wg[foeId], G2 = WAR_GOALS[g.t];
  if (!foe || !G2) return '';
  return G2.txt(e, foe, g);
}
/* hedefe ulaşan taraf barış masasında avantajlıdır */
function warLeverage(e, foeId){
  const p = warGoalProgress(e, foeId);
  return Math.round(p * 260);
}

/* ---------- SAVAŞ YORGUNLUĞU ----------
   Uzun savaş halkı ve orduyu yorar. %100'e ulaşan taraf barışa
   mecbur kalır. Militarist devletler yarı hızda yorulur.        */
function exhOf(e, foeId){
  if (!e.exh) e.exh = {};
  return e.exh[foeId] || 0;
}
function addExh(e, foeId, amt, reason){
  e.exh = e.exh || {};
  let m = 1;
  if (hasPerk(e,'freeWar')) m = .5;              // Militarist 2
  if (hasPerk(e,'peaceAlways')) m = 1.4;         // Pasifist barışa itilir
  if (RACES[e.race].dip === 0) m *= .6;          // kovan zihni yorulmaz
  if (RACES[e.race].bio === 'makine') m *= .7;
  /* FAZ 15: Çarpanlar üst üste binince (militarist + kovan + makine)
     m 0.21'e düşüyor ve yorgunluk pratikte hiç dolmuyordu — ölçümde
     528 ay (44 yıl) süren savaşlar çıktı. Taban güvence: hiçbir
     doktrin savaşı sonsuz kılamaz. */
  m = Math.max(m, .45);
  e.exh[foeId] = clamp((e.exh[foeId] || 0) + amt * m, 0, 100);
  if (reason && e.id === 0 && amt >= 4)
    say('Savaş yorgunluğu +' + Math.round(amt*m) + ' — ' + reason, 'war');
}
function warExhTick(){
  // savaş hedefi ödülleri ve boyun eğdirme
  for (const e of G.emps){
    if (e.dead || e.wild || !e.wg) continue;
    for (const k in e.wg) if (e.war[k]){
      warGoalCheckReward(e, +k);
      if (typeof checkSubjugation === 'function') checkSubjugation(e, +k);
    }
  }
  for (const e of G.emps){
    if (e.dead || e.wild) continue;
    e.exh = e.exh || {};
    for (const o of G.emps){
      if (o.dead || o.wild || o.id === e.id) continue;
      if (!e.war[o.id]){
        // barışta yorgunluk yavaşça iyileşir
        if (e.exh[o.id]) e.exh[o.id] = Math.max(0, e.exh[o.id] - 2.5);
        continue;
      }
      let amt = 1.3;
      /* FAZ 16: PARYA'ya karşı savaşmak meşru bir dava sayılır —
         halk daha az yorulur. Paryanın kendisi ise yalnız
         savaştığı için daha hızlı yorulur. */
      if (typeof isPariah === 'function'){
        if (isPariah(o)) amt *= .45;          // ben paryaya saldırıyorum
        if (isPariah(e)) amt *= 1.5;          // ben paryayım, herkes üstüme geliyor
      }
      // kuşatılan koloniler yorgunluğu hızlandırır
      let besieged = 0;
      for (const c of e.colonies){
        const sy = G.sys[c.s];
        if (G.fleets.some(f => f.e === o.id && f.sys === sy.id && isArmed(f))) besieged++;
      }
      amt += besieged * .8;
      // hedefine ulaşamamış uzun savaş daha çok yorar
      /* Savaş uzadıkça yorgunluk HIZLANIR: 3 yıldan sonra her yıl
         biraz daha ağır gelir, 8 yıldan sonra halk dayanamaz. */
      const wsMonths = (G.day - ((e.warStart && e.warStart[o.id] !== undefined)
        ? e.warStart[o.id] : G.day)) / 30;
      if (wsMonths > 36) amt += .8 + (wsMonths - 36) * .035;
      if (wsMonths > 96) amt += 2.0;
      addExh(e, o.id, amt);

      if(e.exh[o.id]>=85&&e.exh[o.id]<100){const f=warLedgerFind(e.id,o.id);if(f)recordNews({category:'war',empires:[e.id,o.id],key:'war-exhaustion:'+f.id+':'+e.id,title:'Zorunlu barış yaklaşıyor',text:e.name+' savaş yorgunluğu %'+Math.floor(e.exh[o.id])+': %100 düzeyinde zorunlu barış uygulanır.',important:true});}
      // fraksiyonlar yorgunluktan etkilenir
      if (e.factions && e.exh[o.id] > 60 && rnd() < .2)
        facShift(e, 'halk', -3, 'savaş yorgunluğu');

      /* %100: ZORLA BARIŞ.
         canPeace() soğuma/kilit döndürebiliyordu ve o durumda savaş
         sonsuza dek sürüyordu. Yorgunluk doruğa vurduğunda ordu
         zaten savaşamaz: kilit ne olursa olsun barış dayatılır. */
      if (e.exh[o.id] >= 100){
        if (!canPeace(e, o)){
          /* Kilidi kır: savaş hedefi ve vekil savaş kayıtları düşer */
          if (e.wg) delete e.wg[o.id];
          if (o.wg) delete o.wg[e.id];
          if (e.proxyWar) delete e.proxyWar[o.id];
          if (o.proxyWar) delete o.proxyWar[e.id];
          e.war[o.id] = false; o.war[e.id] = false;
          e.peaceAt = e.peaceAt || {}; o.peaceAt = o.peaceAt || {};
          e.peaceAt[o.id] = G.day; o.peaceAt[e.id] = G.day;
          if (typeof remember === 'function'){
            remember(e, o.id, 'barisImzala');
            remember(o, e.id, 'barisImzala');
          }
          if (e.id === 0 || o.id === 0)
            say('ORDU SAVAŞAMIYOR — ' + (e.id===0?o.name:e.name) +
                ' ile çatışma kendiliğinden durdu', 'war');
          warLedgerSync('exhaustion',null);
        } else makePeace(e, o,'exhaustion',null);
        e.exh[o.id] = 55; o.exh = o.exh || {}; o.exh[e.id] = Math.min(o.exh[e.id]||0, 55);
        if (e.id === 0) say('SAVAŞ YORGUNLUĞU DORUKTA — ' + o.name + ' ile barış zorunlu oldu', 'war');
        else if (o.id === 0) say(e.name + ' savaştan çekildi — barış imzalandı', 'win');
      }
    }
  }
}
/* =====================================================================
   GALAKTİK KONSEY — "Birleşmiş Milletler"
   Pasifist bir imparatorluk kurar; tüm galaksi üye olabilir.
   Kararlar galaksi çapında bağlayıcıdır ve ihlal edenin bedeli vardır.
   ===================================================================== */

const COUNCIL_COST = 350;

/* oylama sıklığı — kurulum ekranından seçilir */
/* Meclis artık pasif değil: AI'lar mizaçlarına göre düzenli yasa
   teklif ediyor. Aralık AY (tur) cinsinden tutulur. */
const COUNCIL_PACE = {
  kapali:{n:'KAPALI', yil:0, ay:0,  d:'Konsey diplomasisi devre dışı'},
  sik   :{n:'SIK',    yil:1, ay:12, d:'12 turda bir oylama · yoğun meclis'},
  normal:{n:'NORMAL', yil:2, ay:18, d:'18 turda bir oylama · dengeli'},
  seyrek:{n:'SEYREK', yil:3, ay:30, d:'30 turda bir oylama · nadir ama ağır kararlar'}
};
function councilPaceMonths(){
  const k = (G.cfg && G.cfg.council) || 'normal';
  const p = COUNCIL_PACE[k];
  return p ? p.ay : 18;
}
function councilPaceYears(){
  const k = (G.cfg && G.cfg.council) || 'normal';
  const p = COUNCIL_PACE[k];
  return p ? p.yil : 5;
}

/* ---------- KARARLAR ---------- */
const COUNCIL_FOUND_TURN = 100;      // konsey bu turda kendiliğinden doğar

const RESOLUTIONS = {
  /* ═══ FAZ 72: İKİ YENİ KONSEY YASASI ═══ */
  /* ═══ FAZ 78: GALAKTİK BORSANIN KURULUŞU ═══
     Borsa artık oyunun başında AÇIK DEĞİL. Galaksinin ortak bir
     pazara ihtiyaç duyduğuna konseyin karar vermesi gerekiyor —
     ekonomik bütünleşme siyasi bir tercih olsun. */
  borsaKur  :{n:'Galaktik Borsayı Kur', ico:'💱',
    d:'Ortak bir takas merkezi açılır. Tüm devletler Enerji, Mineral ' +
      've Alaşım arasında serbestçe alışveriş yapabilir. Kurlar arz ve ' +
      'talebe göre dalgalanır.'},
  piyasaReg :{n:'Piyasa Regülasyonu', ico:'⚖',
    d:'Galaktik Piyasa komisyonu %8 → %3 iner. Ticaret ucuzlar, ' +
      'spekülasyon zorlaşır.'},
  casusSeffaf:{n:'Casusluk Şeffaflığı', ico:'🔍',
    d:'Tüm galakside operasyon başarı şansı kalıcı olarak −%18. ' +
      'Gölgede iş çevirmek zorlaşır.'},

  birlesme:{n:'Krize Karşı Birleşme', ico:'🛡', hedefli:false,
    d:'Galaktik kriz sürerken üyeler arasındaki tüm savaşlar dondurulur ve ' +
      'sınırlar karşılıklı açılır. Yalnızca kriz aktifken önerilebilir.',
    lean:{dip:1, war:.3}},
  parya   :{n:'Galaktik Parya Yaptırımı', ico:'⛔', hedefli:true,
    d:'Hedef devletin galaksiyle tüm ticareti kesilir ve üretimi %30 düşer. ' +
      'Yalnızca onuru −50 altına düşmüş devletler için önerilebilir.',
    lean:{dip:1}},
  ticaretStd:{n:'Evrensel Ticaret Standardı', ico:'⚖', hedefli:false,
    d:'Ortak ölçüler, ortak limanlar, tek muhasebe dili. Tüm üyelerin ticaret geliri %10 artar.',
    lean:{eco:1}},
  silahsiz:{n:'Silahsızlanma Antlaşması', ico:'🕊', hedefli:false,
    d:'Tüm üyelerin filo kapasitesi 30 birim azalır. Kapasiteyi aşan her ay itibar kaybeder.',
    lean:{mil:-1}},
  serbest :{n:'Serbest Ticaret Bölgesi', ico:'🤝', hedefli:false,
    d:'Üyelerin enerji üretim çarpanı +%12. Liman bağlantıları mevcut ticaret izni ve rota kurallarına tabidir.',
    lean:{eco:1}},
  bilim   :{n:'Bilim Ortaklığı', ico:'🔬', hedefli:false,
    d:'Tüm üyeler +%20 araştırma. Bilgi paylaşılır.',
    lean:{sci:1}},
  seferber:{n:'Kriz Seferberliği', ico:'🌋', hedefli:false,
    d:'Kriz filolarına karşı +%40 hasar. Üyeler ortak savunma hazinesine katkı verir.',
    lean:{war:.5}},
  muhafiz :{n:'Konsey Muhafızları', ico:'⚑', hedefli:false,
    d:'Üyeler ayda 6 alaşım bağışlar; konsey kendi filosunu kurar ve kararları uygular.',
    lean:{war:1}},
  savasYasak:{n:'Savaş Yasağı', ico:'🚫', hedefli:true,
    d:'Hedef imparatorluğa savaş açmak yasaklanır. İhlal eden TÜM konseyin düşmanı olur.',
    lean:{dip:1}},
  yaptirim :{n:'Yaptırım', ico:'⛔', hedefli:true,
    d:'Hedefin enerji, maden ve bilim üretim çarpanları −%25. Mevcut ticaret bağlantıları bu kararla korunur.',
    lean:{dip:.5, war:.5}},
  ihrac    :{n:'Konseyden İhraç', ico:'🚪', hedefli:true,
    d:'Hedef üyelikten atılır ve konsey ayrıcalıklarını kaybeder.',
    lean:{dip:.3}},

  /* ═══ FAZ 32: YENİ YASALAR ═══ */
  colYasak :{n:'Süper Silah Yasağı', ico:'☄', hedefli:false,
    d:'Colossus sınıfı gemilerin inşası yasaklanır. Yasağa rağmen ateşleyen ' +
      'devlet doğrudan Galaktik Parya ilan edilir.',
    lean:{dip:1, war:-.6}},
  arastirma:{n:'Araştırma Bütçeleri', ico:'🔬', hedefli:false,
    d:'Üyeler bilime yatırım yapmak zorunda: araştırma +%15, enerji −%10.',
    lean:{sci:1, eco:-.2}},
  sinirGuv :{n:'Sınır Güvenliği Paktı', ico:'🛡', hedefli:false,
    d:'Ortak savunma standardı: garnizon +%20, ticaret geliri −%15.',
    lean:{war:.6, eco:-.4}},
  casusInfaz:{n:'Casusluk İnfaz Yasası', ico:'⚖', hedefli:false,
    d:'Yakalanan ajanlar infaz edilir; mağdur devlet otomatik savaş nedeni kazanır ' +
      've casusluk riski tüm galakside artar.',
    lean:{dip:.5, war:.3}},
  gocSerbest:{n:'Serbest Göç Yasası', ico:'🚀', hedefli:false,
    d:'Üyeler arası nüfus akışı serbest: koloni büyümesi +%20, istikrar −5.',
    lean:{eco:.6, dip:.4}},
  /* ═══ FAZ 54: TİCARET AMBARGOSU ═══
     Hedefli tasarı: seçilen devletin enerji ve mineral üretimi
     düşer. Konseyin en sert ekonomik silahı. */
  ticAmbargo:{n:'Ticaret Ambargosu', ico:'🚫', hedefli:true,
    d:'Hedef devletin galaktik pazara erişimi kesilir: enerji ve ' +
      'mineral üretimi −%20. Konsey üyeleri onunla ticaret yapamaz.',
    lean:{eco:.4, dip:-.3}},

  /* ═══ FAZ 54: KRİZ HAZIRLIĞI ═══
     Galaksi tehdidi sezdiğinde tersaneler seferber olur. */
  krizHazir:{n:'Kriz Hazırlığı', ico:'🛠', hedefli:false,
    d:'Üyeler ortak üretim standardına geçer: gemi maliyetleri −%15, ' +
      'ama araştırma −%8 (mühendisler tezgâha kayar).',
    lean:{war:.5, sci:-.3}},
  madenTekel:{n:'Maden Tekeli', ico:'⛏', hedefli:false,
    d:'Konsey madenciliği düzenler: mineral +%18, araştırma −%8.',
    lean:{eco:1, sci:-.3}},

  /* ═══ FAZ 35: GALAKTİK SAVUNMA PAKTI ═══ */
  savunmaPakti:{n:'Galaktik Savunma Paktı', ico:'🛡', hedefli:false,
    d:'Hiçlik Sürüsü\'ne karşı ortak savunma: üyelerin filo kapasitesi +25, ' +
      'gemi bakımı −%20 ve krize karşı savaşan filolar +%15 hasar verir. ' +
      'Yalnızca kriz sırasında önerilebilir.',
    lean:{dip:.8, war:.5, sci:.3}}
};

function councilExists(){ return !!(G.council && !G.council.dead); }
function inCouncil(e){ return councilExists() && G.council.members.includes(e.id); }
function councilName(){
  const a = ['Galaktik','Yıldızlar','Evrensel','Büyük','Kadim'];
  const b = ['Konsey','Meclis','Birliği','Divanı','Forumu'];
  return pick(rnd, a) + ' ' + pick(rnd, b);
}
/* ═══════════════════════════════════════════════════════════════════
   DİPLOMATİK AĞIRLIK
   Konseyde söz hakkı yalnız topraktan gelmez. Sözünde durmayan bir
   imparatorluğun kürsüsü sessizleşir; küçük ama saygın bir devlet
   dev bir hainden daha gür konuşur.

     maddi  = 1 + √sistem×2,2 + √nüfus×0,55 + min(4, etki/500)
     çarpan = clamp(1 + onur/100 , 0,25 … 2,00)
     ağırlık = maddi × çarpan  (+ ideoloji ve civic bonusları)

   Karekök ölçek kasıtlıdır: doğrusal ölçekte 24 sistemli bir devlet
   tek sistemliyi 9 kat eziyor ve onurun hükmü kalmıyordu.
   ═══════════════════════════════════════════════════════════════════ */
function voteWeight(e){
  if (!e || e.dead) return 0;

  let pop = 0;
  for (const c of e.colonies){
    const pl = G.sys[c.s] && G.sys[c.s].planets[c.p];
    if (pl && pl.col) pop += pl.col.pop;
  }
  /* MADDÎ TABAN — karekök ölçekli.
     Doğrusal ölçekte 24 sistemli bir imparatorluk tek sistemliyi
     9 kat eziyordu ve onurun hiçbir hükmü kalmıyordu. Karekök,
     büyüklüğü hâlâ ödüllendirir ama tek başına belirleyici kılmaz. */
  const maddi = 1
    + Math.sqrt(sysCount(e)) * 2.2
    + Math.sqrt(Math.max(0, pop)) * .55
    + Math.min(4, (e.res.etk || 0) / 500);

  /* ONUR ÇARPANI — asıl belirleyici.
     −100 onur → ×0.25 (söz hakkı erir)
        0 onur → ×1.00
     +100 onur → ×2.00 (küçük ama saygın devlet kürsüde büyür) */
  const hon = (typeof honorOf === 'function') ? honorOf(e) : 0;
  const onurCarpan = clamp(1 + hon / 100, .25, 2.00);

  let w = maddi * onurCarpan;

  const mil = (e.ethics && e.ethics.mil) || 0;
  if (mil < 0) w += Math.abs(mil) * .8;              // pasifistler kürsüde güçlü
  if (hasCivic(e,'council')) w *= 2;                 // Konsey Mimarı
  if (hasCivic(e,'universal')) w *= 1.6;             // Evrensel Barış
  if (G.council && G.council.president === e.id) w *= 1.35;
  /* FAZ 37: Galaksinin Koruyucusu — krizi bitirenin sözü ağır basar */
  if (e.guardian) w *= 1.5;
  /* FAZ 48: reddedilen tasarı ağırlığı 5 yıl kırar */
  if (e._billPenalty && e._billPenalty > (G.memAge || 0)) w *= .75;
  return Math.max(.2, w);                            // hiç kimse tamamen susturulmaz
}
/* Arayüz için ayrıntı dökümü */
function voteWeightBreakdown(e){
  let pop = 0;
  for (const c of e.colonies){
    const pl = G.sys[c.s] && G.sys[c.s].planets[c.p];
    if (pl && pl.col) pop += pl.col.pop;
  }
  const hon = (typeof honorOf === 'function') ? honorOf(e) : 0;
  const maddi = 1 + Math.sqrt(sysCount(e)) * 2.2 + Math.sqrt(Math.max(0,pop)) * .55
              + Math.min(4, (e.res.etk||0) / 500);
  return {
    sistem: sysCount(e), nufus: Math.round(pop), etki: Math.round(e.res.etk||0),
    onur: hon, maddi: maddi.toFixed(1),
    carpan: clamp(1 + hon/100, .25, 2.00).toFixed(2),
    toplam: voteWeight(e).toFixed(1)
  };
}
function canFoundCouncil(e){
  if (councilExists()) return {ok:false, why:'Galaktik Konsey zaten kurulmuş.'};
  if (councilPaceYears() === 0) return {ok:false, why:'Bu galakside konsey devre dışı.'};
  const mil = (e.ethics && e.ethics.mil) || 0;
  if (mil > -2) return {ok:false, why:'Konseyi yalnızca Pasifist 2 veya üstü bir devlet kurabilir.'};
  const known = G.emps.filter(o=>!o.dead && !o.wild && o.id!==e.id && e.contact[o.id]).length;
  if (known < 2) return {ok:false, why:'En az 2 imparatorlukla temas gerekir (şu an ' + known + ').'};
  if ((e.res.etk||0) < COUNCIL_COST) return {ok:false, why:COUNCIL_COST + ' etki gerekir.'};
  return {ok:true};
}
function foundCouncil(e){
  const chk = canFoundCouncil(e);
  if (!chk.ok) return chk;
  e.res.etk -= COUNCIL_COST;
  const members = [e.id];
  // barış hâlindeki tanıdıklar kurucu üye olur
  for (const o of G.emps){
    if (o.dead || o.wild || o.id === e.id) continue;
    if (!e.contact[o.id] || e.war[o.id]) continue;
    if (RACES[o.race].dip <= .02) continue;          // kovan zihni katılmaz
    if (false) continue;
    members.push(o.id);
  }
  G.council = {
    name: councilName(), founder: e.id, members,
    laws: {}, targeted: {}, treasury: 0,
    president: e.id, termStart: G.day, terms: {},
    voteIn: 12, vote: null, dead: false
  };
  if(members.includes(0))recordNews({category:'council',scope:'player',empires:[0,...(e.id!==0?[e.id]:[])],title:'Galaktik Konsey kuruldu',text:G.council.name,important:true});
  G.council.terms[e.id] = 1;
  G.council.firstLaw = 'ticaretStd';       // ilk gündem daima ortak ticaret
  say('GALAKTİK KONSEY KURULDU — ' + G.council.name + ' · ' + members.length + ' üye', 'win');
  if (typeof facEvent === 'function') facEvent(e, 'ally');
  return {ok:true};
}
function joinCouncil(e){
  if (!councilExists() || inCouncil(e)) return false;
  if (e.wild || e.crisisSide) return false;      // Hiçlik Sürüsü diplomasi tanımaz
  if (G.council.targeted.ihrac === e.id) return false;
  G.council.members.push(e.id);
  return true;
}
function leaveCouncil(e){
  if (!inCouncil(e)) return false;
  G.council.members = G.council.members.filter(m => m !== e.id);
  // ayrılmak itibar kaybettirir
  for (const m of G.council.members){
    const o = G.emps[m];
    if (o) { o.rel[e.id] = clamp(o.rel[e.id] - 18, -100, 100); }
  }
  if (G.council.members.length < 2) G.council.dead = true;
  return true;
}

/* ---------- KARAR ETKİLERİ ---------- */
function councilMods(e){
  const m = {};
  if (!councilExists()) return m;
  const c = G.council;
  const member = inCouncil(e);
  if (member){
    /* Evrensel Ticaret Standardı: ticaret gelirinin %10'u kadar ek enerji.
       tr.mul zaten ticaretin gelire katkısı olduğundan, onun %10'unu
       eklemek tam olarak "ticaret geliri +%10" demektir. */
    if (c.laws.ticaretStd){
      const tr = e.trade;
      if (tr && tr.mul) m.eneMul = (m.eneMul||0) + tr.mul * .10;
    }
    if (c.laws.silahsiz) m.capFlat = (m.capFlat||0) - 30;
    if (c.laws.bilim)    m.araMul  = (m.araMul||0) + .20;
    if (c.laws.serbest)  m.eneMul  = (m.eneMul||0) + .12;
    /* ═══ FAZ 32 YASALARI ═══ */
    if (c.laws.arastirma){ m.araMul = (m.araMul||0) + .15; m.eneMul = (m.eneMul||0) - .10; }
    if (c.laws.sinirGuv){                       // garnizon etkisi groundTick'te
      const tr2 = e.trade;
      if (tr2 && tr2.mul) m.eneMul = (m.eneMul||0) - tr2.mul * .15;
    }
    if (c.laws.gocSerbest){ m.growMul = (m.growMul||0) + .20; m.stab = (m.stab||0) - 5; }
    if (c.laws.madenTekel){ m.minMul = (m.minMul||0) + .18; m.araMul = (m.araMul||0) - .08; }
    if (c.laws.krizHazir){ m.shipCost = (m.shipCost||0) - .15; m.araMul = (m.araMul||0) - .08; }
    /* FAZ 54: ambargo yalnız HEDEFİ vurur */
    if (c.targeted && c.targeted.ticAmbargo === e.id){
      m.eneMul = (m.eneMul||0) - .20;
      m.minMul = (m.minMul||0) - .20;
    }
    if (c.laws.savunmaPakti){
      m.capFlat = (m.capFlat||0) + 25;
      m.upMul = (m.upMul||0) - .20;
      m.crisisDmg = (m.crisisDmg||0) + .15;    // yalnız Sürü'ye karşı
    }
  }
  // yaptırım hedefi ağır bedel öder
  if (c.targeted.yaptirim === e.id){
    m.minMul = (m.minMul||0) - .25;
    m.eneMul = (m.eneMul||0) - .25;
    m.araMul = (m.araMul||0) - .25;
  }
  return m;
}
/* savaş yasağı kontrolü — declareWar buna bakar */
function councilBlocksWar(a, b){
  if (!councilExists()) return false;
  const c = G.council;
  if (Number.isInteger(c.targeted?.savasYasak) && c.targeted.savasYasak === b.id && inCouncil(a)) return true;
  return false;
}
/* yasağı çiğneyen tüm konseyin düşmanı olur */
function councilPunish(breaker){
  if (!councilExists()) return;
  const c = G.council;
  for (const m of c.members){
    if (m === breaker.id) continue;
    const o = G.emps[m];
    if (!o || o.dead) continue;
    o.rel[breaker.id] = clamp(o.rel[breaker.id] - 45, -100, 100);
    remember(o, breaker.id, 'konseyIhlal');
    if (!o.war[breaker.id] && rnd() < .55){
      o._lastCB = {n:'Konsey Kararını Uygula'};
      warAuthorize(o, breaker, o._lastCB);
      declareWar(o, breaker);
      warAuthClear();
    }
  }
  c.members = c.members.filter(m => m !== breaker.id);
  if (breaker.id === 0) say('KONSEY KARARINI ÇİĞNEDİN — üyelikten atıldın ve konsey sana savaş açıyor', 'war');
  else say(breaker.name + ' konsey kararını çiğnedi — konsey ona karşı harekete geçti', 'war');
}

/* ---------- OYLAMA ---------- */
function startCouncilVote(kampanya){
  const c = G.council;
  if (!c || c.dead || c.vote) return;
  /* Parya yasası yalnızca gerçekten onursuz bir devlet varsa gündeme
     gelebilir — konseyin en ağır silahı keyfî kullanılmaz. */
  const paryaAday = (typeof pariahCandidate === 'function') ? pariahCandidate() : null;
  const krizVar = (typeof crisisActive === 'function') && crisisActive();
  const open = Object.keys(RESOLUTIONS).filter(k => {
    const R = RESOLUTIONS[k];
    if (k === 'parya'){
      /* FAZ 37: çoklu parya — aday zaten parya değilse önerilebilir */
      if (!paryaAday) return false;
      const map = (typeof pariahMap === 'function') ? pariahMap() : {};
      return !map[paryaAday.id];
    }
    if (k === 'birlesme') return krizVar && !c.laws.birlesme;
    if (k === 'savunmaPakti') return krizVar && !c.laws.savunmaPakti;
    if (R.hedefli) return true;                 // hedefliler tekrar önerilebilir
    return !c.laws[k];
  });
  if (!open.length) return;
  /* Konsey kurulduktan sonraki İLK oylama daima Evrensel Ticaret
     Standardı'dır — galaksinin ilk ortak sınavı. */
  /* ═══ FAZ 32: GÜNDEM KUYRUĞU ═══
     Rastgele sponsor kaldırıldı. Masaya, kuyrukta arkasında en çok
     diplomatik ağırlık biriken teklif gelir. Sponsor = ilk öneren. */
  const kuyruk = kampanya ? kampanya.agenda
    : ((typeof topAgenda === 'function') ? topAgenda() : null);
  let sponsor = (kampanya && kampanya.sponsor !== null && kampanya.sponsor !== undefined)
    ? G.emps[kampanya.sponsor]
    : (kuyruk ? G.emps[kuyruk.by] : null);
  if (sponsor && (sponsor.dead || sponsor.id === 0)) sponsor = null;
  /* Sponsorun mizacına göre tercih sırası */
  const sponsorTercih = (sp) => {
    if (!sp) return [];
    const P = (typeof personaOf === 'function') ? personaOf(sp) : null;
    const nm = P ? P.n : '';
    if (nm === 'Tüccar')       return ['ticaretStd','serbest','bilim'];
    if (nm === 'Pasifist')     return ['silahsiz','savasYasak','bilim','ticaretStd'];
    if (nm === 'Militarist')   return ['muhafiz','seferber','yaptirim'];
    if (nm === 'İzolasyonist') return ['yaptirim','muhafiz','silahsiz'];
    if (nm === 'Yayılmacı')    return ['bilim','seferber','serbest'];
    return ['bilim','ticaretStd'];
  };

  let key;
  if (kampanya && open.includes(kampanya.key)){
    key = kampanya.key;
    if (c.firstLaw === key) c.firstLaw = null;
    if (kuyruk) c.agenda = (c.agenda || []).filter(a => a !== kuyruk);
  }
  else if (c.firstLaw && open.includes(c.firstLaw)){ key = c.firstLaw; c.firstLaw = null; }
  /* Varoluşsal gündemler kuyruğu ezer */
  else if (krizVar && open.includes('birlesme')) key = 'birlesme';
  else if (paryaAday && open.includes('parya')) key = 'parya';
  else if (kuyruk && open.includes(kuyruk.key)){
    key = kuyruk.key;
    /* Masaya gelen teklif kuyruktan düşer */
    c.agenda = (c.agenda || []).filter(a => a !== kuyruk);
  }
  else {
    const tercih = sponsorTercih(sponsor).filter(k => open.includes(k));
    key = tercih.length ? tercih[0] : open[Math.floor(rnd()*open.length)];
  }
  const R = RESOLUTIONS[key];
  let target = null;
  if (key === 'parya' && paryaAday){
    target = paryaAday.id;
  } else if (R.hedefli){
    const cands = G.emps.filter(o=>!o.dead && !o.wild && !o.crisisSide &&
      (key === 'ihrac' ? c.members.includes(o.id) : true) && o.id !== c.president);
    if (!cands.length) return;
    if (key === 'ticAmbargo'){
      /* ═══ FAZ 55: AMBARGO ZİRVEYİ HEDEFLER ═══
         Ticaret ambargosu bir kıskançlık aracıdır: konsey, önünde
         koşan devleti frenlemek için kullanır. Bu yüzden hedef
         "en savaşçı" değil, SKORU EN YÜKSEK olan devlettir.
         (Faz 54 şartnamesinde istenmişti; genel hedefleme
          kuralına düşüyordu.) */
      cands.sort((a,b)=>{
        const sa = (typeof scoreCard === 'function' && scoreCard(a))
          ? scoreCard(a).toplam : totalPower(a);
        const sb2 = (typeof scoreCard === 'function' && scoreCard(b))
          ? scoreCard(b).toplam : totalPower(b);
        return sb2 - sa;
      });
    } else {
      // hedef: en çok savaş açan veya en güçlü dış imparatorluk
      cands.sort((a,b)=>{
        const wa = Object.values(a.war||{}).filter(Boolean).length;
        const wb = Object.values(b.war||{}).filter(Boolean).length;
        return (wb*40 + totalPower(b)/100) - (wa*40 + totalPower(a)/100);
      });
    }
    target = cands[0].id;
  }
  c.vote = {key, target, opened:G.day, yes:[], no:[], speeches:[], done:false, age:0,
            sponsor: sponsor ? sponsor.id : null};
  /* Sponsor kendi teklifine oy verir */
  if (sponsor) c.vote.yes.push(sponsor.id);
  /* Kuyrukta bu teklifi destekleyenler de evet der — kampanya
     dönemi boyunca fikirlerini değiştirmezler. */
  if (kuyruk && kuyruk.key === key){
    for (const b of kuyruk.backers){
      if (b === 0 || (sponsor && b === sponsor.id)) continue;
      if (!G.emps[b] || G.emps[b].dead) continue;
      if (c.vote.yes.indexOf(b) < 0 && c.vote.no.indexOf(b) < 0) c.vote.yes.push(b);
    }
  }

  // AI üyeleri oy verir ve konuşur
  for (const id of c.members){
    if (id === 0) continue;
    if (sponsor && id === sponsor.id) continue;      // teklifi veren zaten evet dedi
    const o = G.emps[id];
    if (!o || o.dead) continue;
    /* HEGEMONYA: vasal bağımsız oy kullanamaz — senyörü adına susar,
       ağırlığı finishCouncilVote'ta senyörün oyuna eklenir. */
    if (typeof isVassal === 'function' && isVassal(o) &&
        c.members.includes(o.overlord)) continue;
    const p = aiProfile(o);
    let want = .35;
    const lean = R.lean || {};
    for (const k in lean) want += (p[k] || 0) * lean[k] * .55;

    /* ── GİZLİ MİZAÇ OYU ──
       İzolasyonistler ortak standartlara ilke gereği HAYIR der;
       tüccarlar ticaret yasalarını coşkuyla destekler. */
    const P = (typeof personaOf === 'function') ? personaOf(o) : null;
    if (P && key === 'ticaretStd') want += P.tradeVote;
    if (P && P.n === 'İzolasyonist' && !R.hedefli) want -= .30;
    if (P && P.n === 'Militarist' && key === 'silahsiz') want -= .60;
    if (P && P.n === 'Pasifist'   && key === 'silahsiz') want += .45;

    /* ═══ FAZ 35: KRİZ TEPKİSİ — İNAT VE PANİK ═══
       Pasifist ve bilimci tehdidi hemen görür. Militarist ve
       izolasyonist "biz kendi başımıza hallederiz" der — ta ki
       Sürü kapıya dayanana kadar. */
    if (key === 'savunmaPakti' || key === 'birlesme'){
      const tehlike = (typeof crisisProximity === 'function')
        ? crisisProximity(o) : 0;

      if (P){
        if (P.n === 'Pasifist')      want += 1.10;   // hemen evet
        else if (P.n === 'Tüccar')   want += .45;
        else if (P.n === 'Militarist')   want -= .95;   // "orduma güvenirim"
        else if (P.n === 'İzolasyonist') want -= 1.15;  // "bizi ilgilendirmez"
      }
      /* Bilimci profil tehdidi anlar.
         (Bu blokta profil değişkeni `p` — `prof` DEĞİL. Hotfix 23.1'de
          aynı türden bir kapsam hatası siyah ekrana yol açmıştı.) */
      if (p.sci > .6) want += .55;

      /* ── PANİK ──
         tehlike: 0 = uzak, 1 = sınırda, 2 = sistemim yutuldu.
         İnat ne kadar sertse panik o kadar sert kırılır. */
      if (tehlike >= 2) want += 3.0;               // gezegenim yutuldu
      else if (tehlike >= 1) want += 1.8;          // Sürü sınırımda
      else if (G.crisis && G.crisis.stage >= 3) want += 1.0;  // galaksi yanıyor

      /* Kendi filosu Sürü karşısında eriyorsa da akıllanır */
      if (typeof totalPower === 'function' && G.crisisId !== undefined){
        const sr = G.emps[G.crisisId];
        if (sr && totalPower(sr) > totalPower(o) * 2.2) want += .9;
      }
    }

    /* ═══ FAZ 32: SÜPER SİLAH YASAĞI — HAYATTA KALMA REFLEKSİ ═══
       Colossus'u olan ya da yapmayı planlayan asla evet demez;
       düşmanında Colossus olan çaresizce ister. */
    if (key === 'colYasak'){
      const benimVar = G.fleets.some(f => f.e === o.id && f.ships.length &&
        typeof isColossus === 'function' && isColossus(f));
      if (benimVar || (o.colossusReserve || 0) > 0) want -= 1.5;
      else {
        let tehdit = false;
        for (const f of G.fleets){
          if (!f.ships.length || f.e === o.id) continue;
          if (typeof isColossus !== 'function' || !isColossus(f)) continue;
          if (o.war[f.e] || (o.rel[f.e] || 0) < -30){ tehdit = true; break; }
        }
        if (tehdit) want += 1.2;
        if (P && P.n === 'Pasifist') want += .45;
        if (P && P.n === 'Militarist') want -= .35;
      }
    }

    /* FAZ 16: PARYA oylaması — tehdit puanı yüksekse kimse itiraz etmez */
    if (key === 'parya' && target !== null && G.emps[target]){
      const hedef = G.emps[target];
      const th = hedef.threat || 0;
      want += clamp(th / 90, 0, 1.1);                 // suç ne kadar açıksa o kadar evet
      if (o.war[hedef.id]) want += .45;               // düşmanımı cezalandırmak iyi
      if (o.ally[hedef.id]) want -= .9;               // müttefiğimi koruyorum
      if (typeof isVassal === 'function' && isVassal(hedef) &&
          hedef.overlord === o.id) want -= 1.2;       // vasalım, ben korurum
      if (P && P.n === 'Pasifist') want += .25;
      if (P && P.n === 'Tüccar') want -= .15;         // ticaret kesilmesi zararına
    }

    /* ── KRİZE KARŞI BİRLEŞME: varoluşsal tehdit mizaçları büker ──
       Ortak düşman herkesi masaya çeker, ama farklı sebeplerle. */
    if (key === 'birlesme' && P){
      if (P.n === 'İzolasyonist'){
        /* Sınır açmak doktrinlerine aykırı — ilkesel direnç. Ama
           kriz onların da kapısını çalıyorsa direnç kırılır. */
        want -= .45;
        if (typeof crisisPressure === 'function') want += crisisPressure(o) * .85;
      }
      else if (P.n === 'Militarist'){
        /* "Bu savaş bizim savaşımız" — düşman varken birleşmeyi sever,
           ama komuta bağımsızlığından ödün vermek istemez. */
        want += .30;
        if (typeof crisisPressure === 'function') want += crisisPressure(o) * .60;
        /* Aktif bir savaşı varsa onu bırakmak istemez */
        let acikSavas = 0;
        for (const w in o.war) if (o.war[w] && G.emps[w] && !G.emps[w].crisisSide) acikSavas++;
        want -= acikSavas * .28;
      }
      else if (P.n === 'Pasifist')  want += .40;
      else if (P.n === 'Tüccar')    want += .25;   // savaş ticareti bozar
      else if (P.n === 'Yayılmacı') want += .10;
    }

    /* Onursuz bir imparatorluğun önerisine güven duyulmaz */
    if (target !== null && typeof honorOf === 'function'){
      const th = honorOf(G.emps[target]);
      if (th < -25) want += .25;                    // itibarsız hedefe yaptırım kolay
    }
    if (target === id) want -= .9;                     // kendini hedefleyen karara hayır
    if (target !== null && o.war[target]) want += .35; // düşmanına yaptırım iyi gelir
    if (target !== null && o.ally[target]) want -= .5;
    /* ── KESİN İLKE ──
       İzolasyonist bir imparatorluk ortak standart yasalarına ilke
       gereği HAYIR der; bu bir olasılık değil, karakterdir. */
    /* ═══ FAZ 32: OY MANİPÜLASYONU ═══
       Rüşvet ve şantaj oyuncunun tarafına çeker. Rüşvet ölçülü,
       şantaj sert — ama ifşa riski taşır. */
    if (kampanya){
      /* ÖLÇÜM: tipik oylamada evet/hayır farkı toplam ağırlığın
         %48'i. Eski katsayılar (.85 / 1.10) bir üyeyi bile zor
         çeviriyordu. Manipülasyon gerçekten belirleyici olmalı —
         ama pahalı ve riskli olduğu için dengeli kalıyor. */
      const rusvet = kampanya.bribed[id];
      if (rusvet) want += rusvet * 1.6;
      const sn = kampanya.blackmailed.find(b =>
        (b.id !== undefined ? b.id : b) === id);
      if (sn) want += (sn.yon !== undefined ? sn.yon : 1) * 2.2;
    }

    /* FAZ 35: ultimatoma boyun eğen pakta evet demek zorunda */
    if ((key === 'savunmaPakti' || key === 'birlesme') && o._paktSoz !== undefined)
      want += 3.5;

    let yes;
    if (P && P.n === 'İzolasyonist' && (key === 'ticaretStd' || key === 'serbest')) yes = false;
    else if (target === id) yes = false;                // kimse kendini hedefleyene evet demez
    else yes = rnd() < clamp(want, .05, .95);
    (yes ? c.vote.yes : c.vote.no).push(id);
    if (c.vote.speeches.length < 4 && rnd() < .6)
      c.vote.speeches.push({id, txt: aiSpeech(o), yes});
  }
  if (c.members.includes(0) && G.emps[0] && !G.emps[0].dead) UI.councilVote();
  else finishCouncilVote();
}
// BETA-P0.1: ballot identity survives Save8 and distinguishes repeated laws.
function councilVoteToken(v){
  return v?v.key+':'+(v.target===null||v.target===undefined?'':v.target)+':'+(Number.isFinite(v.opened)?v.opened:'legacy'):'';
}
function castCouncilVote(e,yes,token){
  const c=G.council,v=c&&c.vote;
  if(!e||!c||!c.members.includes(e.id))return {ok:false,why:'Konsey üyesi değilsin'};
  if(!v||v.done)return {ok:false,why:'Açık oylama yok'};
  if(token!==councilVoteToken(v))return {ok:false,why:'Oylama değişti; güncel oylamayı aç'};
  if(typeof isVassal==='function'&&isVassal(e)&&c.members.includes(e.overlord))return {ok:false,why:'Senyörün adına oy kullanılıyor'};
  if(v.yes.includes(e.id)||v.no.includes(e.id))return {ok:false,why:'Oyun zaten kaydedildi'};
  (yes?v.yes:v.no).push(e.id);finishCouncilVote();return {ok:true};
}
function finishCouncilVote(){
  const c = G.council;
  if (!c || !c.vote || c.vote.done) return;
  const ballot={key:c.vote.key,target:c.vote.target,opened:Number.isFinite(c.vote.opened)?c.vote.opened:null,yes:c.vote.yes.slice(),no:c.vote.no.slice(),expired:(c.vote.age||0)>24};
  c.vote.done = true;
  let yw = 0, nw = 0;
  /* Senyörün oyu, konseydeki vasallarının ağırlığını da taşır */
  const hg = id => voteWeight(G.emps[id]) +
    ((typeof hegemonyWeight === 'function') ? hegemonyWeight(G.emps[id]) : 0);
  for (const id of c.vote.yes) yw += hg(id);
  for (const id of c.vote.no)  nw += hg(id);
  // Evrensel Barış civic'i tek başına karar geçirir
  const uni = c.vote.yes.some(id => hasCivic(G.emps[id],'universal'));
  const passed = uni || yw > nw;
  const R = RESOLUTIONS[c.vote.key];
  /* FAZ 48: oyuncu tasarısı reddedildiyse bedel öder */
  if (!passed && c.vote.sponsor !== null && c.vote.sponsor !== undefined){
    const sp = G.emps[c.vote.sponsor];
    if (sp && !sp.dead && sp._billPending &&
        sp._billPending.key === c.vote.key && typeof billRejected === 'function'){
      billRejected(sp, c.vote.key);
      delete sp._billPending;
    }
  } else if (passed){
    const sp2 = G.emps[c.vote.sponsor];
    if (sp2 && sp2._billPending) delete sp2._billPending;
  }
  if (passed){
    if (R.hedefli){
      /* ═══ FAZ 56: DİNAMİK AMBARGO HEDEFİ ═══
         Ticaret Ambargosu 3 aylık kampanya boyunca oylanır. O süre
         içinde skor lideri değişebilir — eski lidere vurmak
         ambargonun amacını (zirveyi frenlemek) boşa çıkarır.
         Bu yüzden hedef, tasarı MECLİSTEN GEÇTİĞİ AN yeniden
         hesaplanır. Diğer hedefli tasarılar oylanan hedefte kalır:
         orada oyuncular bilinçli bir devlete oy vermiştir. */
      if (c.vote.key === 'ticAmbargo'){
        const adaylar = G.emps.filter(o => !o.dead && !o.wild && !o.crisisSide &&
          o.id !== c.president);
        if (adaylar.length){
          adaylar.sort((a, b) => {
            const sa = (typeof scoreCard === 'function' && scoreCard(a))
              ? scoreCard(a).toplam : totalPower(a);
            const sb2 = (typeof scoreCard === 'function' && scoreCard(b))
              ? scoreCard(b).toplam : totalPower(b);
            return sb2 - sa;
          });
          const yeni = adaylar[0].id;
          if (yeni !== c.vote.target){
            const eski = G.emps[c.vote.target];
            say('🚫 Ambargo hedefi güncellendi — kampanya sırasında ' +
                adaylar[0].name + ' zirveye çıktı' +
                (eski ? ' (' + eski.name + ' yerine)' : ''), 'sci');
            c.vote.target = yeni;
          }
        }
      }
      c.targeted[c.vote.key] = c.vote.target;
      // 96C.1: the targeted vote previously omitted the activation flag read by
      // councilBlocksWar; a passed protection vote could never take effect.
      if(c.vote.key === 'savasYasak') c.laws.savasYasak = true;
      if (c.vote.key === 'parya'){
        if (typeof addPariah === 'function') addPariah(c.vote.target);  // FAZ 37
        const t = G.emps[c.vote.target];
        if (t){
          /* Parya ilan edilen devletin tüm ticaret anlaşmaları düşer */
          for (const o of G.emps){
            if (o.dead || o.wild || o.id === t.id) continue;
            if (typeof breakPact === 'function') breakPact(t, o);
            if (typeof remember === 'function') remember(t, o.id, 'yaptirim');
          }
          t._trAt = -1;
          if (t.id === 0)
            say('GALAKTİK PARYA İLAN EDİLDİN — tüm ticaretin kesildi, üretimin −%30', 'war');
          else
            say('GALAKTİK PARYA: ' + t.name + ' galaksiden dışlandı', 'war');
        }
      }
      if (c.vote.key === 'ihrac'){
        c.members = c.members.filter(m => m !== c.vote.target);
      }
    } else {
      c.laws[c.vote.key] = true;
      if (c.vote.key === 'birlesme' && typeof applyUnity === 'function') applyUnity();
    }
    G.emps.forEach(x=>{ if (!x.dead) recalcMods(x); });
  }
  if (c.members.includes(0)){
    const tName = c.vote.target !== null && G.emps[c.vote.target] ? ' · ' + G.emps[c.vote.target].name : '';
    const spName = (c.vote.sponsor !== null && G.emps[c.vote.sponsor])
      ? G.emps[c.vote.sponsor].name + ' teklif etti · ' : '';
    say('Konsey: ' + spName + R.n + tName + ' — ' + (passed ? 'KABUL' : 'RED') +
        ' (' + Math.round(yw) + '/' + Math.round(yw+nw) + ' ağırlık)', passed?'win':'');
  }
  // BETA-P0.2: one bounded public result; original ballot identity and applied target differ for dynamic sanctions.
  c.lastVote={...ballot,appliedTarget:c.vote.target,ended:G.day,passed,weight:{yes:yw,no:nw},eventKey:'council:'+c.vote.key+':'+G.day};
  recordNews({category:'council',scope:'public',empires:[],key:c.lastVote.eventKey,title:'Konsey kararı — '+R.n,text:(passed?'Kabul edildi':'Reddedildi')+' · EVET '+yw.toFixed(1)+' / HAYIR '+nw.toFixed(1)+' · gün '+G.day,important:true});
  c.vote = null;
}

/* ---------- DÖNEM VE BAŞKANLIK ---------- */
/* ═══════════════════════════════════════════════════════════════════
   GALAKTİK KONSEY'İN DOĞUŞU
   100. turda galaksi kendiliğinden masaya oturur. Kimse kurmasa da
   konsey doğar; kurucu, o an diplomatik ağırlığı en yüksek olandır.
   Sürgün ve Korsan Krallığı doktrinleri dışarıda kalır.
   ═══════════════════════════════════════════════════════════════════ */
function foundCouncilByConvention(){
  if (councilExists()) return false;
  if (typeof councilPaceYears === 'function' && councilPaceYears() === 0) return false;

  const uygun = G.emps.filter(o =>
    !o.dead && !o.wild &&
        G.emps.some(x => !x.dead && !x.wild && x.id !== o.id && o.contact[x.id]));
  if (uygun.length < 3) return false;               // meclis için en az üç taraf

  uygun.sort((a,b) => voteWeight(b) - voteWeight(a));
  const baskan = uygun[0];

  G.council = {
    name: (typeof councilName === 'function') ? councilName() : 'Galaktik Konsey',
    founder: baskan.id, members: uygun.map(o => o.id),
    laws: {}, targeted: {}, treasury: 0,
    president: baskan.id, terms: {}, termAge: 0,
    voteIn: 2, vote: null, dead: false, byConvention: true
  };
  G.council.terms[baskan.id] = 1;

  say('GALAKTİK KONSEY KURULDU — ' + G.council.name + ' · ' +
      uygun.length + ' üye · başkan ' + baskan.name, 'win');
  if (typeof UI !== 'undefined' && UI.councilFounded) UI.councilFounded(baskan);

  /* İlk yasa gündemi hazır: Evrensel Ticaret Standardı */
  G.council.firstLaw = 'ticaretStd';
  return true;
}

function councilTick(){
  if (!councilExists()){
    /* Turu gelen konsey her hâlükârda doğar; gelmediyse pasifist bir
       imparatorluk erken kurabilir (aiTryFoundCouncil). */
    if ((G.memAge || 0) >= COUNCIL_FOUND_TURN){
      if (!foundCouncilByConvention()) aiTryFoundCouncil();
    } else {
      aiTryFoundCouncil();
    }
    return;
  }
  const c = G.council;
  c.members = c.members.filter(m => G.emps[m] && !G.emps[m].dead);
  if (c.members.length < 2){ c.dead = true; return; }
  if (typeof agendaTick === 'function') agendaTick();   // FAZ 32: gündem kuyruğu

  // Konsey Muhafızları: hazine
  if (c.laws.muhafiz){
    for (const m of c.members){
      const o = G.emps[m];
      if (!o || o.dead) continue;
      const give = Math.min(6, o.res.ala);
      o.res.ala -= give; c.treasury += give;
    }
  }
  // Silahsızlanma ihlali
  if (c.laws.silahsiz){
    for (const m of c.members){
      const o = G.emps[m];
      if (!o || o.dead) continue;
      if (fleetUsage(o) > o.cap){
        for (const x of c.members){
          if (x === m) continue;
          const q = G.emps[x];
          if (q) q.rel[m] = clamp(q.rel[m] - 3, -100, 100);
        }
        if (m === 0) say('Silahsızlanma antlaşmasını aşıyorsun — konsey rahatsız', 'war');
      }
    }
  }
  /* ═══ FAZ 51: BAŞKANLIK DÖNEMİ 15 YIL ═══
     Daimi hükümdarlık ilan edilmişse seçim yapılmaz — taht
     sabittir ve Diplomatik Hegemonya zaferinin ön şartı sağlanır. */
  c.termAge = (c.termAge || 0) + 1;
  if (c.permanent !== undefined && c.permanent !== null){
    c.president = c.permanent;
    c.termAge = 0;
  }
  else if (c.termAge >= PRESIDENT_TERM){
    c.termAge = 0;
    let best = c.members[0], bw = -1;
    for (const m of c.members){
      const w = voteWeight(G.emps[m]);
      if (w > bw){ bw = w; best = m; }
    }
    const changed = best !== c.president;
    c.president = best;
    c.terms[best] = (c.terms[best] || 0) + 1;
    if (c.members.includes(0)){
      const nm = G.emps[best] ? G.emps[best].name : '?';
      say('Konsey başkanlığı: ' + nm + (best===0?' (sen)':'') +
          ' · ' + c.terms[best] + '. dönem', best===0?'win':'');
    }
    if (best === 0 && typeof checkVictory === 'function') checkVictory(G.p, 'council');
  }
  // açık oylama zaman aşımı — oyuncu oy kullanmazsa 24 ayda kapanır
  if (c.vote && !c.vote.done){
    c.vote.age = (c.vote.age || 0) + 1;
    if (c.vote.age > 24) finishCouncilVote();
  }
  // oylama zamanı (ay sayacı — gün senkronuna bağlı değil)
  if (!c.vote){
    c.voteIn = (c.voteIn === undefined ? 12 : c.voteIn) - 1;
    /* ═══ FAZ 32: KAMPANYA DÖNEMİ ═══
       Oylama iki aşamalı: önce gündem ilan edilir ve 3 ay kampanya
       yürütülür (rüşvet/şantaj penceresi), sonra oylar toplanır. */
    if (c.campaign){
      if (typeof aiCampaignTick === 'function') aiCampaignTick();  // FAZ 33
      c.campaign.left--;
      if (c.campaign.left <= 0){
        const kmp = c.campaign;
        c.campaign = null;
        startCouncilVote(kmp);
      }
    } else if (c.voteIn <= 0){
      c.voteIn = Math.max(6, councilPaceMonths());
      prepareCouncilVote();
    }
  }
  // AI'lar ara ara katılır — pasifistler daha istekli
  for (const o of G.emps){
    if (o.dead || o.wild || inCouncil(o)) continue;
    if (RACES[o.race].dip <= .02) continue;
    if (false) continue;
    if (o.id === 0) continue;
    const pmil = (o.ethics && o.ethics.mil) || 0;
    const eager = .04 + (pmil < 0 ? .10 : 0) + (aiProfile(o).dip * .06);
    if (rnd() < eager){
      joinCouncil(o);
      if (c.members.includes(0)) say(o.name + ' Galaktik Konsey\'e katıldı');
    }
  }
}

/* Konsey Hâkimiyeti zaferi için ilerleme */
function councilDominance(e){
  if (!councilExists()) return 0;
  const c = G.council;
  const terms = (c.terms && c.terms[e.id]) || 0;
  const share = c.members.length ? voteWeight(e) / c.members.reduce((a,m)=>a+voteWeight(G.emps[m]),0) : 0;
  return Math.min(terms/3, share/.45);
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 1 — ONUR/GÜVEN ENDEKSİ, CASUS BELLI VE SOĞUK SAVAŞ
   ═══════════════════════════════════════════════════════════════════ */

/* Güven endeksi: −100 (kan davası) … +100 (kardeşlik) */
function trustOf(e, id){
  if (!e) return 0;
  let sum = 0;
  for (const m of e.mem?.[id]||[]) sum += m.v;
  /* ═══ FAZ 48: DİPLOMATİK AHLAK ═══
     DÜRÜST devletin güven tavanı yükselir (sözü daha çok değer
     taşır); SAHTEKÂR devlete karşı başlangıç güveni düşüktür. */
  const hedef = G.emps[id];
  const tavan = 100 + ((hedef && hedef.mods && hedef.mods.trustCap) || 0);
  const taban = ((hedef && hedef.mods && hedef.mods.trustStart) || 0);
  return clamp(sum + taban, -100, tavan);
}
function grudgeOf(e, id){ return Math.max(0, -trustOf(e, id)); }

/* ONUR: galaksinin bu imparatorluk hakkındaki ORTAK kanaati.
   Sözünde duran yükselir, ihanet eden çöker. */
function honorOf(e){
  if (!e) return 0;
  if (e.wild || e.crisisSide) return 0;          // krizin onuru yoktur
  /* ÖNEMLİ: yalnızca HAKKINDA KANAATİ OLAN imparatorluklar sayılır.
     Eskiden tarafsızlar da ortalamaya giriyordu ve tek bir ihanet
     (−95) beş imparatorluklu galakside −19'a kadar sulanıyordu;
     onur pratikte hiç kıpırdamıyordu. Artık kanaat sahipleri
     üzerinden ortalanır, ama tek bir öfkeli komşu tüm galaksiyi
     temsil etmesin diye payda en az 2 kabul edilir. */
  let sum = 0, n = 0;
  for (const o of G.emps){
    if (o.dead || o.wild || o.id === e.id) continue;
    const t = trustOf(o, e.id);
    if (t === 0) continue;
    sum += t; n++;
  }
  if (!n) return 0;
  return Math.round(sum / Math.max(2, n));
}

/* Arayüzde gösterilecek en ağır anılar */
function topMemories(e, id, n){
  if (!e || !e.mem || !e.mem[id]) return [];
  return e.mem[id].slice()
    .sort((a,b)=>Math.abs(b.v) - Math.abs(a.v))
    .slice(0, n || 3)
    .map(m => ({txt: (typeof MEM_KINDS !== 'undefined' && MEM_KINDS[m.k]) ? MEM_KINDS[m.k].n : m.k,
                v: Math.round(m.v)}));
}

/* İki imparatorluk kaç aydır sınır teması yaşıyor? */
function frictionMonths(aId, bId){
  if (!G.friction) return 0;
  return Math.max(G.friction[aId + '_' + bId] || 0, G.friction[bId + '_' + aId] || 0);
}

/* ─── SOĞUK SAVAŞ ───
   İttifak bozulduktan sonra taraflar 3 tur (ay) birbirine savaş
   açamaz. Bu süre oyuncuya hazırlık ve diplomatik onarım şansı verir. */
const COLD_WAR_TURNS = 3;
function setColdWar(a, b, turns){
  a.coldWar = a.coldWar || {}; b.coldWar = b.coldWar || {};
  const until = (G.memAge || 0) + (turns || COLD_WAR_TURNS);
  a.coldWar[b.id] = until; b.coldWar[a.id] = until;
}
function inColdWar(a, b){
  return !!(a.coldWar && a.coldWar[b.id] > (G.memAge || 0));
}
function coldWarLeft(a, b){
  if (!inColdWar(a, b)) return 0;
  return a.coldWar[b.id] - (G.memAge || 0);
}

/* ─── CASUS BELLI ───
   AI sebepsiz savaş açamaz. Sebep bu kaynaklardan gelir. */
function casusBelliOf(e, o){
  if (!e || !o) return null;

  /* ═══ FAZ 40: YENİDEN BİRLEŞME ═══
     Balkanizasyonla ayrılan iki taraf birbirini meşru saymaz.
     Ardıl devlet "asıl varisim ben" der, ana gövde "isyancı
     eyaletim" der. Bu CB kalıcıdır — barış imzalansa bile
     yeniden savaş açmak için gerekçe hazır bekler. */
  if ((e.sundered && e.sundered === o.id) || (o.sundered && o.sundered === e.id))
    return {k:'reunify', w:1.20, n:'Yeniden Birleşme'};

  /* FAZ 40: ZAFER GANİMETİ — Özgürlük Savaşı'nın galipleri
     yıkılmış zalimden toprak talep edebilir (10 yıllık pencere). */
  {
    const ra = G.rebelAlliance;
    if (ra && ra.done && ra.wonAt !== undefined && ra.target === o.id &&
        (G.memAge || 0) - ra.wonAt <= 120 &&
        (ra.members.indexOf(e.id) >= 0 || e.id === 0))
      return {k:'ganimet', w:.95, n:'Zafer Ganimeti'};
  }

  /* FAZ 29: Geç oyunda derinleşen düşmanlık başlı başına gerekçedir.
     Kutuplaşma ilişkiyi −70'in altına indirmişse "Uzlaşmaz Husumet"
     savaş nedeni doğar — galaksi donmaz. */
  if ((G.year || 2210) - 2210 >= POLARIZE_YEAR && (e.rel[o.id] || 0) <= -70)
    return {k:'husumet', w:.75, n:'Uzlaşmaz Husumet'};

  let border = false;
  for (const s of G.sys){
    if (aiKnownSystem(e,s)?.owner !== o.id) continue;
    for (const l of s.lanes) if (G.sys[l].owner === e.id){ border = true; break; }
    if (border) break;
  }
  /* Kovan zihni ve Sürgün doktrini: diplomasi kavramları yok,
     sınır komşuluğu tek başına yeterli sebeptir. */
  const noDiplo = (RACES[e.race] && RACES[e.race].dip <= .02) || false;
  if (noDiplo && border) return {k:'dogal', w:.85, n:'Yayılma Doktrini'};

  const g  = grudgeOf(e, o.id);
  const fm = frictionMonths(e.id, o.id);
  const mem = (e.mem && e.mem[o.id]) || [];
  const has = k => mem.some(m => m.k === k);

  /* En ağır sebepten en hafife */
  if (has('ihanet'))      return {k:'ihanet',    w:1.30, n:'İhanetin Bedeli'};
  /* FAZ 4: ortaya çıkan komplo, çiğnenen sözden bile ağırdır —
     entrikacı yıllarca sinsi davranmıştır, affı yoktur. */
  /* Sahte bayrak ifşası, ihanetten bile ağır sayılır: yalnız saldırmadı,
     suçunu masum birine yıkmaya çalıştı. */
  if (has('sahteBayrak')) return {k:'sahteBayrak', w:1.35, n:'İstihbarat Sabotajı — Sahte Bayrak'};
  if (has('komplo'))      return {k:'komplo',    w:1.20, n:'İstihbarat Sabotajı'};
  if (has('paktBozdu'))   return {k:'yalanci',   w:1.10, n:'Çiğnenen Söz'};
  if (has('sistemAldi'))  return {k:'irredanta', w:1.00, n:'Kayıp Topraklar'};

  /* ── ÖNLEYİCİ MÜDAHALE (Megayapı Kıskançlığı) ──
     Bir devlet galaksiyi değiştirecek bir harika inşa ediyorsa,
     rakipleri tamamlanmadan durdurmak ister. Militarist ve
     Yayılmacı mizaçlar bu baskıya en açık olanlardır. */
  if (typeof megaBuilds === 'function'){
    const mb = megaBuilds(o).filter(w=>aiView(e).ctx.visible.has(w.sys.id));
    if (mb.length){
      const P = (typeof personaOf === 'function') ? personaOf(e) : null;
      const mz = P ? (P.n === 'Militarist' ? 1.00 :
                      P.n === 'Yayılmacı'  ? .85  :
                      P.n === 'Tüccar'     ? .55  :
                      P.n === 'İzolasyonist'? .45 : .30) : .55;
      /* Tamamlanmaya ne kadar yakınsa panik o kadar büyük */
      let yakinlik = 0;
      for (const w of mb) yakinlik = Math.max(yakinlik, 1 - (w.left / Math.max(1, w.tot)));
      const agirlik = .55 + mz * .60 + yakinlik * .35;
      if (agirlik >= .78)
        return {k:'onleyici', w: Math.min(1.45, agirlik), n:'Önleyici Müdahale'};
    }
  }

  if (has('konseyIhlal')) return {k:'konsey',    w:.95, n:'Konsey Kararını Uygula'};
  if (has('sabotaj'))     return {k:'sabotaj',   w:.85, n:'Gizli Savaşa Karşılık'};
  if (g >= 35)            return {k:'kin',       w:.80, n:'Kan Davası'};
  // 94D.1: elapsed adjacency alone is not a casus belli.
  if (has('kervanYagma') || has('yaptirim')) return {k:'korsan', w:.60, n:'Ticaret Yollarını Koru'};
  if (g >= 15 && fm >= 8) return {k:'gerginlik', w:.55, n:'Süregelen Gerginlik'};

  /* YAŞAM ALANI KURALI (%85)
     Yerleşecek yeri kalmamış imparatorluk, kendisinden en az %85
     büyüklükteki komşusunun toprağına göz diker. */
  if (border && typeof colonizeTargets === 'function'){
    const room = colonizeTargets(e).length;
    /* MİZAÇ: taban eşik %85; militarist bunu %59,5'e çeker ve elinde
       hâlâ bir yerleşim yeri varken bile talepte bulunabilir. */
    const P = (typeof personaOf === 'function') ? personaOf(e) : null;
    const esik = 0.85 * (P ? P.lifeSpace : 1);
    const tol  = P ? P.roomTol : 0;
    if (room <= tol && aiKnownSystems(e,o.id).length >= sysCount(e) * esik && e.rel[o.id] < 10)
      return {k:'yasamalani', w:.62 + (P && P.warBias > 0 ? .08 : 0), n:'Yaşam Alanı Talebi'};
  }

  /* İç politika da bir savaş sebebidir */
  if (e.factions){
    for (const f of e.factions)
      if (f.k === 'asker' && f.pow >= 45 && f.mood <= 30 && border)
        return {k:'ordu', w:.65, n:'Ordunun Talebi'};
  }
  return null;
}

/* Savaş iştahı: fırsat + sebep + kimlik − frenler */
function warAppetite(e, o){
  const prof = aiProfile(e);
  const estimate=shownPower(e,o);
  const ratio = totalPower(e) / (estimate.v*(1+estimate.band) + 1);
  const opportunity = clamp((ratio - 1.05) * .85, -1, 1.1);

  const cb = casusBelliOf(e, o);
  const cause = cb ? cb.w : 0;
  const grudge = grudgeOf(e, o.id) / 100;

  let identity = prof.war * .50;
  if (e.factions) for (const f of e.factions){
    if (f.k === 'asker'  && f.mood < 40) identity += (f.pow / 100) * .45;
    if (f.k === 'halk'   && f.mood > 65) identity -= .25;
    if (f.k === 'tuccar' && f.mood > 60) identity -= .20;
  }

  let brake = intelOf(e,o.id)<1?.55:0;
  if (typeof exhOf === 'function') brake += (exhOf(e, o.id) / 100) * .85;
  let openWars = 0;
  for (const w in e.war) if (e.war[w]) openWars++;
  if (openWars >= 2) brake += .55;
  if (e.pact && e.pact[o.id]) brake += .35;
  if (e.nap && e.nap[o.id] > G.day) brake += 1.30;
  if ((e.inc && e.inc.ene || 0) < 0) brake += .40;
  const _P = (typeof personaOf === 'function') ? personaOf(e) : null;
  if (honorOf(e) > 25) brake += .30 * (_P ? _P.honorCare : 1);
  if (typeof councilExists === 'function' && councilExists() &&
      inCouncil(e) && inCouncil(o)) brake += .45;
  /* Müttefike saldırmak neredeyse imkânsız — AI önce ittifakı bozar */
  if (e.ally[o.id]) brake += 2.20 - Math.min(1.1, grudge * 1.4);

  /* ═══ FAZ 40: GANİMET İŞTAHI ═══
     İki ayrı açgözlülük kaynağı: */
  let ganimet = 0;

  /* 1. YENİDEN BİRLEŞME — ayrılmış kardeşe karşı ebedi dava.
     Uysal bir ardıl devlet istemiyoruz; iki taraf da diğerini
     yutmak ister. */
  if ((e.sundered && e.sundered === o.id) || (o.sundered && o.sundered === e.id)){
    ganimet += .70;
    if (_P && _P.n === 'Militarist') ganimet += .30;
  }

  /* 2. ZAFER GANİMETİ — Özgürlük Savaşı biter bitmez eski
     isyancılar yıkılmış zalimin üstüne çullanır. Fırsat penceresi
     10 yıl; militarist ve yayılmacı karakterler daha hevesli. */
  const ra = G.rebelAlliance;
  if (ra && ra.done && ra.wonAt !== undefined && ra.target === o.id){
    const gecen = (G.memAge || 0) - ra.wonAt;
    if (gecen <= 120 && (ra.members.indexOf(e.id) >= 0 || e.id === 0)){
      const taze = 1 - gecen / 120;             // zamanla soğur
      let istah = .55 * taze;
      if (_P){
        if (_P.n === 'Militarist') istah *= 1.9;
        else if (_P.n === 'Yayılmacı') istah *= 1.7;
        else if (_P.n === 'Tüccar') istah *= .8;
        else if (_P.n === 'Pasifist') istah *= .25;
      }
      if (prof.war > .6) istah *= 1.4;
      ganimet += istah;
    }
  }

  return {score: opportunity * .55 + cause * .90 + grudge * .55 + identity +
                 ganimet - brake,
          ratio, cause, cb, grudge, brake, ganimet};
}

/* Hafızadaki yara savaş HEDEFİNİ belirler */
function pickCasusBelli(e, o){
  const mem = (e.mem && e.mem[o.id]) || [];
  const has = k => mem.some(m => m.k === k);

  /* ── BOYUN EĞDİRME ──
     Yok etmek yerine boyunduruk altına almak: ezici üstünlük varken,
     hedef hâlâ yaşayabilir durumdayken ve etki yeterliyken tercih
     edilir. Militarist hegemonya kurmayı, Tüccar vergi almayı sever;
     ihanet gibi affedilmez suçlarda ise yok etme öne geçer. */
  if (!has('ihanet') && !has('sahteBayrak') && (e.res.etk || 0) >= 45){
    const oran = totalPower(e) / (aiKnownPower(e,o) + 1);
    if (oran > 1.6 && aiKnownSystems(e,o.id).length >= 2){
      const P = (typeof personaOf === 'function') ? personaOf(e) : null;
      let istek = .35;
      if (P){
        if (P.n === 'Militarist') istek += .30;
        else if (P.n === 'Tüccar') istek += .28;
        else if (P.n === 'Yayılmacı') istek += .10;
        else if (P.n === 'İzolasyonist') istek -= .20;
      }
      /* Zaten vasalı çoksa daha da hevesli olur (hegemonya hırsı) */
      if (typeof vassalsOf === 'function') istek += vassalsOf(e).length * .10;
      if (rnd() < clamp(istek, 0, .80)) return 'boyun';
    }
  }

  /* ── BOYUN EĞDİRME ──
     Ezici üstünlük varsa yok etmek yerine boyunduruk altına almak
     daha kârlıdır: vergi, kapasite ve konseyde ikinci oy demektir.
     Ama pahalıdır (45 etki) ve yalnızca gerçekten güçlüyken mantıklı. */
  const oran = totalPower(e) / (aiKnownPower(e,o) + 1);
  if (oran > 1.8 && (e.res.etk || 0) >= 45 && !isVassal(o) && !isVassal(e)){
    const P = (typeof personaOf === 'function') ? personaOf(e) : null;
    let istek = .35;
    if (P){
      if (P.n === 'Yayılmacı') istek += .30;      // hegemonya kurmayı sever
      else if (P.n === 'Tüccar') istek += .25;    // vergi cazip
      else if (P.n === 'Militarist') istek -= .05;
      else if (P.n === 'İzolasyonist') istek -= .20;
      else if (P.n === 'Pasifist') istek += .15;  // yok etmektense boyun eğdir
    }
    /* İhanete uğramışsan affetmezsin, yok edersin */
    if (has('ihanet') || has('sahteBayrak')) istek -= .45;
    if (rnd() < clamp(istek, 0, .75)) return 'boyun';
  }

  /* ── BOYUN EĞDİRME ──
     Yok etmek pahalı ve itibar yakıcıdır; boyunduruk hem kalıcı gelir
     hem konseyde oy demektir. Güçlü ve hegemonyacı devletler bunu
     yok etmeye tercih eder. */
  if (typeof isVassal === 'function' && !isVassal(o) &&
      !has('ihanet') && !has('sahteBayrak')){
    const oran = totalPower(e) / (aiKnownPower(e,o) + 1);
    const P = (typeof personaOf === 'function') ? personaOf(e) : null;
    let hevesli = .30;
    if (P){
      if (P.n === 'Militarist')      hevesli += .30;   // boyunduruk sever
      else if (P.n === 'Tüccar')     hevesli += .25;   // vergi sever
      else if (P.n === 'Yayılmacı')  hevesli += .15;
      else if (P.n === 'Pasifist')   hevesli -= .15;
      else if (P.n === 'İzolasyonist') hevesli -= .20;
    }
    /* Konsey varsa hegemonya siyaseten daha değerli */
    if (typeof councilExists === 'function' && councilExists() &&
        inCouncil(e) && inCouncil(o)) hevesli += .25;
    /* Zaten vasalı olan devlet imparatorluk kurmayı sürdürür */
    if (typeof vassalsOf === 'function' && vassalsOf(e).length) hevesli += .20;
    /* Ezici üstünlük gerekiyor: boyun eğdirmek uzun bir savaştır */
    if (oran > 1.35 && rnd() < clamp(hevesli, 0, .85) &&
        (e.res.etk || 0) >= (WAR_GOALS.boyun ? WAR_GOALS.boyun.etk : 45))
      return 'boyun';
  }
  if (has('ihanet') || has('paktBozdu')) return 'yoketme';
  if (has('sahteBayrak'))                return 'yoketme'; // affedilmez
  if (has('komplo'))                     return 'yikim';   // ağını dağıt
  if (has('sistemAldi'))                 return 'fetih';
  if (has('sabotaj') || has('casusYakalan')) return 'bilgi';
  if (has('kervanYagma') || has('yaptirim')) return 'harac';
  const prof = aiProfile(e);
  if (prof.war > .90) return 'yikim';
  if (prof.eco > .70) return 'harac';
  if (prof.sci > .80) return 'bilgi';
  return 'fetih';
}

/* ─── YETKİ PROTOKOLÜ ───
   AI savaşları yalnızca aiWarReview veya yükümlülük yoluyla açılır. */
function warAuthorize(a, b, why){ G._warAuth = a.id + '>' + b.id; G._warWhy = why || null; }
function warAuthClear(){ G._warAuth = null; G._warWhy = null; }

/* ─── AYLIK SAVAŞ MECLİSİ ───
   Tüm AI savaş kararlarının tek kapısı. */
function aiWarReview(){
  for (const e of G.emps){
    if (e.dead || e.wild || !e.ai) continue;
    if(aiCoalitionCommit(e))continue;
    if (hasCivic(e,'shadow') || hasCivic(e,'universal')) continue;

    let open = 0;
    for (const w in e.war) if (e.war[w] && G.emps[w] && !G.emps[w].wild) open++;
    if (open >= 2) continue;                      // ikiden fazla cephe açma

    let best = null;
    for (const o of G.emps){
      if (o.dead || o.wild || o.id === e.id) continue;
      if (!e.contact[o.id] || e.war[o.id]) continue;
      if (false) continue;
      if (inColdWar(e, o)) continue;              // 3 turluk soğuk savaş
      /* FAZ 16: kriz kapıdayken iç hesaplaşma ertelenir */
      if (typeof crisisActive === 'function' && crisisActive() &&
          typeof crisisPressure === 'function' && crisisPressure(e) > .35 &&
          !o.crisisSide) continue;
      /* Senyör vasalına, vasal senyörüne savaş açmaz (isyan ayrı yoldan) */
      if (typeof isVassal === 'function' &&
          (o.overlord === e.id || e.overlord === o.id)) continue;
      /* Aynı senyörün vasalları birbiriyle savaşmaz */
      if (e.overlord !== undefined && e.overlord !== null &&
          e.overlord === o.overlord) continue;
      /* Galaktik Odak: birleşme yasası üye-içi savaşı yasaklar */
      if (typeof unityActive === 'function' && unityActive() &&
          councilExists() && G.council.members.includes(e.id) &&
          G.council.members.includes(o.id)) continue;

      const g = grudgeOf(e, o.id);
      const lastPeace = (e.peaceAt && e.peaceAt[o.id] !== undefined) ? e.peaceAt[o.id] : -9999;
      if (G.day - lastPeace < 720 - g * 5) continue;

      if(typeof aiStrategicWarReady==='function'&&!aiStrategicWarReady(e,o))continue;
      const ap = warAppetite(e, o);
      if (!ap.cb) continue;                       // SEBEP YOK → SAVAŞ YOK
      if (ap.score < .92 - ap.grudge * .45) continue;
      if (ap.ratio < .55 && ap.grudge < .80) continue;
      if(!aiWarAccess(e,o).ok)continue;

      if (!best || ap.score > best.ap.score) best = {o, ap};
    }
    if (!best) continue;

    if (!fedWarAllowed(e,best.o)){
      if (canFedWarRequest(e,best.o).ok) proposeFedWar(e,best.o);
      continue;
    }

    /* Karar aylara yayılır: savaş patlamaz, gerginlik birikir. */
    const chance = clamp((best.ap.score - .92 + best.ap.grudge * .55) * .20, .015, .34);
    if (rnd() > chance) continue;

    const budget=aiWarBudget(e,best.o);
    if(!budget.ok){AIDiagnostics.note('war-deferred:'+budget.reason,e,best.o);continue;}

    if (typeof setWarGoal === 'function' && typeof WAR_GOALS !== 'undefined'){
      const key = pickCasusBelli(e, best.o);
      const cost = WAR_GOALS[key] ? WAR_GOALS[key].etk : 999;
      setWarGoal(e, best.o, (e.res.etk >= cost) ? key : 'fetih');
    }
    e._lastCB = best.ap.cb;
    warAuthorize(e, best.o, best.ap.cb);
    declareWar(e, best.o);
    warAuthClear();
  }
}

/* ─── İTTİFAK GÖZDEN GEÇİRME ───
   AI ani ihanet etmez: önce ittifakı bozar, 3 turluk soğuk savaş
   başlar, ancak ondan sonra savaş açabilir. Oyuncuya uyarıdır. */
/* Normal bilateral withdrawal. Federation and sovereign bonds use their own exits. */
function canEndAlliance(e,o){
  if(!e||!o||e===o||G.emps[e.id]!==e||G.emps[o.id]!==o||e.dead||o.dead||e.wild||o.wild)return {ok:false,why:'Devlet artık mevcut veya geçerli değil'};
  if(sovereignPair(e,o))return {ok:false,why:'Vassallık bağı normal ittifak feshiyle değiştirilemez; sözleşme veya bağımsızlık yönetimini kullan'};
  const f=findFed(e),other=findFed(o);
  if(f&&other&&f.id===other.id)return {ok:false,why:'Aynı federasyondaki ittifak bağı üyelik düzeninin parçasıdır. Federasyon Yönetimi içindeki Ayrıl veya İhraç işlemini kullan',federation:true};
  if(!e.ally[o.id]&&!o.ally[e.id])return {ok:false,why:'Sonlandırılabilecek bir ittifak yok'};
  return {ok:true};
}
function applyAllianceEnd(e,o){
  e.ally[o.id] = false; o.ally[e.id] = false;
  e.rel[o.id] = clamp(e.rel[o.id] - 15, -100, 100);
  o.rel[e.id] = clamp(o.rel[e.id] - 15, -100, 100);
  remember(o, e.id, 'paktBozdu');
  for (const w of G.emps){
    if (w.dead || w.wild || w.id === e.id || w.id === o.id) continue;
    if (rnd() < .5) remember(w, e.id, 'paktBozdu');
  }
  setColdWar(e, o, COLD_WAR_TURNS);
}
function endAlliance(e,o){
  const gate=canEndAlliance(e,o);if(!gate.ok)return gate;
  applyAllianceEnd(e,o);
  say('İTTİFAK SONLANDIRILDI — '+o.name+' · '+COLD_WAR_TURNS+' ay soğuk savaş','war');
  return {ok:true};
}

function aiReviewAlliances(){
  for (const e of G.emps){
    if (e.dead || e.wild || !e.ai) continue;
    const prof = aiProfile(e);
    for (const o of G.emps){
      if (o.dead || o.wild || o.id === e.id || !e.ally[o.id]) continue;

      let bound = 0;
      if (typeof findFed === 'function'){
        const fe = findFed(e), fo = findFed(o);
        if (fe && fo && fe === fo) bound += 40;
      }
      if (typeof councilExists === 'function' && councilExists() &&
          inCouncil(e) && inCouncil(o)) bound += 15;
      for (const x of G.emps)
        if (!x.dead && !x.wild && x.id !== e.id && x.id !== o.id &&
            e.war[x.id] && aiKnownWar(e,o,x)) bound += 35;

      const strain = (-trustOf(e, o.id)) + (-e.rel[o.id] * .4) - bound + (prof.war - .5) * 20;
      if (strain > 45 && rnd() < .05){
        applyAllianceEnd(e,o);
        if (o.id === 0)
          say('İTTİFAK BOZULDU — ' + e.name + ' anlaşmayı feshetti (' +
              COLD_WAR_TURNS + ' tur soğuk savaş)', 'war');
        else if (e.id !== 0)
          say(e.name + ' ile ' + o.name + ' arasındaki ittifak dağıldı');
      }
    }
  }
}

/* Aylık diplomasi tiki — monthTick buradan çağırır */
function diploTick(){
  if(G.warLedger?.fronts.some(f=>f.coalition&&f.ended===null))warCoalitionTick();
  if (typeof memTick === 'function') memTick();
  embargoTick();                 // güven çökünce ticaret kesilir
  pariahReview();
  if (typeof guardianTick === 'function') guardianTick();   // FAZ 37
  if (typeof rebelTick === 'function') rebelTick();         // FAZ 38: isyancı ittifakı
  if (typeof rebelVictoryCheck === 'function') rebelVictoryCheck(); // FAZ 39: balkanizasyon                // itibar onarılırsa parya statüsü kalkar
  aiReviewAlliances();
  if (typeof whisperTick === 'function') whisperTick();          // fısıltı ağları
  if (typeof counterIntelTick === 'function') counterIntelTick(); // gecikmeli ifşa
  unityTick();                                                   // galaktik odak
  megaWatchTick();                                               // harika izleme
  threatTick();                                                  // galaktik tehdit erimesi
  polarizeTick();                                                // FAZ 29: geç oyun kutuplaşması
  hegemonyTick();                                                // FAZ 30: güç korkusu
  crisisDiplomacyTick();                                         // kriz diplomasisi
  if (typeof aiStructTick === 'function') aiStructTick();
  if (typeof aiForwardBaseTick === 'function') aiForwardBaseTick();  // FAZ 56        // AI uzay inşaatı
  if (typeof aiLogisticsTick === 'function') aiLogisticsTick();  // ikmal geri çekilmesi
  vassalTick();                                                  // vergi, öfke, isyan
  if (typeof aiDisbandTick === 'function') aiDisbandTick();       // ekonomik terhis
  if (typeof aiOpsTick === 'function') aiOpsTick();               // AI casusluk operasyonları
  if (typeof aiArmyTick === 'function') aiArmyTick();             // FAZ 22: ordu komutası
  if (typeof aiFalseFlagTick === 'function') aiFalseFlagTick();   // FAZ 34: AI sahte bayrak
  if (typeof aiTerraformTick === 'function') aiTerraformTick();   // FAZ 36: AI diriliş
  if (typeof aiPatronageTick === 'function') aiPatronageTick();   // FAZ 45: AI himayesi
  if (typeof aiStatusQuoTick === 'function') aiStatusQuoTick();   // FAZ 49: statüko refleksi
  if (typeof fedFundTick === 'function') fedFundTick();           // FAZ 49: federal fon
  if (typeof sabotageTick === 'function') sabotageTick();          // FAZ 59
  if (typeof loopBuildTick === 'function') loopBuildTick();        // FAZ 60
  if (typeof aiDirectiveTick === 'function') aiDirectiveTick();    // FAZ 62
  if (typeof directiveTick === 'function') directiveTick();        // FAZ 61
  if (typeof schismTick === 'function') schismTick();              // FAZ 61
  if (typeof marketTick === 'function') marketTick();              // FAZ 66
  if (typeof aiMarketTick === 'function') aiMarketTick();          // FAZ 68
  if (typeof aiIntelPactTick === 'function') aiIntelPactTick();    // FAZ 68
  if (typeof edictTick === 'function') edictTick();                // FAZ 71
  if (typeof cohesionTick === 'function') cohesionTick();          // FAZ 71
  if (typeof aiSubmitTick === 'function') aiSubmitTick();          // FAZ 71
  if (typeof aiEdictTick === 'function') aiEdictTick();            // FAZ 72
  if (typeof aiFedLawTick === 'function') aiFedLawTick();          // FAZ 72
  /* ═══ FAZ 79: DURUMLAR DERİN UYKUDA ═══
     Oyuncu isteği: sistem hiçbir şekilde çalışmasın. Kod silinmedi
     (SITUATIONS kataloğu ve motor duruyor), yalnız tik zinciri
     kesildi. Yeniden açmak için tek satır yeter. */
  // if (typeof situationsTick === 'function') situationsTick();   // FAZ 77C — UYKUDA
  if (typeof separatistTick === 'function') separatistTick();      // FAZ 78
  if (typeof leaderTick === 'function') leaderTick();              // FAZ 78B
  if (typeof disgraceTick === 'function') disgraceTick();          // FAZ 79
  if (typeof throneTick === 'function') throneTick();              // FAZ 77B
  if (typeof hungerTick === 'function') hungerTick();              // FAZ 77B
  if (typeof warSubsidyTick === 'function') warSubsidyTick();     // FAZ 45: savaş yardımı
  if (typeof visionTick === 'function') visionTick();             // FAZ 48: paylaşılan görüş
  if (typeof colossusGuardLock === 'function') colossusGuardLock(); // FAZ 31: koruma kilidi
  if (typeof aiColossusTick === 'function') aiColossusTick();     // FAZ 25: süper silah sevki
  if (typeof hitLogTick === 'function') hitLogTick();             // soğuk dosya soruşturması
  aiWarReview();
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 3 — EKONOMİK SAVAŞ: AMBARGOLAR VE GALAKTİK PARYA
   Savaş artık cepheden önce masada başlar. Güven çökünce ticaret
   kesilir; onur çökünce galaksi devleti topluca dışlar.
   ═══════════════════════════════════════════════════════════════════ */

/* Ambargonun devreye girdiği güven eşiği — mizaca göre değişir.
   Tüccar parayı sever, ticareti son ana kadar sürdürür. */
const EMBARGO_TRUST = -40;
function embargoThreshold(e){
  const P = (typeof personaOf === 'function') ? personaOf(e) : null;
  if (!P) return EMBARGO_TRUST;
  if (P.n === 'Tüccar')       return -60;   // kâr uğruna daha çok dayanır
  if (P.n === 'İzolasyonist') return -30;   // zaten kapalı, çabuk keser
  if (P.n === 'Militarist')   return -35;
  return EMBARGO_TRUST;
}

/* 94D: voluntary sanctions cannot coexist with a direct subject bond,
   alliance or federation. Council pariah law remains a separate global rule. */
function sovereignPair(a,b){return !!(a&&b&&(a.overlord===b.id||b.overlord===a.id));}
function protectedDiplomaticPair(a,b){
  if(!a||!b)return false;
  const fa=findFed(a),fb=findFed(b);
  return sovereignPair(a,b)||!!(a.ally&&a.ally[b.id]||b.ally&&b.ally[a.id])||!!(fa&&fb&&fa.id===fb.id);
}
function clearBilateralEmbargo(a,b){
  let changed=false;
  for(const [e,o] of [[a,b],[b,a]])if(e.embargo&&e.embargo[o.id]){delete e.embargo[o.id];changed=true;}
  if(changed){a._trAt=b._trAt=-1;}
  return changed;
}
function normalizeDiplomaticBindings(){
  let repaired=0;
  for(const e of G.emps){
    if(e.overlord!=null&&(!G.emps[e.overlord]||G.emps[e.overlord].dead||e.overlord===e.id)){
      e.overlord=null;e.vassalType=null;e.vassalAnger=0;e.edicts={};repaired++;
    }
  }
  for(let i=0;i<G.emps.length;i++)for(let j=i+1;j<G.emps.length;j++){
    const a=G.emps[i],b=G.emps[j];if(!a||!b||a.dead||b.dead)continue;
    if(sovereignPair(a,b)&&(a.war[b.id]||b.war[a.id])){
      a.war[b.id]=false;b.war[a.id]=false;warLedgerSync('subject-binding',null);repaired++;
    }
    if(protectedDiplomaticPair(a,b)&&clearBilateralEmbargo(a,b))repaired++;
    if(a.war[b.id]||b.war[a.id])endTreatiesForWar(a,b);
  }
  return repaired;
}
function embargoOn(e, id){
  if (!e) return false;
  if (G.council && (typeof pariahMap === 'function') && pariahMap()[id] &&
      e.id !== id) return true;              // parya ile kimse ticaret yapamaz
  return !!(e.embargo && e.embargo[id] && !protectedDiplomaticPair(e,G.emps[id]));
}
/* İki taraf arasında ticaret akabiliyor mu? */
/* FAZ 10: Kaçakçılık ağı — Ambargo Kaçakçılığı operasyonu bir hattı
   geçici olarak yeniden açar. Savaş hâli delinemez. */
function smuggling(a, b){
  if (!a || !b) return false;
  return !!(a.smuggle && a.smuggle[b.id] > G.day) ||
         !!(b.smuggle && b.smuggle[a.id] > G.day);
}
function tradeBlocked(a, b){
  if (!a || !b) return true;
  if (a.war[b.id]) return true;
  const kesik = embargoOn(a, b.id) || embargoOn(b, a.id);
  if (kesik && smuggling(a, b)) return false;    // kaçakçılık hattı açık tutar
  return kesik;
}

function setEmbargo(e, target, on, sebep){
  if (!e || !target) return false;
  e.embargo = e.embargo || {};
  if (on){
    if(e.id===target.id||e.dead||target.dead||protectedDiplomaticPair(e,target))return false;
    if (e.embargo[target.id]) return false;
    e.embargo[target.id] = true;
    if (typeof breakPact === 'function') breakPact(e, target);
    if (typeof remember === 'function') remember(target, e.id, 'yaptirim');
    target.rel[e.id] = clamp(target.rel[e.id] - 12, -100, 100);
    if (target.id === 0) say(e.name + ' sana TİCARİ AMBARGO uyguladı' +
      (sebep ? ' — ' + sebep : ''), 'war');
    else if (e.id === 0) say(target.name + ' imparatorluğuna ambargo uygulandı', 'war');
  } else {
    if (!e.embargo[target.id]) return false;
    delete e.embargo[target.id];
    if (target.id === 0) say(e.name + ' ambargoyu kaldırdı', 'win');
  }
  /* ticaret önbelleklerini geçersiz kıl */
  recordNews({category:'economy',empires:[e.id,target.id],title:on?'Ticari ambargo':'Ambargo kaldırıldı',text:e.name+' → '+target.name+' · '+(sebep||(e.ai===false?'oyuncu kararı':'AI kararı'))});
  e._trAt = -1; target._trAt = -1;
  return true;
}

/* Kaç imparatorluk hedefe ambargo uyguluyor ve ne kadar ağır? */
function embargoPressure(target){
  let n = 0, weight = 0;
  for (const o of G.emps){
    if (o.dead || o.wild || o.id === target.id) continue;
    if (embargoOn(o, target.id)){
      n++;
      weight += 1 + sysCount(o) * .15 + (o.trade && o.trade.vol ? o.trade.vol / 260 : 0);
    }
  }
  return {n, weight};
}
/* Ambargonun üretime yansıması — recalcMods buradan besleniyor */
function embargoMods(e){
  const out = {};
  const parya = (typeof isPariah === 'function') && isPariah(e);

  /* GALAKTİK PARYA konseyin en ağır silahıdır ve TEK BAŞINA uygulanır:
     zaten "tüm galaksiyle ticaret kesik" demek olduğundan üstüne bir de
     tek tek ambargo cezası binmez — yoksa ceza −%48'e kadar çıkıyordu. */
  if (parya){
    out.eneMul = -.30; out.minMul = -.30;
    out.araMul = -.30; out.alaMul = -.30;
    return out;
  }
  const p = embargoPressure(e);
  if (p.n){
    /* Asıl acı, kesilen ticaret ağının kendisidir (rota + lüks mal
       kaybı). Buradaki modifikatör yalnızca ek sürtünmedir; sert
       olmamalı. Tavan %18: üç dört devlet birden ambargo uygularsa
       ekonomi zorlanır ama çökmez. */
    const bite = clamp(p.weight * .020, 0, .18);
    out.eneMul = -bite;
    out.minMul = -bite * .6;
    out.araMul = -bite * .5;
  }
  return out;
}
function isPariah(e){
  if (!e || !G.council) return false;
  const map = (typeof pariahMap === 'function') ? pariahMap() : null;
  return !!(map && map[e.id]);
}

/* ─────────────────────────────────────────────────────────────
   OTOMATİK AMBARGO — soğuk ekonomik savaş
   Güven eşiğin altına düşünce ticaret kendiliğinden kesilir;
   güven onarılınca kendiliğinden geri açılır.
   ───────────────────────────────────────────────────────────── */
function embargoTick(){
  normalizeDiplomaticBindings();
  for (const e of G.emps){
    if (e.dead || e.wild || e.ai!==true) continue;
    for (const o of G.emps){
      if (o.dead || o.wild || o.id === e.id) continue;
      if (!e.contact[o.id]) continue;

      const t   = (typeof trustOf === 'function') ? trustOf(e, o.id) : 0;
      const esik = embargoThreshold(e);
      const acik = embargoOn(e, o.id);

      /* Müttefikler ve federasyon ortakları ambargo uygulamaz */
      let bagli = protectedDiplomaticPair(e,o);
      if (!bagli && typeof findFed === 'function'){
        const fe = findFed(e), fo = findFed(o);
        if (fe && fo && fe === fo) bagli = true;
      }

      if (!acik && !bagli && t <= esik){
        setEmbargo(e, o, true, 'güven ' + Math.round(t));
        /* Ambargo karşılıklıdır: hedef de misilleme yapar */
        if (!embargoOn(o, e.id) && !o.ally[e.id] && o.ai)
          setEmbargo(o, e, true, 'misilleme');
      }
      /* Güven onarıldıysa ambargo kalkar (parya yasası hariç) */
      else if (acik && e.embargo && e.embargo[o.id] && t > esik + 18){
        setEmbargo(e, o, false);
      }
    }
  }
}

/* ─────────────────────────────────────────────────────────────
   GALAKTİK PARYA YASASI
   Onuru −50'nin altına düşen devlet konseyin gündemine girer.
   Kabul edilirse tüm galaksiyle ticareti kesilir ve üretimi −%30.
   ───────────────────────────────────────────────────────────── */
const PARIAH_HONOR = -50;
const PARIAH_THREAT = 70;      // FAZ 16: gerekçesiz savaş eşiği

/* Parya adaylığının İKİ yolu var:
   a) onur çöküşü (sözünü tutmayan)  b) galaktik tehdit (gerekçesiz
   savaş açan). İkincisi Faz 15'te eklenen e.threat üzerinden gelir. */
function pariahCandidate(){
  if (!councilExists()) return null;
  let worst = null, skor = 0;
  for (const o of G.emps){
    if (o.dead || o.wild) continue;
    const h = honorOf(o);
    const t = o.threat || 0;
    const onurSuclu  = h <= PARIAH_HONOR;
    const tehditSuclu = t >= PARIAH_THREAT;
    if (!onurSuclu && !tehditSuclu) continue;
    /* Ağırlıklı suç puanı: ikisi birden varsa çok daha ağır */
    const s2 = (onurSuclu ? (PARIAH_HONOR - h) : 0) + (tehditSuclu ? (t - PARIAH_THREAT) * 1.2 : 0);
    if (!worst || s2 > skor){ worst = o; skor = s2; }
  }
  return worst;
}
/* Bu devlet neden parya adayı? Arayüz ve konsey konuşmaları için. */
function pariahReason(o){
  if (!o) return null;
  const h = honorOf(o), t = o.threat || 0;
  if (h <= PARIAH_HONOR && t >= PARIAH_THREAT) return 'onursuzluk ve gerekçesiz savaş';
  if (t >= PARIAH_THREAT) return 'gerekçesiz savaş';
  if (h <= PARIAH_HONOR) return 'onursuzluk';
  return null;
}
/* ═══════════════════════════════════════════════════════════════════
   FAZ 36 — GALAKTİK AF
   ÖLÇÜM (Faz 35): AI sahte bayrak 158 denemede 39 fiyasko verdi;
   her fiyasko bir parya ilanı. Parya statüsünden tek çıkış yolu
   itibar onarımıydı — ama fiyasko tehdit puanını +75 yaptığı için
   pratikte erişilemezdi. Galakside parya enflasyonu oluşuyordu.

   ÇÖZÜM: AI'nın risk alma iştahına DOKUNULMADI. Bunun yerine
   parya statüsüne 120 aylık (10 yıl) bir sayaç konuldu. Süre
   dolunca af çıkar: ambargolar kalkar, statü düşer — ama
   ilişkiler ve anılar SIFIRLANMAZ. Galaksi affeder, unutmaz.
   ═══════════════════════════════════════════════════════════════════ */
const PARIAH_AMNESTY_MONTHS = 120;

function pariahReview(){
  const c = G.council;
  if (!c) return;
  const map = pariahMap();
  if (!map) return;
  let degisti = false;

  /* FAZ 37: HER PARYA BAĞIMSIZ DEĞERLENDİRİLİR */
  for (const key of Object.keys(map)){
    const id = +key;
    const t = G.emps[id];
    if (!t || t.dead){ removePariah(id); degisti = true; continue; }

    const gecen = (G.memAge || 0) - (map[key].since || 0);

    /* YOL 1 — İTİBAR ONARIMI (erken çıkış) */
    if (honorOf(t) > PARIAH_HONOR + 25 && (t.threat || 0) < PARIAH_THREAT - 25){
      removePariah(id);
      degisti = true;
      if (id === 0) say('PARYA STATÜSÜ KALKTI — itibarını onardın, ticaret yolların açıldı', 'win');
      else say(t.name + ' parya statüsünden çıktı');
      continue;
    }

    /* YOL 2 — GALAKTİK AF (10 yıl sonra otomatik) */
    if (gecen >= PARIAH_AMNESTY_MONTHS){
      removePariah(id);
      degisti = true;
      for (const x of G.emps){
        if (x.dead || x.wild || x.crisisSide || x.id === id) continue;
        if (x.embargo) delete x.embargo[id];
      }
      t.threat = Math.round((t.threat || 0) * .5);
      t._amnesty = (G.memAge || 0);
      if (id === 0)
        say('GALAKTİK AF — 10 yıllık dışlanma bitti. Ambargolar kalktı, ' +
            'ama kimse yaptığını unutmadı.', 'win');
      else
        say(t.name + ' galaktik afla parya statüsünden çıktı');
    }
  }
  if (degisti) G.emps.forEach(x => { if (!x.dead) recalcMods(x); });
}

/* Arayüz için: belirli bir devletin affına ne kadar kaldı? */
function pariahAmnestyLeft(id){
  const map = pariahMap();
  if (!map) return null;
  const hedef = (id !== undefined) ? id
    : (G.council && G.council.targeted ? G.council.targeted.parya : undefined);
  if (hedef === undefined || !map[hedef]) return null;
  return Math.max(0, PARIAH_AMNESTY_MONTHS -
    ((G.memAge || 0) - (map[hedef].since || 0)));
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 5 — GALAKTİK ODAK: KRİZE KARŞI BİRLEŞME
   Kriz varken konsey üyeleri arasındaki savaşlar dondurulur ve
   sınırlar açılır. Kriz biterse yasa kendiliğinden düşer.
   ═══════════════════════════════════════════════════════════════════ */

/* Kriz bu devleti ne kadar sıkıştırıyor? 0 (uzak) … 1 (kapıda).
   İzolasyonistin ilkesini kıran, militaristi coşturan şey budur. */
function crisisPressure(e){
  if (!e || e.dead || e.wild) return 0;
  if (typeof crisisActive !== 'function' || !crisisActive()) return 0;
  if (G.crisisId === undefined) return 0;

  let bask = 0;
  /* Kriz filoları benim sistemlerime ne kadar yakın? */
  const mine = G.sys.filter(sy => sy.owner === e.id);
  if (!mine.length) return .5;
  for (const f of G.fleets){
    if (f.e !== G.crisisId || !f.ships.length) continue;
    let enYakin = 1e9;
    for (const sy of mine) enYakin = Math.min(enYakin, dist(f, sy));
    if (enYakin < 260) bask += .5;
    else if (enYakin < 620) bask += .22;
    else bask += .05;
  }
  /* Krizle fiilen savaşıyorsam baskı zaten yüksektir */
  if (e.war[G.crisisId]) bask += .3;
  /* Aşama ilerledikçe herkes hisseder */
  bask += ((G.crisis && G.crisis.stage) || 0) * .12;
  return clamp(bask, 0, 1);
}

function unityActive(){
  return !!(councilExists() && G.council.laws.birlesme &&
            typeof crisisActive === 'function' && crisisActive());
}

/* Yasa kabul edildiği anda uygulanır: savaşlar biter, sınırlar açılır */
function applyUnity(){
  const c = G.council;
  if (!c) return;
  let barisan = 0, acilan = 0;
  for (const idA of c.members){
    const a = G.emps[idA];
    if (!a || a.dead || a.wild) continue;
    for (const idB of c.members){
      if (idA === idB) continue;
      const b = G.emps[idB];
      if (!b || b.dead || b.wild) continue;
      /* Savaşları dondur */
      if (a.war[b.id] && typeof canPeace === 'function' && canPeace(a, b)){
        if (typeof makePeace === 'function' && makePeace(a, b,'council-unity',null)) barisan++;
      }
      /* Sınırları karşılıklı aç */
      a.passage = a.passage || {};
      if (!a.passage[b.id]){ a.passage[b.id] = true; acilan++; }
    }
  }
  say('KRİZE KARŞI BİRLEŞME yürürlükte — ' + Math.round(barisan/2) +
      ' savaş donduruldu, sınırlar açıldı', 'win');
}

/* Aylık denetim: yasa yürürlükteyken üyeler birbirine savaş açamaz;
   kriz bitince yasa düşer ve açılan sınırlar kapanır. */
function unityTick(){
  const c = G.council;
  if (!c || !c.laws.birlesme) return;

  if (typeof crisisActive === 'function' && !crisisActive()){
    delete c.laws.birlesme;
    for (const id of c.members){
      const e = G.emps[id];
      if (e) e.unityPass = null;
    }
    say('Krize Karşı Birleşme sona erdi — galaksi eski hâline döndü');
    return;
  }
  /* Yasa sürerken üye-içi savaş çıkmışsa derhal dondurulur */
  for (const idA of c.members){
    const a = G.emps[idA];
    if (!a || a.dead || a.wild) continue;
    a.unityPass = true;
    for (const idB of c.members){
      if (idA === idB) continue;
      const b = G.emps[idB];
      if (!b || b.dead || b.wild) continue;
      if (a.war[b.id] && typeof canPeace === 'function' && canPeace(a, b))
        makePeace(a, b,'council-unity',null);
      a.passage = a.passage || {};
      a.passage[b.id] = true;
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 6 — MEGAYAPI KISKANÇLIĞI
   Galaksiyi değiştirecek bir harikanın inşası diplomatik krizdir.
   ═══════════════════════════════════════════════════════════════════ */

/* Bu devletin inşa hâlindeki mega yapıları */
function megaBuilds(e){
  const out = [];
  if (!e || e.dead) return out;
  for (const sy of G.sys){
    if (!sy.work || !sy.work.length) continue;
    for (const w of sy.work){
      if (w.e !== e.id) continue;
      const S = (typeof STRUCTS !== 'undefined') ? STRUCTS[w.key] : null;
      if (S && S.mega) out.push({sys:sy, key:w.key, left:w.left, tot:w.tot, S});
    }
  }
  return out;
}
/* Tamamlanmış mega yapı sayısı — kalıcı kıskançlık kaynağı */
function megaOwned(e){
  let n = 0;
  for (const sy of G.sys){
    if (!sy.built) continue;
    for (const k in sy.built){
      if (sy.built[k] !== e.id) continue;
      const S = (typeof STRUCTS !== 'undefined') ? STRUCTS[k] : null;
      if (S && S.mega) n++;
    }
  }
  return n;
}

/* Galaksiye duyuru + kıskançlık tohumu.
   startStruct bir mega yapı başlattığında çağrılır. */
function announceMega(builder, sys, key){
  const S = (typeof STRUCTS !== 'undefined') ? STRUCTS[key] : null;
  if (!S || !S.mega) return;
  G.megaWatch = G.megaWatch || [];
  G.megaWatch.push({e:builder.id, sys:sys.id, key, at:(G.memAge || 0)});

  for (const o of G.emps){
    if (o.dead || o.wild || o.id === builder.id) continue;
    o.contact[builder.id] = true;                 // böyle bir şey gizlenemez
    builder.contact[o.id] = true;
    /* Kıskançlık: mizaca göre ilişki aşınır */
    const P = (typeof personaOf === 'function') ? personaOf(o) : null;
    let kis = 12;
    if (P){
      if (P.n === 'Militarist') kis = 22;
      else if (P.n === 'Yayılmacı') kis = 18;
      else if (P.n === 'Tüccar') kis = 10;
      else if (P.n === 'Pasifist') kis = 6;
    }
    if (o.ally[builder.id]) kis *= .4;            // müttefikine sevinir
    o.rel[builder.id] = clamp(o.rel[builder.id] - kis, -100, 100);
    if (typeof remember === 'function' && kis >= 18)
      remember(o, builder.id, 'sinirGergin');
  }
  if (builder.id === 0)
    say('GALAKSİ İNŞAATINI GÖRDÜ — ' + S.n + ' başladı, rakiplerin tedirgin', 'war');
  else
    say('⚠ ' + builder.name + ' bir HARİKA inşa ediyor: ' + S.n +
        ' — ' + sys.name, 'war');
}

/* İnşaat tamamlanınca veya iptal olunca izleme kaydı düşer */
function megaWatchTick(){
  if (!G.megaWatch || !G.megaWatch.length) return;
  G.megaWatch = G.megaWatch.filter(w => {
    const sy = G.sys[w.sys];
    if (!sy) return false;
    const sur = sy.work && sy.work.some(x => x.key === w.key && x.e === w.e);
    return !!sur;
  });
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 8 — VASALLIK VE HEGEMONYA
   Savaş artık yok etme aracı olmaktan çıkıp politik baskıya dönüşür.
   Kazanan, kaybedeni haritadan silmek yerine boyunduruk altına alır.
   ═══════════════════════════════════════════════════════════════════ */

const VASSAL_TYPES = {
  haracguzar:{n:'Haraçgüzar', ico:'💰',
    d:'Senyörüne her tur enerji, mineral ve alaşım vergisi öder. ' +
      'Bağımsız dış politikası kısıtlıdır.'},
  bekci     :{n:'Sınır Bekçisi', ico:'🛡',
    d:'Vergi ödemez; senyörünün filo kapasitesini artırır ve onun ' +
      'savaşlarına otomatik katılır.'},
  /* FAZ 71: üçüncü ihtisas — bilim vasalı */
  akademik  :{n:'Akademik Vasal', ico:'🔬',
    d:'Araştırma üretiminin bir kısmını senyörüne aktarır. Vergi ' +
      'vermez, savaşa zorlanmaz — ama teknolojisi artık ortaktır.'}
};
const VASSAL_SCI_CUT = .22;    // akademik vasalın araştırma payı

/* ═══════════════════════════════════════════════════════════════════
   FAZ 71 — VASAL SADAKATİ VE EMİRLER
   Sadakat 0–100. vassalAnger'ın (öfke) tersi olarak okunur ama
   ayrı etkenleri var: tip uyumu, senyörün gücü, süre, emir yükü.
   Senyör emir dayatabilir; sadakat yetmezse vasal reddeder ve
   bağımsızlık savaşı patlar.
   ═══════════════════════════════════════════════════════════════════ */
const EDICTS = {
  oyBirligi :{n:'Konsey Oy Birliği', ico:'🗳', c:90,
              d:'Konseyde daima senin oyunu verir.', sadakat:45},
  ekVergi   :{n:'Ek Vergi', ico:'💰', c:70,
              d:'Bir yıl boyunca vergisi yarı yarıya artar.', sadakat:60},
  savasCagri:{n:'Savaş Çağrısı', ico:'⚔', c:120,
              d:'Tüm savaşlarına katılmak zorunda kalır.', sadakat:70},
  bilimPayi :{n:'Bilim Payı', ico:'🔬', c:80,
              d:'Araştırmasının bir kısmını sana aktarır.', sadakat:50}
};

function vassalLoyalty(sub){
  if (!isVassal(sub)) return 100;
  const lord = overlordOf(sub);
  if (!lord) return 100;
  let l = 60;
  /* İlişki en güçlü etken */
  l += clamp((sub.rel[lord.id] || 0) * .35, -30, 30);
  /* Güç dengesi: zayıf vasal boyun eğer */
  const oran = totalPower(sub) / Math.max(1, totalPower(lord));
  l -= clamp((oran - .5) * 40, -15, 35);
  /* Minnet bağıyla doğduysa sadıktır */
  if (sub.founder === lord.id) l += 18;
  /* Tip: bekçi ve akademik daha az sürtüşür (vergi yok) */
  const t = vassalType(sub);
  if (t === 'bekci') l += 6;
  else if (t === 'akademik') l += 10;
  /* Yürürlükteki emirler yorar */
  const emirN = sub.edicts ? Object.keys(sub.edicts).length : 0;
  l -= emirN * 12;
  /* Uzun boyunduruk */
  const yil = ((G.memAge || 0) - (sub.vassalSince || 0)) / 12;
  l -= clamp(yil * .8, 0, 20);
  /* Reddedilen emir hafızası */
  l -= (sub._edictRed || 0) * 15;
  /* FAZ 72: dış destek cesaret verir — her destekçi sadakati düşürür */
  const destek = (sub.indepBackers || []).length;
  l -= destek * 14;
  /* FAZ 78: dışarıdan fonlanan ayrılıkçılar sadakati aşındırır */
  l -= (sub.sepFunded || 0);
  return clamp(Math.round(l), 0, 100);
}

function canEdict(lord, sub, key){
  const E = EDICTS[key];
  const contract=vassalContractOf(sub);if(contract&&!contract.legacy&&contract.source!=='forced'&&key==='savasCagri'&&contract.terms.war==='none')return {ok:false,why:'Sözleşme zorunlu savaşı kapsamıyor'};
  if (!E) return {ok:false, why:'Bilinmeyen emir'};
  if (!isVassal(sub) || sub.overlord !== lord.id)
    return {ok:false, why:'Bu devlet senin vasalın değil'};
  if (sub.edicts && sub.edicts[key])
    return {ok:false, why:'Bu emir zaten yürürlükte'};
  if ((lord.res.etk || 0) < E.c)
    return {ok:false, why:E.c + ' etki gerekir'};
  if (sub._edictCd && sub._edictCd > (G.memAge || 0))
    return {ok:false, why:'Yakında emir verdin — ' +
      (sub._edictCd - (G.memAge || 0)) + ' ay bekle'};
  return {ok:true, sadakat: vassalLoyalty(sub), gerek: E.sadakat};
}

function issueEdict(lord, sub, key){
  const chk = canEdict(lord, sub, key);
  if (!chk.ok) return chk;
  const E = EDICTS[key];
  lord.res.etk -= E.c;
  sub._edictCd = (G.memAge || 0) + 24;

  const sadakat = vassalLoyalty(sub);
  if (sadakat >= E.sadakat){
    sub.edicts = sub.edicts || {};
    sub.edicts[key] = {since: G.memAge || 0};
    sub.rel[lord.id] = clamp((sub.rel[lord.id] || 0) - 8, -100, 100);
    if (lord.id === 0)
      say('⚖ EMİR KABUL EDİLDİ — ' + sub.name + ': ' + E.n, 'win');
    else if (sub.id === 0)
      say('⚖ ' + lord.name + ' sana emir dayattı: ' + E.n, 'war');
    return {ok:true, kabul:true, sadakat};
  }

  /* ═══ RET → BAĞIMSIZLIK SAVAŞI ═══ */
  sub._edictRed = (sub._edictRed || 0) + 1;
  sub.rel[lord.id] = clamp((sub.rel[lord.id] || 0) - 35, -100, 100);
  const eskiLord = sub.overlord;
  sub.overlord = null;
  delete sub.vassalType;
  sub.edicts = {};
  sub.warCause = sub.warCause || {};
  sub.warCause[eskiLord] = 'Bağımsızlık Savaşı';
  /* ═══ FAZ 71 DÜZELTMESİ ═══
     declareWar() civic engellerine takılabiliyor (Gölge Konseyi,
     Evrensel Barış vb.) ve sessizce false dönüyordu — isyan
     savaşsız kalıyordu. Bağımsızlık savaşı bir DİPLOMATİK KARAR
     değil, fiilî bir kopuştur: doğrudan kuruluyor. */
  sub.war[lord.id] = true;
  lord.war[sub.id] = true;
  sub.warSince = sub.warSince || {}; sub.warSince[lord.id] = G.day;
  lord.warSince = lord.warSince || {}; lord.warSince[sub.id] = G.day;
  warStartNotice(sub,lord,{kind:'independence'});
  if (typeof recalcMods === 'function'){ recalcMods(sub); recalcMods(lord); }
  if (typeof remember === 'function') remember(sub, lord.id, 'ihanet');
  /* FAZ 72: destek sözü verenler savaşa katılır */
  if (typeof joinIndepWar === 'function'){
    const kac = joinIndepWar(sub, lord);
    if (kac && lord.id === 0)
      say('⚔ ' + kac + ' devlet isyancının yanında savaşa girdi', 'war');
  }
  if (lord.id === 0 && typeof UI !== 'undefined')
    UI.eventArt('infaz', 'VASAL AYAKLANDI',
      sub.name + ' emrini reddetti ve boyunduruğu kırdı. Sadakati ' +
      sadakat + ' idi, bu emir ' + E.sadakat + ' istiyordu. ' +
      'Artık bağımsızlık savaşı veriyorlar.', 'war', 'kritik', sub);
  else if (sub.id === 0 && typeof UI !== 'undefined')
    UI.eventArt('infaz', 'BOYUNDURUĞU KIRDIK',
      lord.name + ' dayatmasını reddettik. Bağımsızlık savaşı başladı.',
      'win', 'kritik', lord);
  return {ok:true, kabul:false, sadakat, isyan:true};
}

/* Aylık: emirlerin etkisi + süresi dolanlar */
function edictTick(){
  for (const sub of G.emps){
    if (sub.dead || sub.wild || sub.crisisSide) continue;
    if (!sub.edicts || !isVassal(sub)) continue;
    const lord = overlordOf(sub);
    if (!lord || lord.dead){ sub.edicts = {}; continue; }
    for (const k in sub.edicts){
      if (k === 'ekVergi'){
        const e2 = sub.edicts[k];
        if ((G.memAge || 0) - e2.since > 12){ delete sub.edicts[k]; continue; }
      }
      if (k === 'bilimPayi'){
        const month=Math.floor(G.day/30);if(sub.vassalEdictPaidMonth===month)continue;
        const pay = Math.min(Math.max(0,sub.inc?.ara||0)*.18,Math.max(0,sub.res.ara||0));
        sub.vassalEdictPaidMonth=month;
        if (pay > 0){ sub.res.ara = Math.max(0, (sub.res.ara||0) - pay);
                      lord.res.ara = (lord.res.ara||0) + pay; }
      }
    }
  }
}

/* Temel ilişki sorguları */
function isVassal(e){ return !!(e && e.overlord !== undefined && e.overlord !== null && G.emps[e.overlord] && !G.emps[e.overlord].dead); }
function overlordOf(e){ return isVassal(e) ? G.emps[e.overlord] : null; }
function vassalsOf(e){
  if (!e) return [];
  return G.emps.filter(o => !o.dead && !o.wild && o.overlord === e.id);
}
function vassalType(e){ return isVassal(e) ? (e.vassalType || 'haracguzar') : null; }

/* 96H.5.2: capitulation ends only the federation's proven common front.
   An independent declaration has its own campaign and must survive. */
function subjugationFedPeace(lord,sub){
 const f=findFed(lord),front=warLedgerFind(lord.id,sub.id);
 if(!f||!front||front.legacy||front.ended!==null)return;
 const role=front.roles[front.sides.indexOf(lord.id)];
 const peers=G.warLedger.fronts.filter(x=>x.ended===null&&!x.legacy&&x.campaign===front.campaign&&x.sides.includes(sub.id)&&x.roles[x.sides.indexOf(sub.id)]!==role)
  .map(x=>x.sides.find(id=>id!==sub.id)).filter(id=>id!==lord.id&&f.members.includes(id));
 for(const id of peers){const peer=G.emps[id];if(!peer||peer.dead)continue;
  peer.war[sub.id]=false;sub.war[id]=false;
  peer.peaceAt=peer.peaceAt||{};sub.peaceAt=sub.peaceAt||{};peer.peaceAt[sub.id]=sub.peaceAt[id]=G.day;
  for(const [a,b]of [[peer,sub],[sub,peer]])for(const key of ['warDefense','warCause','proxyWar'])if(a[key])delete a[key][b.id];
  resolveProxyWars(peer,sub);
 }
 warLedgerSync('subjugation-federation');
}

/* Boyun eğdirme: savaş hedefi tamamlandığında uygulanır */
function subjugate(lord, sub, tur, custom=null, source='forced'){
  const terms=vassalTerms(VASSAL_TYPES[tur]?tur:"haracguzar",custom||vassalDefaultTerms(VASSAL_TYPES[tur]?tur:"haracguzar",true));if(!terms)return false;
  if (!lord || !sub || lord.id === sub.id) return false;
  if (sub.dead || sub.wild || lord.dead || lord.wild) return false;
  /* Yeni kazanılmış bağımsızlık 5 yıl korunur */
  if (sub.freeUntil && sub.freeUntil > (G.memAge || 0)) return false;
  if (isVassal(lord) && lord.overlord === sub.id) return false;   // döngü olmasın
  /* Zincirleme vasallık yok: yeni senyör, eski vasalları devralır */
  for (const v of vassalsOf(sub)){if(v.vassalContract?.status==='active')v.vassalContract.lord=lord.id;v.overlord=lord.id;clearBilateralEmbargo(lord,v);lord.war[v.id]=false;v.war[lord.id]=false;}

  recordNews({category:'politics',empires:[lord.id,sub.id],title:'Vasallık kuruldu',text:sub.name+' — '+lord.name+' himayesi',important:true});
  sub.overlord = lord.id;
  /* FAZ 71: üç tip — çağıran hangisini istediyse */
  sub.vassalType = VASSAL_TYPES[tur] ? tur : 'haracguzar';
  vassalInstall(lord,sub,sub.vassalType,terms,source);
  sub.vassalSince = G.memAge || 0;
  sub.vassalAnger = 0;
  clearBilateralEmbargo(lord,sub);

  subjugationFedPeace(lord,sub);
  /* Savaş biter, ittifak benzeri bir bağ kurulur */
  if (lord.war[sub.id] || sub.war[lord.id]){
    lord.war[sub.id] = false; sub.war[lord.id] = false;
    lord.peaceAt = lord.peaceAt || {}; sub.peaceAt = sub.peaceAt || {};
    lord.peaceAt[sub.id] = G.day; sub.peaceAt[lord.id] = G.day;
    for(const [a,b]of [[lord,sub],[sub,lord]])for(const key of ['warDefense','warCause','proxyWar'])if(a[key])delete a[key][b.id];
    if (typeof resolveProxyWars === 'function') resolveProxyWars(lord, sub);
  }
  warLedgerSync('subjugation');
  /* Sınır bekçisi senyörünün savaşlarına katılır */
  if (vassalContractOf(sub)?.terms.war!=='none') vassalJoinWars(lord, sub);

  /* Hafıza: boyunduruk unutulmaz, ama ihanet kadar ağır değildir */
  if (typeof remember === 'function') remember(sub, lord.id, 'sistemAldi');
  sub.rel[lord.id] = clamp(sub.rel[lord.id] - 25, -100, 100);

  /* Galaksi bunu görür: hegemonya kurmak itibar meselesidir */
  for (const x of G.emps){
    if (x.dead || x.wild || x.id === lord.id || x.id === sub.id) continue;
    x.rel[lord.id] = clamp(x.rel[lord.id] - 8, -100, 100);
  }
  const T = VASSAL_TYPES[sub.vassalType];
  if (sub.id === 0) say('BOYUN EĞDİRİLDİN — ' + lord.name + ' senyörün oldu (' + T.n + ')', 'war');
  else if (lord.id === 0) say('VASAL KAZANDIN — ' + sub.name + ' artık ' + T.n, 'win');
  else say(lord.name + ', ' + sub.name + ' devletini ' + T.n + ' yaptı');
  return true;
}

/* Bağımsızlık: vasal bağı kopar */
function freeVassal(sub, sebep){
  if (!isVassal(sub)) return false;
  const lord = overlordOf(sub);
  recordNews({category:'politics',empires:[sub.id,lord.id],title:'Vasallık sona erdi',text:sub.name+' bağımsızlığını kazandı',important:true});
  if(sub.vassalContract){if(sub.vassalContract.status!=='expired')sub.vassalContract.status='ended';sub.vassalContract.ended=G.day;sub.vassalContract.reason=sebep||'';}
  sub.overlord = null;
  sub.vassalType = null;
  sub.vassalAnger = 0;
  sub.edicts={};sub._edictRed=0;
  if (lord){
    sub.rel[lord.id] = clamp(sub.rel[lord.id] - 10, -100, 100);
    if (sub.id === 0) say('BAĞIMSIZLIK — ' + lord.name + ' boyunduruğundan çıktın' +
      (sebep ? ' (' + sebep + ')' : ''), 'win');
    else if (lord.id === 0) say(sub.name + ' vasallıktan çıktı' + (sebep ? ' — ' + sebep : ''), 'war');
  }
  return true;
}

/* Sınır bekçisi senyörünün savaşlarına katılır */
function vassalJoinWars(lord, sub){
  for (const o of G.emps){
    if (o.dead || o.wild || o.id === sub.id || o.id === lord.id) continue;
    if (!lord.war[o.id] || sub.war[o.id]) continue;
    if(!vassalDuty(sub,'join',o)&&!((vassalContractOf(sub)?.legacy||vassalContractOf(sub)?.source==='forced')&&sub.edicts?.savasCagri))continue;
    if (typeof warAuthorize === 'function'){
      sub._lastCB = {n:'Senyörün Çağrısı'};
      warAuthorize(sub, o, sub._lastCB);
      declareWar(sub, o, {sponsor:lord.id,enemy:o.id,kind:'vassal'});
      warAuthClear();
    }
  }
}

/* ── VERGİ VE HEGEMONYA TİKİ ── */
/* FAZ 78: haraç oranı %20'ye çekildi (şartname). Mineral de
   dahil — vasal senyörüne gerçekten yük olsun. */
const VASSAL_TAX = {min:.20, ene:.20, ala:.20};   // gelirin oranı

function vassalTick(){
  vassalTalkTick();
  for (const sub of G.emps){
    if (sub.dead || sub.wild || !isVassal(sub)) continue;
    const lord = overlordOf(sub);
    if (!lord || lord.dead){ freeVassal(sub, 'senyör yok oldu'); continue; }

    /* GÜVENLİK AĞI — koruma yükümlülüğü.
       declareWar içindeki iç içe çağrı bazı yollarda (savaş sözü,
       konsey cezası, isyan) atlanabiliyor. Burada her ay denetlenir:
       vasalıma saldıran biri varsa ve ben savaşta değilsem, girerim. */
    for (const o of G.emps){
      if (o.dead || o.wild || o.id === lord.id || o.id === sub.id) continue;
      if (!sub.war[o.id]) continue;                    // vasal onunla savaşta değil
      if (lord.war[o.id]) continue;                    // senyör zaten savaşta
      if (isVassal(o) && o.overlord === lord.id) continue;  // iki vasalım arasında
      if (typeof overlordDefend === 'function') overlordDefend(o, sub);
    }

    const c=vassalContractOf(sub),month=Math.floor(G.day/30);
    if(sub.vassalPaidMonth!==month){
      const paid={};sub.vassalPaid=0;sub.vassalSci=0;
      for(const r of [...VASSAL_RESOURCES,'ara']){
        const rate=r==='ara'?c.terms.science:c.terms.tax[r]*(sub.edicts?.ekVergi?1.5:1);
        const value=Math.min(Math.max(0,sub.inc?.[r]||0)*rate,Math.max(0,sub.res[r]||0));
        if(value>0){sub.res[r]-=value;lord.res[r]=(lord.res[r]||0)+value;}
        paid[r]=value;sub.vassalPaid+=value;if(r==='ara')sub.vassalSci=value;
      }
      sub.vassalPaidMonth=month;sub.vassalTransfer={day:G.day,lord:lord.id,paid};
    }
    if(c.terms.war!=='none')vassalJoinWars(lord,sub);
    /* Savaş Çağrısı emri her tipte savaşa sokar */
    if (sub.edicts && sub.edicts.savasCagri) vassalJoinWars(lord, sub);

    /* ═══ FAZ 18: BAĞIMSIZLIK ARZUSU ═══
       Öfke artık tek bir sayı değil, dört kaynaktan besleniyor:
       güç dengesi, senyörün itibarı, vasallığın süresi ve mizaç.
       vassalLiberty() bunu tek noktadan hesaplıyor. */
    const guc = totalPower(lord) / (totalPower(sub) + 1);
    sub.vassalAnger = clamp((sub.vassalAnger || 0) + vassalLiberty(sub, lord), 0, 100);

    /* Oyuncu vasalsa eşiği geçince uyarılır — kararı kendi verir */
    if (sub.id === 0 && sub.vassalAnger >= 70 && !sub._libWarned){
      sub._libWarned = true;
      say('HALKIN BAĞIMSIZLIK İSTİYOR — DEVLET panelinden isyan edebilirsin', 'war');
    }
    if (sub.id === 0 && sub.vassalAnger < 55) sub._libWarned = false;

    /* İsyan: öfke dolduğunda ve senyör zayıfladığında */
    if (sub.vassalAnger >= 70 && sub.ai && guc < 1.35 && rnd() < .07){
      const eskiLord = lord;
      freeVassal(sub, 'isyan');
      if (typeof remember === 'function') remember(sub, eskiLord.id, 'sistemAldi');
      if (typeof warAuthorize === 'function'){
        sub._lastCB = {n:'Bağımsızlık Savaşı'};
        warAuthorize(sub, eskiLord, sub._lastCB);
        declareWar(sub, eskiLord, {kind:'independence'});
        warAuthClear();
      }
      if (eskiLord.id === 0) say('VASALIN İSYAN ETTİ — ' + sub.name, 'war');
    }
  }
}

/* Senyörün filo kapasitesine bekçi katkısı — recalcMods kullanır */
function vassalCapBonus(e){
  let n = 0;
  for (const v of vassalsOf(e))
    if (v.vassalType === 'bekci') n += 10 + sysCount(v) * 2;
  return n;
}

/* ── KONSEY HEGEMONYASI ──
   Vasal bağımsız oy kullanamaz; ağırlığı senyörüne eklenir. */
function hegemonyWeight(e){
  let w = 0;
  for (const v of vassalsOf(e)){
    if (!councilExists() || !G.council.members.includes(v.id)) continue;
    w += voteWeight(v) * (v.vassalType === 'bekci' ? .75 : .90);
  }
  return w;
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 8.5 — SENYÖRÜN KORUMA YÜKÜMLÜLÜĞÜ
   Vasallık tek yönlü bir sömürü değildir: vasal senyörünün
   savaşlarına katılıyorsa, senyör de vasalını korumak zorundadır.
   Aksi hâlde vasallık kimse için cazip olmaz.
   ═══════════════════════════════════════════════════════════════════ */
function overlordDefend(attacker, victim){
  if (!attacker || !victim) return;
  if (typeof isVassal !== 'function' || !isVassal(victim)) return;

  const lord = overlordOf(victim);
  if (!lord || lord.dead || lord.wild || !vassalDuty(victim,'protect')) return;
  if (lord.id === attacker.id) return;          // senyörün kendisi saldırıyorsa geçersiz
  if (lord.war[attacker.id]) return;            // zaten savaşta
  if (isVassal(attacker) && attacker.overlord === lord.id) return;  // iki vasalı arasında

  /* Senyör yükümlülüğü yerine getirir — bu bir tercih değil, borçtur */
  lord._lastCB = {n:'Senyörlük Yükümlülüğü'};
  if (typeof warAuthorize === 'function'){
    warAuthorize(lord, attacker, lord._lastCB);
    const oldu = declareWar(lord, attacker, {sponsor:victim.id, enemy:attacker.id, kind:'overlord'});
    warAuthClear();
    if (oldu){
      /* Korunan vasalın öfkesi diner: koruma boyunduruğu meşrulaştırır */
      victim.vassalAnger = clamp((victim.vassalAnger || 0) - 25, 0, 100);
      victim.rel[lord.id] = clamp(victim.rel[lord.id] + 10, -100, 100);
      // Declaration fulfills the political obligation; actual help is credited
      // once by diplomaticBattleEvidence / joint arrival after real support.

      if (victim.id === 0)
        say('SENYÖRÜN SENİ KORUYOR — ' + lord.name + ', ' + attacker.name + ' devletine savaş açtı', 'win');
      else if (lord.id === 0)
        say('VASALIN SALDIRIYA UĞRADI — yükümlülüğün gereği ' + attacker.name + ' ile savaştasın', 'war');
      else if (attacker.id === 0)
        say('DİKKAT: ' + victim.name + ' bir vasal — senyörü ' + lord.name + ' savaşa girdi', 'war');
    }
  }
  /* Senyörün diğer sınır bekçileri de seferber olur */
  for (const v of vassalsOf(lord)){
    if (v.id === victim.id || !vassalDuty(v,'join',attacker)) continue;
    if (v.war[attacker.id] || v.dead) continue;
    v._lastCB = {n:'Senyörün Çağrısı'};
    if (typeof warAuthorize === 'function'){
      warAuthorize(v, attacker, v._lastCB);
      declareWar(v, attacker, {sponsor:victim.id, enemy:attacker.id, kind:'vassal'});
      warAuthClear();
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 15 — GALAKTİK TEHDİT
   AI zaten Casus Belli olmadan savaş açamıyordu (aiWarReview kapısı).
   Ama OYUNCU açabiliyordu ve bedeli yoktu. Artık nedensiz savaş
   galaksinin gözünde suçtur: itibar çöker, herkes cephe alır.
   ═══════════════════════════════════════════════════════════════════ */

const THREAT_DECAY = 0.55;      // ayda erime

/* Bu savaşın meşru bir gerekçesi var mıydı? */
function warHadCause(a, b){
  /* Yükümlülük savaşları daima meşrudur */
  const yuk = a.warCause && a.warCause[b.id];
  if (yuk === 'Savunma Paktı Yükümlülüğü' || yuk === 'Senyörlük Yükümlülüğü' ||
      yuk === 'Konsey Kararını Uygula' || yuk === 'Senyörün Çağrısı' ||
      yuk === 'Bağımsızlık Savaşı') return true;
  /* Savunmaya geçen taraf suçlu sayılmaz */
  if (b.war[a.id] && !a.war[b.id]) return true;
  return !!casusBelliOf(a, b);
}

function judgeCasusBelli(a, b){
  if (!a || !b || a.wild || b.wild) return;
  if (typeof casusBelliOf !== 'function') return;
  if (warHadCause(a, b)) return;

  /* NEDENSİZ SAVAŞ — galaksi bunu affetmez */
  a.threat = (a.threat || 0) + 34;
  a.warCause = a.warCause || {};
  a.warCause[b.id] = 'Gerekçesiz Saldırı';

  for (const x of G.emps){
    if (x.dead || x.wild || x.id === a.id) continue;
    x.rel[a.id] = clamp(x.rel[a.id] - 16, -100, 100);
    if (typeof remember === 'function') remember(x, a.id, 'paktBozdu');
  }
  if (a.id === 0)
    say('GEREKÇESİZ SALDIRI — galaksi seni tehdit olarak görüyor (itibar çöktü)', 'war');
  else
    say(a.name + ' gerekçesiz savaş açtı — galaksi tedirgin', 'war');
}

/* Galaktik Tehdit puanı üretime ve diplomasiye yansır */
function threatMods(e){
  const t = (e && e.threat) || 0;
  if (t < 20) return {};
  const bite = clamp(t / 260, 0, .30);
  return {etkFlat: -bite * 6, dipMul: -bite, eneMul: -bite * .35};
}
function threatLabel(t){
  return t >= 80 ? 'GALAKTİK TEHDİT' : t >= 45 ? 'tehlikeli'
       : t >= 20 ? 'şaibeli' : null;
}

/* Aylık erime — diploTick çağırır */
function threatTick(){
  for (const e of G.emps){
    if (e.dead || e.wild || !e.threat) continue;
    /* Barışçıl davranış lekeyi yavaşça siler; savaştayken silinmez */
    let savasta = false;
    for (const w in e.war) if (e.war[w]) savasta = true;
    if (!savasta) e.threat = Math.max(0, e.threat - THREAT_DECAY);
    if (e.threat <= 0) delete e.threat;
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 16 — KRİZ DİPLOMASİSİ
   Hiçlik Sürüsü sahnedeyken galaksi eski hesaplarını askıya alır.
   Kinler SİLİNMEZ — dondurulur; kriz bitince yeniden ısınır. Bu,
   "ortak düşman" hissini verirken tarihi de yok saymaz.
   ═══════════════════════════════════════════════════════════════════ */

function crisisDiplomacyTick(){
  if (typeof crisisActive !== 'function' || !crisisActive()) {
    /* Kriz bitti: askıya alınmış lekeler geri döner (yarısı bağışlanır) */
    for (const e of G.emps){
      if (e.dead || e.wild || e.threatFrozen === undefined) continue;
      e.threat = (e.threat || 0) + e.threatFrozen * .5;
      delete e.threatFrozen;
      if (e.id === 0) say('Kriz bitti — galaksi eski hesapları hatırlamaya başladı');
    }
    return;
  }

  const bask = {};
  for (const e of G.emps){
    if (e.dead || e.wild || e.crisisSide) continue;
    bask[e.id] = (typeof crisisPressure === 'function') ? crisisPressure(e) : .5;
  }

  for (const e of G.emps){
    if (e.dead || e.wild || e.crisisSide) continue;
    const p = bask[e.id] || 0;

    /* 1. GALAKTİK TEHDİT ASKIYA ALINIR
       Kriz varken kimse birbirinin eski suçunu konuşmaz. */
    if ((e.threat || 0) > 0 && e.threatFrozen === undefined){
      e.threatFrozen = e.threat;
      e.threat = 0;
      recalcMods(e);
      if (e.id === 0) say('Kriz karşısında geçmiş suçların askıya alındı', 'win');
    }

    /* 2. KİNLER YUMUŞAR — kriz baskısıyla orantılı */
    if (e.mem){
      for (const id in e.mem){
        const o = G.emps[id];
        if (!o || o.crisisSide) continue;          // krize duyulan kin sönmez
        for (const m of e.mem[id]) if (m.v < 0) m.v *= (1 - .035 * (0.4 + p));
      }
    }

    /* 3. İNSANLAR BİRBİRİNE YAKLAŞIR */
    for (const o of G.emps){
      if (o.dead || o.wild || o.crisisSide || o.id === e.id) continue;
      if (!e.contact[o.id]) continue;
      e.rel[o.id] = clamp(e.rel[o.id] + .55 * (0.5 + p), -100, 100);

      /* 4. AMBARGOLAR GEVŞER — kriz varken ekonomik savaş lüks */
      if (typeof embargoOn === 'function' && embargoOn(e, o.id) && e.embargo &&
          e.embargo[o.id] && rnd() < .10 + p * .18 && e.ai===true){
        if (typeof setEmbargo === 'function') setEmbargo(e, o, false);
        if (o.id === 0 || e.id === 0)
          say((e.id===0?'Ambargonu kaldırdın':e.name + ' ambargoyu kaldırdı') +
              ' — kriz herkesi masaya çağırıyor');
      }

      /* 5. SINIRLAR AÇILIR — kriz filoları serbestçe geçebilsin */
      if (p > .25 && !e.ally[o.id]){
        e.passage = e.passage || {};
        if (!e.passage[o.id] && rnd() < .12){
          e.passage[o.id] = true;
          if (o.id === 0) say(e.name + ' kriz için sınırlarını sana açtı', 'win');
        }
      }
    }

    /* 6. SAVAŞLARI BIRAKMA EĞİLİMİ — kriz kapıdaysa iç savaş anlamsız */
    if (!e.ai || p < .30) continue;
    for (const o of G.emps){
      if (o.dead || o.wild || o.crisisSide || !e.war[o.id]) continue;
      if (rnd() > .10 + p * .22) continue;
      if (typeof canPeace === 'function' && canPeace(e, o)){
        if (makePeace(e, o,'crisis',e.id) && (e.id === 0 || o.id === 0))
          say('Kriz yüzünden barış — ortak düşman kapıda', 'win');
      } else {
        /* Kilit varsa bile kriz baskısı savaşı durdurur */
        e.war[o.id] = false; o.war[e.id] = false;
        e.peaceAt = e.peaceAt || {}; o.peaceAt = o.peaceAt || {};
        e.peaceAt[o.id] = G.day; o.peaceAt[e.id] = G.day;
        warLedgerSync('crisis',e.id);
        if (e.id === 0 || o.id === 0)
          say('Ateşkes — galaksi ortak düşmana döndü', 'win');
      }
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 18 — VASAL SADAKATİ
   Bağımsızlık arzusunun aylık artış hızı. Dört kaynak:
     1. GÜÇ DENGESİ — vasal efendisine yaklaştıkça cesaretlenir
     2. SENYÖRÜN İTİBARI — onursuz/tehditkâr efendiye boyun eğilmez
     3. SÜRE — uzun boyunduruk yorar (ama koruma bunu dengeler)
     4. MİZAÇ — militarist ve izolasyonist daha çabuk küser
   ═══════════════════════════════════════════════════════════════════ */
function vassalLiberty(sub, lord){
  if (!sub || !lord) return 0;
  const guc = totalPower(lord) / (totalPower(sub) + 1);

  /* 1. GÜÇ DENGESİ — asıl belirleyici */
  let d = 1.0;
  if (guc > 3)      d -= .85;      // ezici efendi: boyun eğilir
  else if (guc > 2) d -= .60;
  else if (guc > 1.4) d -= .25;
  else if (guc < 1)   d += .80;    // vasal daha güçlü: isyan yakın
  else if (guc < 1.15) d += .40;

  /* 2. SENYÖRÜN İTİBARI — Faz 15/16'daki onur ve tehdit */
  if (typeof honorOf === 'function'){
    const h = honorOf(lord);
    if (h <= -40) d += .55;        // hain bir efendiye kimse sadık kalmaz
    else if (h <= -15) d += .25;
    else if (h >= 35) d -= .30;    // saygın efendi boyunduruğu meşrulaştırır
  }
  const th = lord.threat || 0;
  if (th >= 70) d += .60;          // parya adayı efendinin yanında olmak tehlikeli
  else if (th >= 30) d += .25;
  if (typeof isPariah === 'function' && isPariah(lord)) d += .70;

  /* ═══ FAZ 46: KUKLA GÜÇLENMESİ VE HAMİ ZAYIFLIĞI ═══
     Kışkırtmayla doğan kuklalar minnet duyar ama güçlendikçe
     bağımsızlık ister. Filo gücü haminin %70'ini aşarsa istek
     hızla tırmanır; hami savaşta yıpranmışsa fırsat doğar. */
  const oranTers = totalPower(sub) / Math.max(1, totalPower(lord));
  if (oranTers >= .70) d += clamp((oranTers - .70) * 1.6, 0, .70);
  /* Hami savaş yorgunu mu? */
  let lordSavas = 0;
  for (const w in lord.war)
    if (lord.war[w] && G.emps[w] && !G.emps[w].wild) lordSavas++;
  if (lordSavas >= 2) d += .35;
  else if (lordSavas === 1) d += .15;
  if ((lord.warExh || 0) > 50) d += .30;
  /* Minnet bağı frenler — ama sonsuza dek değil */
  if (sub.founder === lord.id){
    const yas = ((G.memAge || 0) - (sub._bornAt || 0)) / 12;
    d -= clamp(.55 - yas * .05, 0, .55);
  }

  /* 3. SÜRE — uzun boyunduruk yıpratır */
  const yil = ((G.memAge || 0) - (sub.vassalSince || 0)) / 12;
  d += clamp(yil * .045, 0, .55);

  /* 4. MİZAÇ */
  if (typeof personaOf === 'function'){
    const P = personaOf(sub);
    if (P.n === 'Militarist') d += .50;
    else if (P.n === 'İzolasyonist') d += .40;
    else if (P.n === 'Tüccar') d -= .20;
    else if (P.n === 'Pasifist') d -= .15;
  }

  /* Sınır bekçisi vergi vermediği için daha az küser */
  if (vassalType(sub) === 'bekci') d *= .70;
  /* Senyörle aynı federasyondaysa boyunduruk ortaklığa dönüşür */
  if (typeof findFed === 'function'){
    const fs = findFed(sub), fl = findFed(lord);
    if (fs && fl && fs === fl) d *= .55;
  }
  /* Ortak düşman varken iç hesap kapanır */
  if (typeof crisisActive === 'function' && crisisActive()) d *= .35;

  return clamp(d * .85, -1.2, 3.0);
}

/* Arayüz için: sadakat durumu ve kalan süre tahmini */
function vassalLoyaltyInfo(sub){
  if (!isVassal(sub)) return null;
  const lord = overlordOf(sub);
  const hiz = vassalLiberty(sub, lord);
  const arzu = sub.vassalAnger || 0;
  const kalan = hiz > .02 ? Math.ceil((70 - arzu) / hiz) : null;
  return {
    arzu, hiz,
    kalanAy: (arzu >= 70) ? 0 : kalan,
    durum: arzu >= 70 ? 'İSYAN EŞİĞİNDE' : arzu >= 45 ? 'huzursuz'
         : arzu >= 20 ? 'gergin' : 'sadık',
    yon: hiz > .5 ? 'hızla artıyor' : hiz > .05 ? 'artıyor'
       : hiz < -.05 ? 'azalıyor' : 'durgun'
  };
}

/* Oyuncunun kendi isyanı — DEVLET panelinden tetiklenir */
function playerRevolt(){
  const e = G.p;
  if (!isVassal(e)) return {ok:false, why:'Vasal değilsin'};
  if ((e.vassalAnger || 0) < 55)
    return {ok:false, why:'Halkın henüz hazır değil (bağımsızlık arzusu 55 gerekir)'};
  const lord = overlordOf(e);
  freeVassal(e, 'isyan');
  if (typeof remember === 'function') remember(e, lord.id, 'sistemAldi');
  e._lastCB = {n:'Bağımsızlık Savaşı'};
  if (typeof warAuthorize === 'function'){
    warAuthorize(e, lord, e._lastCB);
    declareWar(e, lord, {kind:'independence'});
    warAuthClear();
  }
  /* Bağımsızlık savaşı meşrudur: Galaktik Tehdit cezası YOK */
  if (e.threat) e.threat = Math.max(0, e.threat - 34);
  say('BAĞIMSIZLIK SAVAŞI İLAN EDİLDİ — ' + lord.name, 'war');
  return {ok:true};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 27 — KALKAN SABOTAJI
   Uzun kuşatmaları kırmanın istihbarat yolu. Kuşatma altındaki bir
   gezegende, saldıranın istihbarat gücü yeterse ajanlar kalkan
   jeneratörünü çökertir. Başarısızlık ağır: ajan infaz edilir,
   kurban haklı savaş nedeni kazanır.
   Mevcut intelOf / counterIntel / remember altyapısını kullanır.
   ═══════════════════════════════════════════════════════════════════ */

const SABOTAGE_COOLDOWN = 24;      // ay — aynı gezegene tekrar denenmez

/* FAZ 72: Casusluk Şeffaflığı yasası yürürlükte mi? */
function spyTransparency(){
  return !!(typeof councilExists === 'function' && councilExists() &&
            G.council.laws && G.council.laws.casusSeffaf);
}
/* FAZ 72: Piyasa Regülasyonu komisyonu düşürür (%8 → %3) */
function marketFeeNow(){
  if (typeof councilExists === 'function' && councilExists() &&
      G.council.laws && G.council.laws.piyasaReg) return .03;
  return (typeof MARKET_FEE !== 'undefined') ? MARKET_FEE : .08;
}

function sabotageChance(e, target){
  if (!e || !target) return {basari:0, ifsa:0};
  const lvl = (typeof intelOf === 'function') ? intelOf(e, target.id) : 0;
  const prof = (typeof aiProfile === 'function') ? aiProfile(e) : {dip:.5, sci:.5};
  let basari = .10 + lvl * .16 + prof.dip * .12 + prof.sci * .08;
  if (typeof hasCivic === 'function'){
    if (hasCivic(e, 'shadow')) basari += .22;
    if (hasCivic(e, 'counter')) basari += .05;
  }
  /* FAZ 48: SAHTEKÂR ekseni — gölgede ustalık */
  if (e.mods){
    basari += (e.mods.opBonus || 0);
  }
  /* Hedefin karşı istihbaratı sabotajı zorlaştırır */
  const ci = (typeof counterIntel === 'function') ? counterIntel(target) : 0;
  basari -= ci * .18;
  /* FAZ 38: İsyancı İttifakı üyeleri zalime karşı daha etkili —
     gizli ağ, ortak istihbarat, içeriden yardım. */
  if (typeof rebelOpBonus === 'function') basari += rebelOpBonus(e, target);
  let ifsa = .30 - lvl * .05 + ci * .20;
  /* FAZ 48: SAHTEKÂR ekseni ajanı gizler, DÜRÜST açığa çıkarır */
  if (e.mods) ifsa += (e.mods.opRisk || 0);
  if (typeof hasCivic === 'function' && hasCivic(e, 'shadow')) ifsa *= .55;
  /* FAZ 72: Casusluk Şeffaflığı tüm galaksiyi vurur */
  if (typeof spyTransparency === 'function' && spyTransparency())
    basari = clamp(basari - .18, .03, 1);
  return {basari: clamp(basari, .04, .72), ifsa: clamp(ifsa, .05, .60)};
}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 30 — TEKNOLOJİ HIRSIZLIĞI
   Hedefin bildiği ama bizim bilmediğimiz bir teknolojinin
   maliyetinin %50'si araştırma puanı olarak eklenir. Kilit
   doğrudan açılmaz — yarı yolu kısaltır.
   ═══════════════════════════════════════════════════════════════════ */
/* 87C: Çözülmüş özel denemenin kaydı UI/AI çağıranında değil motorda.
   ok ödenmiş deneme, basarili gerçek etki demektir. Sessiz başarısızlık
   kurbana yeni bilgi vermez. Kayıt işlemi RNG tüketmez. */
function finishSpecialOp(e, target, key, result, cost, location){
  const r = Object.assign({}, result, {cost});
  r.basarili = result.basarili === true;
  r.outcome = r.basarili ? 'basari' : (r.caught ? 'ifsa' : 'sonucsuz');
  e.opLog = e.opLog || [];
  e.opLog.push({t:G.memAge || 0, k:key, o:target.id,
    caught:!!r.caught, outcome:r.outcome, cost,
    actorSummary:String(r.msg || '').slice(0,320)});
  if (e.opLog.length > 20) e.opLog.splice(0, e.opLog.length - 20);
  if (r.basarili || r.caught){
    target.hitLog = target.hitLog || [];
    target.hitLog.push(Object.assign({t:G.memAge || 0,
      k:key === 'incite' ? 'kiskirt' : key, by:e.id,
      caught:!!r.caught, known:!!r.caught, outcome:r.outcome}, location));
    if (target.hitLog.length > 30) target.hitLog.splice(0, target.hitLog.length - 30);
  }
  return r;
}

/* 91A: yalnız sunum sınırı. Bedel/etki/geçmiş önce tamamlanır; log yazma
   hataları gizlenmez. Mevcut işlem tamponu varsa sahipliği değiştirilmez.
   Operasyonun kendisi transaction değildir ve yeniden denenmez. */
function specialOpPresent(stage, fn){
  try { fn(); } catch(err){ sideBufferError(stage, err, 'op-presentation'); }
}
function specialOpNotify(msg, cls, art){
  const buf = [{tur:'say', msg, cls, scope:'op-presentation'}];
  if (art) buf.push({tur:'ui', scope:'op-presentation', args:[], fn:()=>{
    if (typeof UI !== 'undefined' && typeof UI.eventArt === 'function') UI.eventArt(...art);
  }});
  if (G._sideBuf){ G._sideBuf.push(...buf); return; }
  commitSideBuffer(buf);
  flushSideBuffer(buf);
}

function stealTech(e, target){
  const gate = spyTargetCheck(e, target);
  if (!gate.ok) return gate;
  if (typeof intelOf !== 'function') return {ok:false, why:'—'};
  const lvl = intelOf(e, target.id);
  if (lvl < 2) return {ok:false, why:'En az 2. seviye istihbarat gerekir'};
  if ((e.res.etk || 0) < 90) return {ok:false, why:'90 etki gerekir'};

  /* Onda olan, bizde olmayan teknolojiler */
  const adaylar = [];
  for (const id in (target.techs || {})){
    if (e.techs && e.techs[id]) continue;
    if (!TECHS[id]) continue;
    adaylar.push(id);
  }
  if (!adaylar.length) return {ok:false, why:'Çalınacak yeni teknolojisi yok'};

  e.res.etk -= 90;
  const c = sabotageChance(e, target);
  /* Teknoloji çalmak sabotajdan daha zor, daha riskli */
  const basari = clamp(c.basari * .85, .04, .65);
  const ifsa   = clamp(c.ifsa * 1.25, .06, .70);

  if (rnd() < basari){
    /* En pahalı olanı çal — istihbarat seçici davranır */
    adaylar.sort((a, b) => (TECHS[b].c || 0) - (TECHS[a].c || 0));
    const id = adaylar[Math.floor(rnd() * Math.min(3, adaylar.length))];
    const kazanc = Math.round((TECHS[id].c || 0) * .5);
    e.res.ara = (e.res.ara || 0) + kazanc;
    if (typeof recordSabotage === 'function') recordSabotage('tech');
    const msg = TECHS[id].n + ' araştırma verileri çalındı — +' + kazanc + ' araştırma';
    const result = finishSpecialOp(e, target, 'stealTech',
      {ok:true, caught:false, basarili:true, msg, tech:id, kazanc}, 90);
    if (e.id === 0){
      specialOpNotify('📡 ' + msg, 'sci', ['veri', 'VERİ ELE GEÇİRİLDİ',
          target.name + ' arşivlerinden <b>' + TECHS[id].n + '</b> araştırma ' +
          'verileri kopyalandı. Laboratuvarlarımız yolun yarısını atladı: ' +
          '<b style="color:#6ff2c8">+' + kazanc + ' araştırma</b>.', 'sci']);
    }
    else if (target.id === 0)
      specialOpNotify('VERİ SIZINTISI — Arşivlerimizden ' + TECHS[id].n + ' araştırma verileri çalındı. Fail bilinmiyor.', 'war');
    return result;
  }

  if (rnd() < ifsa){
    if (typeof recordSabotage === 'function') recordSabotage('ifsa');
    if (typeof remember === 'function') remember(target, e.id, 'sabotaj');
    target.rel[e.id] = clamp(target.rel[e.id] - 45, -100, 100);
    target._lastCB = {n:'Teknoloji Hırsızlığı', w:1.30};
    for (const x of G.emps){
      if (x.dead || x.wild || x.id === e.id || x.id === target.id) continue;
      x.rel[e.id] = clamp(x.rel[e.id] - 6, -100, 100);
    }
    const msg = 'Ajan infaz edildi — ' + target.name + ' hırsızlığı ifşa etti';
    const result = finishSpecialOp(e, target, 'stealTech',
      {ok:true, caught:true, msg}, 90);
    if (e.id === 0){
      specialOpNotify('☠ ' + msg, 'war', ['infaz', 'AJANIMIZ İNFAZ EDİLDİ',
          target.name + ' arşivlerine sızma girişimimizi yakaladı. Ajanımız ' +
          'idam edildi ve elimizdeki kanıtlar onlara geçti.', 'war']);
    }
    else if (target.id === 0)
      specialOpNotify('☠ TEKNOLOJİ HIRSIZI YAKALANDI — ' + e.name + ' arşivlerimize sızmaya çalıştı', 'win');
    return result;
  }

  if (typeof recordSabotage === 'function') recordSabotage('sessiz');
  return finishSpecialOp(e, target, 'stealTech',
    {ok:true, caught:false, msg:'Sızma sonuçsuz kaldı — veri bulunamadı'}, 90);
}

/* Aylık deneme — invasionTick sırasında kuşatma varsa çağrılır */
function trySabotage(e, sys, pl){
  const col = pl && pl.col;
  if (!col || !e) return false;
  if ((col.shield || 0) <= 5) return false;                 // zaten inik
  const sahip = G.emps[pl.owner];
  if (!sahip || sahip.dead) return false;
  if (col.sabCd && col.sabCd > (G.memAge || 0)) return false;

  /* İstihbarat eşiği: en az temas düzeyi gerekir */
  const lvl = (typeof intelOf === 'function') ? intelOf(e, sahip.id) : 0;
  if (lvl < 1) return false;
  if ((e.res.etk || 0) < 30) return false;

  /* Denenme sıklığı — her ay değil */
  if (rnd() > .16 + lvl * .05) return false;

  col.sabCd = (G.memAge || 0) + SABOTAGE_COOLDOWN;
  e.res.etk = Math.max(0, (e.res.etk || 0) - 30);
  const c = sabotageChance(e, sahip);

  if (rnd() < c.basari){
    /* ── BAŞARI: kalkan çöker ── */
    col.shield = 0;
    col.sabotaged = (G.memAge || 0);
    if (typeof recordSabotage === 'function') recordSabotage('basari');
    if (e.id === 0)
      say('🔇 Kalkan jeneratörü sabote edildi — ' + (col.name || pl.name) +
          ' savunmasız', 'sci');
    else if (pl.owner === 0)
      say('KALKANIMIZ ÇÖKTÜ — ' + (col.name || pl.name) + ' sabotaja uğradı', 'war');
    return true;
  }

  if (rnd() < c.ifsa){
    /* ═══ FAZ 28: ÇİFT TARAFLI AJAN ═══
       İfşaların %18'inde ajan infaz edilmez, DÖNDÜRÜLÜR. Saldırgana
       "sabotaj başarılı" yalanı gider; oysa kalkan ayaktadır ve
       yörüngeye giren filolar pusuya düşer (+%25 hasar alır).
       En sinsi sonuç: oyuncu kazandığını sanarak tuzağa yürür. */
    if (rnd() < .18){
      col.ambush = (G.memAge || 0) + 12;      // 1 yıl pusu penceresi
      col.ambushBy = sahip.id;
      if (typeof recordSabotage === 'function') recordSabotage('cift');
      /* Savunan taraf gerçeği bilir */
      if (pl.owner === 0)
        say('🎭 AJANI DÖNDÜRDÜK — ' + e.name + ' sabotajın başarılı olduğunu sanıyor. ' +
            'Yörüngemize girerlerse pusuya düşecekler.', 'win');
      /* Saldırgana SAHTE başarı bildirimi */
      if (e.id === 0)
        say('🔇 Kalkan jeneratörü sabote edildi — ' + (col.name || pl.name) +
            ' savunmasız', 'sci');
      return true;                             // "başarılı" görünür
    }

    /* ── KRİTİK HATA: ajan yakalandı ── */
    if (typeof recordSabotage === 'function') recordSabotage('ifsa');
    if (typeof remember === 'function') remember(sahip, e.id, 'sabotaj');
    sahip.rel[e.id] = clamp(sahip.rel[e.id] - 40, -100, 100);
    e.res.etk = Math.max(0, (e.res.etk || 0) - 40);
    /* Kurban haklı savaş nedeni kazanır */
    sahip._lastCB = {n:'Sabotaj İfşası', w:1.25};
    /* Galaksi de duyar — sabotaj kirli iştir */
    for (const x of G.emps){
      if (x.dead || x.wild || x.id === e.id || x.id === sahip.id) continue;
      x.rel[e.id] = clamp(x.rel[e.id] - 8, -100, 100);
    }
    if (e.id === 0){
      say('☠ AJANIMIZ İNFAZ EDİLDİ — ' + sahip.name +
          ' sabotajı ifşa etti, itibarın zedelendi', 'war');
      if (typeof UI !== 'undefined' && UI.eventArt)
        UI.eventArt('infaz', 'AJANIMIZ İNFAZ EDİLDİ',
          sahip.name + ' kalkan sabotajımızı ifşa etti. Ajanımız yakalandı ve ' +
          'idam edildi. Galaksinin gözünde itibarımız zedelendi; ' +
          'karşı taraf artık haklı bir savaş nedenine sahip.', 'war');
    }
    else if (pl.owner === 0)
      say('☠ SABOTAJCI YAKALANDI — ' + e.name +
          ' kalkanımızı çökertmeye çalıştı, elimizde kanıt var', 'win');
    return false;
  }

  /* Sessiz başarısızlık: ne kalkan düştü ne ajan yakalandı */
  if (typeof recordSabotage === 'function') recordSabotage('sessiz');
  if (e.id === 0) say('Sabotaj girişimi sonuçsuz kaldı', '');
  return false;
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 29 — GALAKTİK KUTUPLAŞMA
   ÖLÇÜM (Faz 28): 60. yılda AI'lar arasında hiç savaş kalmıyordu;
   e.war bayrağı yalnız korsanlarla doluydu. Galaksi donuyor ve
   Colossus gibi geç oyun mekanikleri hiç tetiklenmiyor.
   Çözüm: 40. yıldan sonra sınır sürtüşmesi ve ideolojik uçurum
   her ay biraz daha derinleşir. Kimse zorlanmaz — nefret
   kendiliğinden birikir ve savaş doğal olarak çıkar.
   ═══════════════════════════════════════════════════════════════════ */
const POLARIZE_YEAR = 40;        // oyun yılı (başlangıç 2210 → 2250)
const POLARIZE_FLOOR = -85;      // ilişkinin inebileceği taban

function ideologyGap(a, b){
  const ea = a.ethics || {}, eb = b.ethics || {};
  let d = Math.abs((ea.mil||0) - (eb.mil||0)) +
          Math.abs((ea.aut||0) - (eb.aut||0)) * .7 +
          Math.abs((ea.mat||0) - (eb.mat||0)) * .6;
  /* Mizaç zıtlığı da sayılır */
  if (typeof personaOf === 'function'){
    const pa = personaOf(a).n, pb = personaOf(b).n;
    if ((pa === 'Militarist' && pb === 'Pasifist') ||
        (pa === 'Pasifist' && pb === 'Militarist')) d += 3;
    else if (pa !== pb) d += 1;
  }
  return d;
}

function polarizeTick(){
  const yil = (G.year || 2210) - 2210;
  if (yil < POLARIZE_YEAR) return;
  /* Kriz varken galaksi birleşir, kutuplaşma durur */
  if (typeof crisisActive === 'function' && crisisActive()) return;

  /* ÖLÇÜM: %1-2'lik baskı diğer diplomasi mekanikleri (elçi, ticaret,
     ortak düşman, konsey) tarafından eziliyordu — 40→60. yıl arası
     ortalama ilişki 74'ten 92'ye ÇIKMIŞTI. Baskı, iyileşme hızını
     aşacak seviyeye çekildi. */
  const siddet = clamp(.10 + (yil - POLARIZE_YEAR) * .006, .10, .25);

  for (const a of G.emps){
    if (a.dead || a.wild || a.crisisSide) continue;
    for (const b of G.emps){
      if (b.dead || b.wild || b.crisisSide || b.id <= a.id) continue;
      if (!a.contact[b.id]) continue;
      /* Müttefikler ve federasyon ortakları kutuplaşmaz */
      if (a.ally && a.ally[b.id]) continue;
      if (typeof findFed === 'function'){
        const fa = findFed(a), fb = findFed(b);
        if (fa && fb && fa === fb) continue;
      }
      /* Vasal-senyör bağı da korunur */
      if (typeof isVassal === 'function' &&
          ((isVassal(a) && a.overlord === b.id) ||
           (isVassal(b) && b.overlord === a.id))) continue;

      /* 1. SINIR SÜRTÜŞMESİ — komşuluk arttıkça gerilim */
      let komsu = 0;
      for (const sy of G.sys){
        if (sy.owner !== a.id) continue;
        for (const l of sy.lanes)
          if (G.sys[l] && G.sys[l].owner === b.id){ komsu++; break; }
      }
      /* 2. İDEOLOJİK UÇURUM */
      const gap = ideologyGap(a, b);

      /* Taban baskı: komşu olmasa bile ideolojik uçurum yeter */
      const baski = (1.2 + komsu * 1.6 + gap * 1.1) * siddet;
      if (baski <= 0) continue;
      a.rel[b.id] = clamp((a.rel[b.id] || 0) - baski, POLARIZE_FLOOR, 100);
      b.rel[a.id] = clamp((b.rel[a.id] || 0) - baski, POLARIZE_FLOOR, 100);
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 30 — HEGEMONYA GERİLİMİ (GÜÇ KORKUSU)
   ÖLÇÜM (izole, 40. yıl sonrası, AI çifti başına 12 tur):
     envoyTick (elçi) ... +11.71   ← baskın
     polarizeTick ....... −3.36
     borderFriction ..... −2.70
   Elçi mekaniği tek başına iki kötüleştiriciyi ezip geçiyordu.
   Suni ilişki tavanı koymak yerine ORGANİK bir korku ekliyoruz:
   yalnızca DEV olan korkutur. Küçük ve pasifist devletler
   bundan hiç etkilenmez — barışçıl oynayış cezalandırılmaz.
   ═══════════════════════════════════════════════════════════════════ */
const HEGEMON_RATIO = 1.6;       // galaktik ortalamanın kaç katı "dev"

/* Bir imparatorluğun galaktik ölçekteki ağırlığı: askerî güç,
   toprak ve nüfusun bileşimi. */
function hegemonWeight(e){
  if (!e || e.dead || e.wild) return 0;
  const filo = (typeof totalPower === 'function') ? totalPower(e) : 0;
  const sistem = (typeof sysCount === 'function') ? sysCount(e) : 0;
  let pop = 0;
  for (const c of (e.colonies || [])){
    const sy = G.sys[c.s];
    const pl = sy && sy.planets[c.p];
    if (pl && pl.col) pop += pl.col.pop;
  }
  return filo * .55 + sistem * 42 + pop * 7;
}

function hegemonyTick(){
  const canli = G.emps.filter(e => !e.dead && !e.wild && !e.crisisSide);
  if (canli.length < 3) return;

  /* Galaktik ortalama */
  let toplam = 0;
  const agirlik = {};
  for (const e of canli){ agirlik[e.id] = hegemonWeight(e); toplam += agirlik[e.id]; }
  const ort = toplam / canli.length;
  if (ort <= 0) return;

  for (const dev of canli){
    const oran = agirlik[dev.id] / ort;
    if (oran < HEGEMON_RATIO) { delete dev.hegemonFear; continue; }

    /* Ne kadar devsen o kadar korkutucusun. 1.6× → .35, 3× → 1.4 */
    const korku = clamp((oran - HEGEMON_RATIO) * .75, 0, 1.6);
    dev.hegemonFear = korku;

    for (const o of canli){
      if (o.id === dev.id) continue;
      if (!o.contact[dev.id]) continue;
      /* Müttefikler ve federasyon ortakları korkmaz */
      if (o.ally && o.ally[dev.id]) continue;
      if (typeof findFed === 'function'){
        const fa = findFed(o), fb = findFed(dev);
        if (fa && fb && fa === fb) continue;
      }
      /* Vasalı zaten boyun eğmiş */
      if (typeof isVassal === 'function' && isVassal(o) && o.overlord === dev.id) continue;

      /* KÜÇÜK VE PASİFİST DEVLETLER ETKİLENMEZ:
         korku, korkanın kendi büyüklüğüyle ölçeklenir. Cüce bir
         devlet devle boy ölçüşmeyi düşünmez; onun korkusu
         diplomatik değil, varoluşsaldır ve savaşa dönüşmez. */
      const benimOran = agirlik[o.id] / ort;
      let carpan = clamp(benimOran, .25, 1.4);
      if (typeof personaOf === 'function'){
        const P = personaOf(o);
        if (P.n === 'Pasifist') carpan *= .35;        // pasifist korkmaz, kaçınır
        else if (P.n === 'Militarist') carpan *= 1.35;
        else if (P.n === 'İzolasyonist') carpan *= 1.15;
      }
      const dusus = korku * carpan;
      if (dusus <= 0) continue;
      o.rel[dev.id] = clamp((o.rel[dev.id] || 0) - dusus, -100, 100);
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 32 — SENATO GÜNDEM KUYRUĞU
   Rastgele sponsor kaldırıldı. Her üye kendi ideolojisine ve
   ihtiyacına uyan bir yasayı kuyruğa önerir; oylama vakti geldiğinde
   arkasında EN ÇOK DİPLOMATİK AĞIRLIK duran teklif masaya gelir.
   Kuyruk aylık tikte tek geçişle taranır — derin döngü yok.
   ═══════════════════════════════════════════════════════════════════ */

/* Bir üyenin bir yasaya duyduğu ihtiyaç (0–2 arası). Oylama
   sırasındaki `want` ile aynı ruhu taşır ama teklif AŞAMASINDA
   kullanılır: "bunu ben gündeme getirmek ister miyim?" */
function agendaDesire(e, key){
  const R = RESOLUTIONS[key];
  if (!R) return 0;
  const p = aiProfile(e);
  const P = (typeof personaOf === 'function') ? personaOf(e) : null;
  const mz = P ? P.n : '';
  let d = .25;
  const lean = R.lean || {};
  for (const k in lean) d += (p[k] || 0) * lean[k] * .7;

  /* ── SOMUT İHTİYAÇ: yasa benim eksiğimi kapatıyor mu? ── */
  const inc = e.inc || {};
  if (key === 'arastirma'  && (inc.ara || 0) < 60)  d += .55;
  if (key === 'madenTekel' && (inc.min || 0) < 40)  d += .55;
  if (key === 'ticaretStd' || key === 'serbest'){
    if (e.trade && e.trade.mul > 1.2) d += .40;      // ticareti güçlü olan ister
  }
  if (key === 'gocSerbest'){
    let dolu = 0;
    for (const c of e.colonies){
      const pl = G.sys[c.s] && G.sys[c.s].planets[c.p];
      if (pl && pl.col && pl.col.pop < pl.col.cap * .7) dolu++;
    }
    if (dolu >= 2) d += .45;                          // büyüyecek yerim var
  }
  if (key === 'sinirGuv'){
    let tehdit = 0;
    for (const o of G.emps) if (!o.dead && !o.wild && e.war[o.id]) tehdit++;
    d += Math.min(.8, tehdit * .35);
  }
  if (key === 'silahsiz'){
    /* Zayıf olan silahsızlanmayı ister, güçlü olan istemez */
    const ort = (typeof hegemonWeight === 'function') ? hegemonWeight(e) : totalPower(e);
    let toplam = 0, n = 0;
    for (const o of G.emps){
      if (o.dead || o.wild) continue;
      toplam += (typeof hegemonWeight === 'function') ? hegemonWeight(o) : totalPower(o);
      n++;
    }
    const oran = n ? ort / (toplam / n) : 1;
    d += clamp((1 - oran) * .9, -.7, .7);
  }
  if (key === 'casusInfaz'){
    /* Casusluğa uğrayan bunu ister */
    const magdur = (e.hitLog || []).length;
    d += Math.min(.7, magdur * .12);
    if (typeof hasCivic === 'function' && hasCivic(e, 'shadow')) d -= .8;  // casus devlet istemez
  }
  if (key === 'colYasak'){
    /* HAYATTA KALMA REFLEKSİ: Colossus'u olan ya da yapmayı
       planlayan asla istemez; olmayan ve korkan çok ister. */
    const benim = G.fleets.some(f => f.e === e.id && f.ships.length &&
      typeof isColossus === 'function' && isColossus(f));
    if (benim || (e.colossusReserve || 0) > 0) d -= 1.6;
    else {
      let dusmandaVar = false;
      for (const f of G.fleets){
        if (!f.ships.length || f.e === e.id) continue;
        if (typeof isColossus !== 'function' || !isColossus(f)) continue;
        if (e.war[f.e] || (e.rel[f.e] || 0) < -30) { dusmandaVar = true; break; }
      }
      if (dusmandaVar) d += 1.3;                       // düşmanımda var, yasaklayalım
      if (mz === 'Pasifist') d += .5;
    }
  }

  /* FAZ 35: kriz tepkisi teklif AŞAMASINDA da geçerli — inatçı
     devlet pakta ancak paniğe kapılınca sponsor olur. */
  if (key === 'savunmaPakti' || key === 'birlesme'){
    const yakin = (typeof crisisProximity === 'function') ? crisisProximity(e) : 0;
    if (mz === 'Militarist')        d -= .95;
    else if (mz === 'İzolasyonist') d -= 1.15;
    else if (mz === 'Pasifist')     d += 1.10;
    if (yakin >= 2) d += 3.0;
    else if (yakin >= 1) d += 1.8;
  }

  /* Mizaç renkleri */
  if (mz === 'Tüccar' && (key === 'ticaretStd' || key === 'serbest' || key === 'madenTekel')) d += .45;
  if (mz === 'Pasifist' && (key === 'silahsiz' || key === 'savasYasak')) d += .5;
  if (mz === 'Militarist' && (key === 'muhafiz' || key === 'sinirGuv')) d += .45;
  if (mz === 'Militarist' && key === 'silahsiz') d -= .9;
  if (mz === 'İzolasyonist' && (key === 'ticaretStd' || key === 'serbest' || key === 'gocSerbest')) d -= .8;
  if (mz === 'Yayılmacı' && key === 'gocSerbest') d += .5;
  return d;
}

/* Aylık: her üye kuyruğa bir teklif koyar ya da mevcut bir teklifi
   destekler. Kuyruk uzunluğu sınırlı, eski teklifler solar. */
function agendaTick(){
  if (!councilExists()) return;
  const c = G.council;
  c.agenda = c.agenda || [];

  /* Solma: desteklenmeyen teklif zamanla düşer */
  for (let i = c.agenda.length - 1; i >= 0; i--){
    c.agenda[i].age++;
    if (c.agenda[i].age > 36) c.agenda.splice(i, 1);
  }

  /* Ayda bir üye söz alır — döngü ağırlaşmasın */
  const uyeler = c.members.filter(m => G.emps[m] && !G.emps[m].dead &&
    !G.emps[m].wild && m !== 0 &&
    !(typeof isVassal === 'function' && isVassal(G.emps[m]) && c.members.includes(G.emps[m].overlord)));
  if (!uyeler.length) return;
  const konusan = G.emps[uyeler[Math.floor(rnd() * uyeler.length)]];
  if (!konusan) return;

  const acik = openResolutions();
  if (!acik.length) return;

  /* En çok istediği yasayı bul */
  let enIyi = null, enD = .45;                 // eşik: kayıtsızsa susar
  for (const k of acik){
    const d = agendaDesire(konusan, k);
    if (d > enD){ enD = d; enIyi = k; }
  }
  if (!enIyi) return;

  const mevcut = c.agenda.find(a => a.key === enIyi);
  if (mevcut){
    if (!mevcut.backers.includes(konusan.id)) mevcut.backers.push(konusan.id);
    mevcut.age = 0;
  } else {
    if (c.agenda.length >= 6) c.agenda.shift();     // kuyruk tavanı
    c.agenda.push({key: enIyi, backers: [konusan.id], age: 0,
                   target: null, by: konusan.id});
  }
}

/* Şu an önerilebilir yasalar */
function openResolutions(){
  const c = G.council;
  if (!c) return [];
  const paryaAday = (typeof pariahCandidate === 'function') ? pariahCandidate() : null;
  const krizVar = (typeof crisisActive === 'function') && crisisActive();
  return Object.keys(RESOLUTIONS).filter(k => {
    const R = RESOLUTIONS[k];
    if (k === 'parya'){
      /* FAZ 37: çoklu parya — aday zaten parya değilse önerilebilir */
      if (!paryaAday) return false;
      const map = (typeof pariahMap === 'function') ? pariahMap() : {};
      return !map[paryaAday.id];
    }
    if (k === 'birlesme') return krizVar && !c.laws.birlesme;
    if (R.hedefli) return true;
    return !c.laws[k];
  });
}

/* Kuyruktan en güçlü destekli teklifi seç */
function topAgenda(){
  const c = G.council;
  if (!c || !c.agenda || !c.agenda.length) return null;
  const acik = openResolutions();
  let en = null, enW = 0;
  for (const a of c.agenda){
    if (acik.indexOf(a.key) < 0) continue;         // artık geçersiz
    let w = 0;
    for (const b of a.backers){
      const o = G.emps[b];
      if (o && !o.dead) w += voteWeight(o);
    }
    if (w > enW){ enW = w; en = a; }
  }
  return en;
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 32 — KAMPANYA DÖNEMİ
   Gündem ilan edilir, 3 ay boyunca oylar açık kalır. Bu pencerede
   oyuncu rüşvet ve şantajla `want` puanlarını manipüle edebilir.
   Süre dolunca startCouncilVote(kampanya) çağrılır.
   ═══════════════════════════════════════════════════════════════════ */
const CAMPAIGN_MONTHS = 3;

function prepareCouncilVote(){
  const c = G.council;
  if (!c || c.dead || c.vote || c.campaign) return;

  const open = openResolutions();
  if (!open.length) return;

  /* Gündemi şimdiden belirle — kampanya neyin üstüne yürüyecek? */
  const paryaAday = (typeof pariahCandidate === 'function') ? pariahCandidate() : null;
  const krizVar = (typeof crisisActive === 'function') && crisisActive();
  const kuyruk = (typeof topAgenda === 'function') ? topAgenda() : null;

  let key = null, sponsorId = null;
  if (c.firstLaw && open.includes(c.firstLaw)) key = c.firstLaw;
  else if (krizVar && open.includes('birlesme')) key = 'birlesme';
  else if (paryaAday && open.includes('parya')) key = 'parya';
  else if (kuyruk && open.includes(kuyruk.key)){ key = kuyruk.key; sponsorId = kuyruk.by; }
  else key = open[Math.floor(rnd() * open.length)];

  c.campaign = {key, sponsor: sponsorId, left: CAMPAIGN_MONTHS,
                bribed: {}, blackmailed: [], agenda: kuyruk || null};

  const R = RESOLUTIONS[key];
  if (c.members.includes(0) && G.emps[0] && !G.emps[0].dead){
    say('SENATO GÜNDEMİ AÇILDI — ' + R.ico + ' ' + R.n +
        ' · ' + CAMPAIGN_MONTHS + ' ay kampanya', 'sci');
  }
}

/* ── OY MANİPÜLASYONU ──
   İkisi de yalnız kampanya penceresinde çalışır. */

/* Rüşvet: şeffaf, risksiz, pahalı. Etki hedefin açgözlülüğüne bağlı. */
function bribeVote(e, target, miktar, yon){
  const c = G.council;
  if (!c || !c.campaign) return {ok:false, why:'Kampanya dönemi değil'};
  if (!target || target.dead) return {ok:false, why:'Hedef yok'};
  if (!c.members.includes(target.id)) return {ok:false, why:'Hedef konsey üyesi değil'};
  if (c.campaign.bribed[target.id]) return {ok:false, why:'Bu devlete zaten teklif yaptın'};
  miktar = Math.max(50, Math.round(miktar || 200));
  if ((e.res.min || 0) < miktar) return {ok:false, why:miktar + ' mineral gerekir'};

  e.res.min -= miktar;
  target.res.min = (target.res.min || 0) + miktar;

  /* Etki: miktar / hedefin büyüklüğü. Dev bir devlet kolay satın
     alınmaz; küçük bir devlet için aynı para servettir. */
  const olcek = Math.max(1, (typeof hegemonWeight === 'function')
    ? hegemonWeight(target) / 300 : 1);
  let guc = miktar / (260 * olcek);
  const P = (typeof personaOf === 'function') ? personaOf(target) : null;
  if (P){
    if (P.n === 'Tüccar') guc *= 1.45;            // para konuşur
    else if (P.n === 'Pasifist') guc *= .75;
    else if (P.n === 'İzolasyonist') guc *= .60;  // rüşvet onları rahatsız eder
  }
  /* FAZ 33 DÜZELTMESİ: clamp mizaç çarpanından ÖNCE uygulanıyordu,
     Tüccar'da 1.1 × 1.45 = 1.59 ile tavan aşılıyordu (ölçümde
     görüldü). Artık sınır en sonda — para tek başına oylamayı
     satın alamaz. */
  guc = clamp(guc, .05, 1.1);
  /* ═══ YÖN ═══
     Manipülasyon oyuncunun İSTEDİĞİ tarafa iter. Bir yasayı
     engellemek istiyorsan hayır yönünde rüşvet verirsin.
     (Tasarım hatasıydı: her şey "evet"e itiyordu ve muhalefet
      oynamak imkânsızdı.) */
  c.campaign.bribed[target.id] = (yon === 'no') ? -guc : guc;
  /* Küçük bir iyi niyet — para dostluk da getirir */
  target.rel[e.id] = clamp((target.rel[e.id] || 0) + 4, -100, 100);
  return {ok:true, guc, miktar};
}

/* Şantaj: istihbarat gerektirir, çok etkili, ifşa olursa yıkıcı. */
function blackmailVote(e, target, yon){
  const c = G.council;
  if (!c || !c.campaign) return {ok:false, why:'Kampanya dönemi değil'};
  if (!target || target.dead) return {ok:false, why:'Hedef yok'};
  if (!c.members.includes(target.id)) return {ok:false, why:'Hedef konsey üyesi değil'};
  if (c.campaign.blackmailed.some(b => (b.id !== undefined ? b.id : b) === target.id))
    return {ok:false, why:'Bu devlete zaten şantaj yaptın'};
  const lvl = (typeof intelOf === 'function') ? intelOf(e, target.id) : 0;
  if (lvl < 2) return {ok:false, why:'En az 2. seviye istihbarat gerekir'};
  if ((e.res.etk || 0) < 60) return {ok:false, why:'60 etki gerekir'};

  /* Elimizde gerçekten kirli bir sır var mı? */
  const kirli = (target.threat || 0) > 15 ||
    (typeof honorOf === 'function' && honorOf(target) < -10) ||
    (target.opLog || []).some(w => !w.caught);
  if (!kirli) return {ok:false, why:'Elinde kullanılabilir bir sır yok'};

  e.res.etk -= 60;
  const ch = (typeof sabotageChance === 'function')
    ? sabotageChance(e, target) : {basari:.4, ifsa:.3};

  if (rnd() < ch.basari){
    c.campaign.blackmailed.push({id: target.id, yon: yon === 'no' ? -1 : 1});
    return {ok:true, caught:false,
      msg: target.name + ' sessiz kalmayı seçti — oyu bizim tarafımızda'};
  }

  /* İFŞA: ajan yakalandı */
  if (typeof remember === 'function') remember(target, e.id, 'sabotaj');
  target.rel[e.id] = clamp(target.rel[e.id] - 50, -100, 100);
  target._lastCB = {n:'Senato Şantajı', w:1.35};
  /* Konsey bunu duyar — tüm üyeler tepki gösterir */
  for (const m of c.members){
    if (m === e.id || m === target.id) continue;
    const o = G.emps[m];
    if (o && !o.dead) o.rel[e.id] = clamp(o.rel[e.id] - 12, -100, 100);
  }
  if (typeof recordSabotage === 'function') recordSabotage('ifsa');
  return {ok:true, caught:true,
    msg: 'ŞANTAJ İFŞA OLDU — ' + target.name + ' senatoya kanıtları sundu'};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 33 — AI KAMPANYA BÜTÇESİ
   Faz 32'de yalnız oyuncu manipüle edebiliyordu; asimetrikti.
   Artık AI da kampanya döneminde kendi çıkarına olan yasa için
   rüşvet basıyor. Bütçe sınırlı: stoğun küçük bir dilimi.
   ═══════════════════════════════════════════════════════════════════ */
function aiCampaignTick(){
  const c = G.council;
  if (!c || c.dead || !c.campaign) return;
  const key = c.campaign.key;

  for (const m of c.members){
    const e = G.emps[m];
    if (!e || e.dead || e.wild || !e.ai) continue;
    /* Ayda tek girişim, kampanya başına da tek */
    if (c.campaign.aiSpent && c.campaign.aiSpent[e.id]) continue;

    const istek = (typeof agendaDesire === 'function') ? agendaDesire(e, key) : 0;
    /* Kayıtsızsa para harcamaz — eşik hem evet hem hayır yönünde */
    if (Math.abs(istek - .5) < .45) continue;
    const yon = istek > .5 ? 1 : -1;

    /* BÜTÇE: mineral stoğunun en fazla %12'si, tavan 600.
       Ekonomiyi çökertmemeli. */
    const butce = Math.min(600, Math.floor((e.res.min || 0) * .12));
    if (butce < 120) continue;

    /* Ters yönde duran, ucuz (düşük ağırlıklı) bir üye seç */
    let hedef = null, enUcuz = 1e9;
    for (const m2 of c.members){
      const o = G.emps[m2];
      if (!o || o.dead || o.wild || o.id === e.id) continue;
      if (c.campaign.bribed[o.id]) continue;               // zaten alınmış
      if (o.ally && o.ally[e.id]) continue;                // müttefik zaten yanımızda
      const oIstek = (typeof agendaDesire === 'function') ? agendaDesire(o, key) : .5;
      /* Bizimle aynı fikirdeyse rüşvete gerek yok */
      if ((oIstek > .5 ? 1 : -1) === yon) continue;
      const w = (typeof voteWeight === 'function') ? voteWeight(o) : 1;
      if (w < enUcuz){ enUcuz = w; hedef = o; }
    }
    if (!hedef) continue;

    const r = bribeVote(e, hedef, butce, yon > 0 ? 'yes' : 'no');
    if (r.ok){
      c.campaign.aiSpent = c.campaign.aiSpent || {};
      c.campaign.aiSpent[e.id] = butce;
      /* Oyuncu üye ise ve hedef oyuncuysa haber verilir */
      if (hedef.id === 0)
        say(e.name + ' senato oyun için ' + butce + ' mineral teklif etti', 'sci');
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 33 — SAHTE BAYRAK OPERASYONU
   En riskli istihbarat hamlesi: hedefe saldırırken suçu masum bir
   üçüncü devletin üstüne yıkarsın.
     KRİTİK BAŞARI  → hedef, masum devlete savaş ilan eder
     NORMAL BAŞARI  → iş görülür, suç masuma yazılır (savaş yok)
     FİYASKO        → suçüstü yakalanırsın: GALAKTİK PARYA,
                      konseyden ihraç, sınır kalkanları %50 zayıflar
   Faz 15'teki w.framed altyapısını kullanır — Derin Soruşturma
   bu iftirayı sonradan ortaya çıkarabilir.
   ═══════════════════════════════════════════════════════════════════ */

function falseFlagCost(){ return {etk: 140}; }

/* Uygun mu? Hem hedef hem günah keçisi gerekir. */
function canFalseFlag(e, target, patsy){
  for (const o of [target,patsy]){
    const q = spyTargetCheck(e, o);
    if (!q.ok) return q;
  }
  if (!e || !target || !patsy) return {ok:false, why:'Hedef ve günah keçisi gerekir'};
  if (target.id === patsy.id) return {ok:false, why:'Aynı devlet olamaz'};
  if (target.id === e.id || patsy.id === e.id) return {ok:false, why:'Kendini seçemezsin'};
  if (target.dead || patsy.dead) return {ok:false, why:'Devlet yok'};
  const lvl = (typeof intelOf === 'function') ? intelOf(e, target.id) : 0;
  if (lvl < 2) return {ok:false, why:'Hedefte en az 2. seviye istihbarat gerekir'};
  if (!e.contact[patsy.id]) return {ok:false, why:'Günah keçisiyle temasın yok'};
  if ((e.res.etk || 0) < falseFlagCost().etk)
    return {ok:false, why:falseFlagCost().etk + ' etki gerekir'};
  /* İnandırıcılık: hedef zaten günah keçisinden nefret ediyorsa iş kolay */
  return {ok:true};
}

/* tur: 'sabotaj' (konsey oyu) veya 'tekno' (teknoloji hırsızlığı) */
function falseFlagResult(e, target, patsy, r){
  r.cost = falseFlagCost().etk;
  r.basarili = !!r.framed;
  r.outcome = r.basarili ? 'basari' : (r.caught ? 'ifsa' : 'sonucsuz');
  e.opLog = e.opLog || [];
  e.opLog.push({t:G.memAge || 0, k:'falseFlag', o:target.id, patsy:patsy.id,
    caught:!!r.caught, outcome:r.outcome, cost:r.cost, actorSummary:r.msg});
  if (e.opLog.length > 20) e.opLog.splice(0,e.opLog.length-20);
  if (r.caught){
    target.hitLog = target.hitLog || [];
    target.hitLog.push({t:G.memAge || 0, k:'falseFlag', by:e.id, caught:true, known:true, outcome:'ifsa'});
  }
  if (target.hitLog && target.hitLog.length > 30)
    target.hitLog.splice(0,target.hitLog.length-30);
  return r;
}
function falseFlagOp(e, target, patsy, tur){
  if (tur !== 'tekno' && tur !== 'sabotaj') return {ok:false, why:'Bilinmeyen sahte bayrak türü'};
  const chk = canFalseFlag(e, target, patsy);
  if (!chk.ok) return chk;
  e.res.etk -= falseFlagCost().etk;

  const ch = (typeof sabotageChance === 'function')
    ? sabotageChance(e, target) : {basari:.4, ifsa:.3};
  /* Sahte bayrak normal operasyondan zor: iki katmanlı yalan */
  const basari = clamp(ch.basari * .75, .04, .60);
  const fiyasko = clamp(ch.ifsa * 1.45, .08, .68);

  /* İNANDIRICILIK: hedefin günah keçisine bakışı */
  const husumet = -(target.rel[patsy.id] || 0);          // negatif ilişki = artı
  const inandirici = clamp(.25 + husumet / 90, .1, 1);

  if (rnd() < basari){
    /* ── İŞ GÖRÜLDÜ ── */
    let sonuc = '', payloadApplied = false;
    if (tur === 'tekno'){
      const adaylar = [];
      for (const id in (target.techs || {}))
        if (!(e.techs && e.techs[id]) && TECHS[id]) adaylar.push(id);
      if (adaylar.length){
        adaylar.sort((a, b) => (TECHS[b].c || 0) - (TECHS[a].c || 0));
        const id = adaylar[Math.floor(rnd() * Math.min(3, adaylar.length))];
        const kazanc = Math.round((TECHS[id].c || 0) * .5);
        e.res.ara = (e.res.ara || 0) + kazanc;
        payloadApplied = kazanc > 0;
        sonuc = TECHS[id].n + ' çalındı (+' + kazanc + ' araştırma)';
      } else sonuc = 'Çalınacak veri bulunamadı';
    } else {
      /* Konsey oyu sabotajı: hedefin oyu bizim tarafa kayar */
      const c = G.council;
      if (c && c.campaign){
        c.campaign.blackmailed.push({id: target.id, yon: 1});
        payloadApplied = true;
        sonuc = target.name + ' senatoda susturuldu';
      } else sonuc = 'Hedefin diplomatik ağı sarsıldı';
      payloadApplied = payloadApplied || target.res.etk > 0;
      target.res.etk = Math.max(0, (target.res.etk || 0) - 80);
    }

    /* SUÇ GÜNAH KEÇİSİNE YAZILIR — Faz 15 kalıbı */
    target.hitLog = target.hitLog || [];
    const source = memoryEvent(e);
    target.hitLog.push({t: G.memAge || 0, k: tur === 'tekno' ? 'teknoCal' : 'sabotaj',
                        by: patsy.id, framed: e.id, caught: false, known: true, source});
    if (typeof remember === 'function') remember(target, patsy.id, 'sabotaj', source);
    target.rel[patsy.id] = clamp((target.rel[patsy.id] || 0) - 45, -100, 100);

    /* ── KRİTİK BAŞARI: hedef masuma savaş açar ── */
    let savas = false;
    if (rnd() < inandirici * .55 && !target.war[patsy.id] &&
        typeof warAuthorize === 'function'){
      const auth = ['_warAuth','_warWhy'].map(k => [k,Object.prototype.hasOwnProperty.call(G,k),G[k]]);
      const hadCB = Object.prototype.hasOwnProperty.call(target,'_lastCB'), oldCB = target._lastCB;
      try {
        target._lastCB = {n: 'Sahte Bayrak Kanıtı', w: 1.30};
        warAuthorize(target, patsy, target._lastCB);
        declareWar(target, patsy);
      } finally {
        savas = !!(target.war[patsy.id] && patsy.war[target.id]);
        for (const [k,had,value] of auth){ if (had) G[k]=value; else delete G[k]; }
        if (!savas){ if (hadCB) target._lastCB=oldCB; else delete target._lastCB; }
      }
    }
    if (typeof recordSabotage === 'function') recordSabotage('falseflag');
    return falseFlagResult(e, target, patsy, {ok:true, caught:false, framed:true, payloadApplied, savas, sonuc,
      msg: sonuc + ' — suç ' + patsy.name + ' üstüne yıkıldı' +
           (savas ? '. ' + target.name + ' ona SAVAŞ İLAN ETTİ!' : '')});
  }

  if (rnd() < fiyasko){
    /* ── FİYASKO: SUÇÜSTÜ ── */
    if (typeof remember === 'function'){
      remember(target, e.id, 'sahteBayrak');
      remember(patsy, e.id, 'sahteBayrak');
    }
    target.rel[e.id] = -100;
    patsy.rel[e.id] = -100;

    /* GALAKTİK PARYA */
    e.threat = (e.threat || 0) + 75;
    for (const x of G.emps){
      if (x.dead || x.wild || x.id === e.id) continue;
      x.rel[e.id] = clamp((x.rel[e.id] || 0) - 55, -100, 100);
      /* Sınırlar kapanır */
      if (x.passage) delete x.passage[e.id];
      if (e.passage) delete e.passage[x.id];
    }
    /* Konseyden ihraç */
    const c = G.council;
    if (c && !c.dead && c.members.includes(e.id)){
      c.members = c.members.filter(m => m !== e.id);
      c.targeted = c.targeted || {};
      if (typeof addPariah === 'function') addPariah(e.id);   // FAZ 37: çoklu
    }
    /* CEZA: sınır sistemlerindeki kalkanlar bu tur %50 zayıflar */
    let vurulan = 0;
    for (const c2 of (e.colonies || [])){
      const sy = G.sys[c2.s];
      if (!sy) continue;
      /* Sınır sistemi: komşusunda yabancı var mı? */
      let sinir = false;
      for (const l of sy.lanes){
        const o2 = G.sys[l];
        if (o2 && o2.owner >= 0 && o2.owner !== e.id){ sinir = true; break; }
      }
      if (!sinir) continue;
      const pl = sy.planets[c2.p];
      if (pl && pl.col && pl.col.shield > 0){
        pl.col.shield = Math.round(pl.col.shield * .5);
        vurulan++;
      }
    }
    if (typeof recalcMods === 'function') G.emps.forEach(x => { if (!x.dead) recalcMods(x); });
    if (typeof recordSabotage === 'function') recordSabotage('ifsa');
    return falseFlagResult(e, target, patsy, {ok:true, caught:true, vurulan,
      msg: 'SUÇÜSTÜ YAKALANDIN — GALAKTİK PARYA İLAN EDİLDİN. Konseyden ihraç ' +
           'edildin, tüm sınırlar kapandı ve ' + vurulan +
           ' sınır dünyasının kalkanı yarıya düştü.'});
  }

  /* Sessiz başarısızlık */
  if (typeof recordSabotage === 'function') recordSabotage('sessiz');
  return falseFlagResult(e, target, patsy,
    {ok:true, caught:false, msg:'Operasyon sonuçsuz kaldı — ifşa olmadı'});
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 34 — KENDİ ÜZERİMİZDEKİ KOMPLOYU ÇÖZ
   OPS.sorusturma bir HEDEF gerektiriyor ("şu devletin üstündeki
   iftirayı çöz"). Ama oyuncu çoğu zaman şunu sorar: "bana neden
   savaş açıldı, perde arkasında kim var?"
   Bu fonksiyon hedefsiz çalışır: kendi hitLog'umuzdaki iftiralı
   ve çözülmemiş dosyaları tarar, kuklacıyı bulur.
   ═══════════════════════════════════════════════════════════════════ */
const DEEP_INVESTIGATE_COST = 90;

/* Elimizde soruşturulacak bir şey var mı? Arayüz bunu okur. */
function deepInvestigateInfo(e){
  const log = e.hitLog || [];
  const iftirali = log.filter(w => w.framed !== undefined);
  const acik = log.filter(w => !w.known);
  /* Parya isek ya da sebepsiz savaştaysak şüphe güçlüdür */
  let supheliSavas = 0;
  for (const o of G.emps){
    if (o.dead || o.wild || o.crisisSide || !e.war[o.id]) continue;
    const cb = (o.warCause && o.warCause[e.id]) || '';
    if (cb === 'Sahte Bayrak Kanıtı' || cb === 'Sabotaj İfşası' ||
        cb === 'Teknoloji Hırsızlığı' || cb === 'Senato Şantajı') supheliSavas++;
  }
  return {
    iftirali: iftirali.length,
    acik: acik.length,
    supheliSavas,
    varMi: (iftirali.length + acik.length) > 0,
    maliyet: DEEP_INVESTIGATE_COST
  };
}

function deepInvestigate(e){
  if (!e) return {ok:false, why:'—'};
  if ((e.res.etk || 0) < DEEP_INVESTIGATE_COST)
    return {ok:false, why:DEEP_INVESTIGATE_COST + ' etki gerekir'};
  const bilgi = deepInvestigateInfo(e);
  if (!bilgi.varMi)
    return {ok:false, why:'Soruşturulacak şüpheli dosya yok — kimse sana komplo kurmamış'};

  e.res.etk -= DEEP_INVESTIGATE_COST;

  /* Başarı: kendi ajanlarımızın gücü + karşı tarafın gizleme becerisi */
  const prof = (typeof aiProfile === 'function') ? aiProfile(e) : {dip:.5, sci:.5};
  let sans = .38 + prof.dip * .18 + prof.sci * .12;
  if (typeof hasCivic === 'function'){
    if (hasCivic(e, 'shadow')) sans += .20;
    if (hasCivic(e, 'counter')) sans += .15;
  }
  sans = clamp(sans, .20, .88);
  if (rnd() > sans)
    return {ok:true, cozuldu:false, msg:'Soruşturma çıkmaza girdi — izler silinmiş'};

  /* ── ÖNCELİK: İFTİRALI DOSYA (gerçek kuklacı) ── */
  const iftirali = (e.hitLog || []).filter(w => w.framed !== undefined);
  if (iftirali.length){
    const d = iftirali[Math.floor(rnd() * iftirali.length)];
    const sucsuz = G.emps[d.by];              // suçu üstüne yıkılan
    const gercek = G.emps[d.framed];          // asıl fail
    d.by = d.framed;
    delete d.framed;
    d.known = true;
    d.foundAt = G.memAge || 0;

    /* Masuma karşı kin siliniyor, ilişki onarılıyor */
    if (sucsuz && !sucsuz.dead){
      forgetMemoryEvent(e, sucsuz.id, d.source);
      e.rel[sucsuz.id] = clamp((e.rel[sucsuz.id] || 0) + 35, -100, 100);
      sucsuz.rel[e.id] = clamp((sucsuz.rel[e.id] || 0) + 20, -100, 100);
      if (typeof remember === 'function') remember(sucsuz, e.id, 'yardimEtti');
    }
    /* Kin gerçek faile dönüyor + savaş nedeni */
    if (gercek && !gercek.dead){
      if (typeof remember === 'function') remember(e, gercek.id, 'sahteBayrak');
      e.rel[gercek.id] = clamp((e.rel[gercek.id] || 0) - 55, -100, 100);
      e._lastCB = {n:'İfşa Edilmiş Komplo', w:1.40};
      /* Galaksi de öğrenir — iftiracının itibarı gider */
      for (const x of G.emps){
        if (x.dead || x.wild || x.crisisSide || x.id === gercek.id || x.id === e.id) continue;
        x.rel[gercek.id] = clamp((x.rel[gercek.id] || 0) - 18, -100, 100);
      }
      /* Tehdit puanı tavanlı: üst üste ifşalar sonsuz birikmesin
         (testte 60 soruşturmada 975'e çıkmıştı). */
      gercek.threat = Math.min(120, (gercek.threat || 0) + 25);
    }
    return {ok:true, cozuldu:true, kuklaci: gercek ? gercek.id : null,
      sucsuz: sucsuz ? sucsuz.id : null,
      msg: (gercek ? gercek.name : 'Bilinmeyen bir el') + ' perde arkasındaydı' +
           (sucsuz ? ' — ' + sucsuz.name + ' suçsuzmuş' : '') +
           '. Galaksi gerçeği öğrendi ve elimizde artık meşru bir savaş nedeni var.'};
  }

  /* ── İKİNCİL: FAİLİ MEÇHUL DOSYA ── */
  const acik = (e.hitLog || []).filter(w => !w.known);
  if (acik.length){
    const d = acik[Math.floor(rnd() * acik.length)];
    if (d.by === undefined)
      return {ok:true, cozuldu:false, msg:'Dosya soğuk — iz kalmamış'};
    d.known = true;
    d.foundAt = G.memAge || 0;
    const fail = G.emps[d.by];
    if (fail && !fail.dead){
      if (typeof remember === 'function') remember(e, fail.id, 'komplo');
      e.rel[fail.id] = clamp((e.rel[fail.id] || 0) - 30, -100, 100);
    }

    /* ═══ FAZ 43: KIŞKIRTMA İFŞASI ═══
       Halkı ayaklandırmak sıradan bir sabotaj değil — iç işlere
       müdahaledir. Galaksi duyar, mağdur savaş nedeni kazanır. */
    if (d.k === 'kiskirt' && fail && !fail.dead){
      e.rel[fail.id] = clamp((e.rel[fail.id] || 0) - 25, -100, 100);
      e._lastCB = {n:'İç İşlerine Müdahale', w:1.28};
      fail.threat = Math.min(120, (fail.threat || 0) + 20);
      for (const x of G.emps){
        if (x.dead || x.wild || x.crisisSide) continue;
        if (x.id === fail.id || x.id === e.id) continue;
        x.rel[fail.id] = clamp((x.rel[fail.id] || 0) - 14, -100, 100);
      }
      /* Kışkırtılan koloninin huzursuzluğu kırılır: halk kandırıldığını anlar */
      const sy2 = (d.sys !== undefined) ? G.sys[d.sys] : null;
      const pl2 = sy2 && (d.pi !== undefined) ? sy2.planets[d.pi] : null;
      if (pl2 && pl2.col){
        if (pl2.col.unrest) delete pl2.col.unrest;
        pl2.col.secede = Math.max(0, (pl2.col.secede || 0) - 8);
      }
      const ad2 = (pl2 && pl2.col) ? (pl2.col.name || pl2.name) : 'bir dünyamız';
      say('🔍 KOMPLO ÇÖZÜLDÜ — ' + fail.name + ', ' + ad2 +
          ' halkını ayaklandıran eldi. Galaksi gerçeği öğrendi.', 'win');
      return {ok:true, cozuldu:true, kuklaci: fail.id, kiskirtma:true,
        msg: fail.name + ' halkımızı ayaklandıran eldi — ' + ad2 +
             ' isyanı dış kışkırtmaydı. Artık meşru bir savaş nedenimiz var.'};
    }

    return {ok:true, cozuldu:true, kuklaci: fail ? fail.id : null,
      msg: fail ? (fail.name + ' bu operasyonun arkasındaydı') : 'Dosya çözüldü'};
  }
  return {ok:true, cozuldu:false, msg:'Soruşturma sonuçsuz kaldı'};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 35 — KRİZ YAKINLIĞI
   Bir devlet Sürü'yü ne kadar yakından hissediyor?
     0 = uzak, haberi bile yok
     1 = Sürü filosu sınır sistemine dayandı
     2 = kendi gezegeni yutuldu
   İnatçı AI'ların panik eşiği buna bağlı.
   ═══════════════════════════════════════════════════════════════════ */
function crisisProximity(e){
  if (!e || G.crisisId === undefined) return 0;
  if (!crisisActive || !crisisActive()) return 0;

  /* 2 — kendi gezegenim yutuldu mu? */
  if (e._devoured) return 2;

  /* 1 — Sürü filosu benim ya da komşumun sisteminde mi? */
  const benim = {};
  for (const c of (e.colonies || [])) benim[c.s] = 1;
  for (const sy of G.sys) if (sy.owner === e.id) benim[sy.id] = 1;

  for (const f of G.fleets){
    if (f.e !== G.crisisId || !f.ships || !f.ships.length) continue;
    const sid = f.sys >= 0 ? f.sys : (f.mv ? f.mv.to : -1);
    if (sid < 0) continue;
    if (benim[sid]) return 1;
    const sy = G.sys[sid];
    if (!sy) continue;
    for (const l of sy.lanes) if (benim[l]) return 1;
  }
  return 0;
}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 35 — ULTİMATOM
   "Ya pakta katılırsın ya da seni biz yok ederiz."
   Reddedilirse savaş nedeni doğar. Kabul edilirse hedef pakta
   evet oyu vermeye mecbur kalır.
   ═══════════════════════════════════════════════════════════════════ */
const ULTIMATUM_COST = 110;

function canUltimatum(e, target){
  if (!e || !target || target.dead) return {ok:false, why:'Hedef yok'};
  if (target.id === e.id) return {ok:false, why:'Kendine ultimatom veremezsin'};
  if (!crisisActive || !crisisActive())
    return {ok:false, why:'Yalnızca galaktik kriz sırasında'};
  if (target.wild || target.crisisSide)
    return {ok:false, why:'Sürü müzakere etmez'};
  if (!e.contact[target.id]) return {ok:false, why:'Temasın yok'};
  if (e.war[target.id]) return {ok:false, why:'Zaten savaştasınız'};
  if (target._ultimatum && target._ultimatum.by === e.id)
    return {ok:false, why:'Bu devlete zaten ultimatom verdin'};
  if ((e.res.etk || 0) < ULTIMATUM_COST)
    return {ok:false, why:ULTIMATUM_COST + ' etki gerekir'};
  /* Hedef zaten pakta evet demişse anlamsız */
  const c = G.council;
  if (c && c.laws && c.laws.savunmaPakti && c.members.includes(target.id))
    return {ok:false, why:'Zaten pakta bağlı'};
  return {ok:true};
}

function sendUltimatum(e, target){
  const chk = canUltimatum(e, target);
  if (!chk.ok) return chk;
  e.res.etk -= ULTIMATUM_COST;
  target._ultimatum = {by: e.id, at: G.memAge || 0};

  /* Boyun eğme kararı: güç farkı + kriz yakınlığı + mizaç */
  const gucFark = totalPower(e) / Math.max(1, totalPower(target));
  const tehlike = crisisProximity(target);
  const P = (typeof personaOf === 'function') ? personaOf(target) : null;
  let boyun = .18 + clamp((gucFark - 1) * .35, -.25, .55) + tehlike * .22;
  if (P){
    if (P.n === 'Pasifist') boyun += .25;
    else if (P.n === 'Militarist') boyun -= .28;
    else if (P.n === 'İzolasyonist') boyun -= .18;
  }
  /* Zaten dostsak daha kolay ikna olur */
  boyun += clamp((target.rel[e.id] || 0) / 220, -.25, .25);
  boyun = clamp(boyun, .05, .90);

  if (rnd() < boyun){
    /* ── KABUL ── */
    target._paktSoz = e.id;                 // oylamada evet demeye mecbur
    target.rel[e.id] = clamp((target.rel[e.id] || 0) - 18, -100, 100);
    if (typeof remember === 'function') remember(target, e.id, 'tehdit');
    return {ok:true, kabul:true,
      msg: target.name + ' boyun eğdi — Savunma Paktı\'na katılacak'};
  }

  /* ── RET: savaş nedeni ── */
  e._lastCB = {n:'Reddedilen Ultimatom', w:1.15};
  target.rel[e.id] = clamp((target.rel[e.id] || 0) - 35, -100, 100);
  if (typeof remember === 'function') remember(target, e.id, 'tehdit');
  /* Galaksi bunu hoş karşılamaz: kriz varken iç savaş çıkarmak */
  for (const x of G.emps){
    if (x.dead || x.wild || x.crisisSide || x.id === e.id || x.id === target.id) continue;
    x.rel[e.id] = clamp((x.rel[e.id] || 0) - 8, -100, 100);
  }
  return {ok:true, kabul:false,
    msg: target.name + ' ultimatomu REDDETTİ — savaş nedeni doğdu'};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 37 — ÇOKLU PARYA
   ÖLÇÜM (Faz 36): c.targeted.parya TEK bir ID tutuyordu. Yeni parya
   ilan edilince eskisi sessizce serbest kalıyordu — 60 yılda 22
   parya döneminin 17'si "devir" ile bitmişti, af hiç dolmuyordu.
   Artık c.pariahs = {empId: {since}} sözlüğü. Her devletin af
   sayacı BAĞIMSIZ işler.
   Eski c.targeted.parya alanı geriye dönük uyumluluk için
   korunuyor (en son ilan edilen paryayı gösterir).
   ═══════════════════════════════════════════════════════════════════ */

/* Parya sözlüğünü hazırla + eski kayıtları taşı */
function pariahMap(){
  const c = G.council;
  if (!c) return null;
  if (!c.pariahs){
    c.pariahs = {};
    /* Eski tek-slot kaydı varsa taşı (kayıt uyumluluğu) */
    if (c.targeted && c.targeted.parya !== undefined)
      c.pariahs[c.targeted.parya] = {since: c.pariahSince !== undefined
        ? c.pariahSince : (G.memAge || 0)};
  }
  return c.pariahs;
}

function addPariah(id){
  const c = G.council;
  if (!c) return false;
  const map = pariahMap();
  if (map[id]) return false;                    // zaten parya
  map[id] = {since: G.memAge || 0};
  c.targeted = c.targeted || {};
  c.targeted.parya = id;                        // uyumluluk: son ilan
  return true;
}

function removePariah(id){
  const c = G.council;
  if (!c) return;
  const map = pariahMap();
  delete map[id];
  if (c.targeted && c.targeted.parya === id){
    const kalan = Object.keys(map);
    if (kalan.length) c.targeted.parya = +kalan[kalan.length - 1];
    else delete c.targeted.parya;
  }
}

function pariahList(){
  const map = pariahMap();
  if (!map) return [];
  return Object.keys(map).map(Number).filter(id => G.emps[id] && !G.emps[id].dead);
}

function pariahCount(){ return pariahList().length; }


/* ═══════════════════════════════════════════════════════════════════
   FAZ 37 — GÜÇ YOZLAŞMASI
   Koruyucu unvanı bir ödüldür ama militarist/otoriter bir devlette
   iştah açar. Kriz bittikten birkaç yıl sonra yetkiyi devretmeyi
   reddedip "Yeni Düzen" ilan edebilir: unvan kalıcı olur, ama
   galaksi ona sırtını döner.
   ═══════════════════════════════════════════════════════════════════ */
const GUARDIAN_TERM = 60;        // 5 yıl sonra devretme zamanı
const GUARDIAN_VETO_GAP = 180;   // 15 yılda bir veto hakkı

function guardianTick(){
  for (const e of G.emps){
    if (e.dead || e.wild || e.crisisSide || !e.guardian) continue;
    const g = e.guardian;
    const gecen = (G.memAge || 0) - g.since;

    /* Yeni Düzen ilan edilmişse artık karar verilmiş */
    if (g.newOrder) continue;

    if (gecen < GUARDIAN_TERM) continue;

    /* ── DEVRETME KARARI ── */
    const P = (typeof personaOf === 'function') ? personaOf(e) : null;
    const mz = P ? P.n : '';
    const otoriter = (e.ethics && (e.ethics.aut || 0) >= 1);
    const militarist = (mz === 'Militarist') || (e.ethics && (e.ethics.mil || 0) >= 1);

    if (!militarist && !otoriter){
      /* Onurlu devir */
      delete e.guardian;
      if (e.id === 0)
        say('Koruyucu yetkilerini konseye devrettin — galaksi minnettar', 'win');
      else
        say(e.name + ' Koruyucu yetkilerini konseye devretti');
      for (const x of G.emps){
        if (x.dead || x.wild || x.crisisSide || x.id === e.id) continue;
        x.rel[e.id] = clamp((x.rel[e.id] || 0) + 15, -100, 100);
      }
      G.emps.forEach(x => { if (!x.dead) recalcMods(x); });
      continue;
    }

    /* ── YENİ DÜZEN ──
       Yetki bırakılmıyor. Unvan kalıcı, bedeli ağır. */
    if (e.ai && rnd() > .55) continue;         // AI biraz tereddüt eder
    g.newOrder = true;
    g.declaredAt = G.memAge || 0;
    e.threat = (e.threat || 0) + 85;
    for (const x of G.emps){
      if (x.dead || x.wild || x.crisisSide || x.id === e.id) continue;
      x.rel[e.id] = clamp((x.rel[e.id] || 0) - 60, -100, 100);
      if (typeof remember === 'function') remember(x, e.id, 'ihanet');
    }
    if (e.id === 0)
      say('👑 YENİ DÜZEN İLAN ETTİN — Koruyucu yetkilerin kalıcı. ' +
          'Galaksi sana sırtını döndü.', 'war');
    else
      say('👑 ' + e.name + ' YENİ DÜZEN ilan etti — Koruyucu yetkilerini ' +
          'bırakmayı reddediyor!', 'war');
    G.emps.forEach(x => { if (!x.dead) recalcMods(x); });
  }
}

/* Koruyucu veto hakkı: 15 yılda bir yürürlükteki bir yasayı iptal */
function guardianCanVeto(e){
  if (!e || !e.guardian) return false;
  const son = e.guardian.vetoAt || 0;
  return (G.memAge || 0) - son >= GUARDIAN_VETO_GAP;
}

function guardianVeto(e, key){
  if (!guardianCanVeto(e)) return {ok:false, why:'Veto hakkın henüz dolmadı'};
  const c = G.council;
  if (!c || !c.laws || !c.laws[key]) return {ok:false, why:'Bu yasa yürürlükte değil'};
  delete c.laws[key];
  e.guardian.vetoAt = G.memAge || 0;
  G.emps.forEach(x => { if (!x.dead) recalcMods(x); });
  const R = RESOLUTIONS[key];
  say((e.id === 0 ? 'VETO ETTİN' : e.name + ' veto etti') + ' — ' +
      (R ? R.n : key) + ' yürürlükten kalktı', 'war');
  /* Veto galaksiyi rahatsız eder */
  for (const x of G.emps){
    if (x.dead || x.wild || x.crisisSide || x.id === e.id) continue;
    x.rel[e.id] = clamp((x.rel[e.id] || 0) - 10, -100, 100);
  }
  return {ok:true};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 38 — İSYANCI İTTİFAKI (GÖLGELER SAVAŞI)
   Yozlaşmış bir Koruyucu "Yeni Düzen" ilan ettiğinde, ona düşman
   devletler gizlice birleşir. Önce gölgede kalıp casuslukla
   yıpratırlar; güçleri yettiği an açığa çıkıp Özgürlük Savaşı
   ilan ederler.
   G.rebelAlliance = {target, members:[], since, revealed}
   ═══════════════════════════════════════════════════════════════════ */

/* Yozlaşmış koruyucu var mı? */
function corruptGuardian(){
  for (const e of G.emps){
    if (e.dead || e.wild || e.crisisSide) continue;
    if (e.guardian && e.guardian.newOrder) return e;
  }
  return null;
}

function inRebelAlliance(e){
  const ra = G.rebelAlliance;
  return !!(ra && !ra.done && e && ra.members.indexOf(e.id) >= 0);
}

/* İttifakın toplam askerî gücü */
function rebelPower(){
  const ra = G.rebelAlliance;
  if (!ra || ra.done) return 0;
  let p = 0;
  for (const id of ra.members){
    const e = G.emps[id];
    if (e && !e.dead) p += totalPower(e);
  }
  return p;
}

function rebelTick(){
  const zalim = corruptGuardian();

  /* Koruyucu düştüyse ittifak dağılır */
  if (!zalim){
    if (G.rebelAlliance && !G.rebelAlliance.done){
      G.rebelAlliance.done = true;
      if (G.rebelAlliance.members.indexOf(0) >= 0)
        say('İsyancı İttifakı dağıldı — zalim artık yok', 'win');
    }
    return;
  }

  /* İttifakı kur */
  if (!G.rebelAlliance || G.rebelAlliance.target !== zalim.id || G.rebelAlliance.done){
    G.rebelAlliance = {target: zalim.id, members: [], since: G.memAge || 0,
                       revealed: false, done: false};
  }
  const ra = G.rebelAlliance;

  /* ── ÜYE TOPLAMA ──
     Koruyucudan nefret eden, vasalı olmayan, ondan bağımsız
     devletler gizlice katılır. */
  for (const e of G.emps){
    if (e.dead || e.wild || e.crisisSide || e.id === zalim.id) continue;
    if (ra.members.indexOf(e.id) >= 0) continue;
    /* Vasalı isyan edemez */
    if (typeof isVassal === 'function' && isVassal(e) && e.overlord === zalim.id) continue;
    /* Müttefiki de katılmaz */
    if (e.ally && e.ally[zalim.id]) continue;
    /* ═══ FAZ 39: KATILIM EŞİĞİ GEVŞETİLDİ ═══
       ÖLÇÜM: −35 eşiğiyle 60 yıllık koşuda ittifak 1-2 üyede
       kalıyordu; Yeni Düzen −60 ilişki cezası verse de zaman
       içinde ilişkiler onarılıyor. Zalim yalnız nefretle değil,
       KORKUYLA da düşman toplar: tehdidi büyükse tarafsızlar da
       katılır. */
    const rel = e.rel[zalim.id] || 0;
    const korku = (zalim.threat || 0) >= 60;
    const esik = korku ? -10 : -35;
    if (rel > esik) continue;
    /* Oyuncu kendi kararını verir — otomatik katılmaz */
    if (e.id === 0) continue;
    ra.members.push(e.id);
    if (G.p && !G.p.dead && e.id !== 0 && ra.members.length === 1)
      say('Gölgelerde bir şey kıpırdıyor — ' + zalim.name +
          ' karşıtı devletler fısıldaşıyor', 'sci');
  }

  if (!ra.members.length) return;

  /* ── TOPYEKÛN İSYAN ──
     İttifakın gücü zalimi aştığı an gölgeden çıkılır.
     ÖLÇÜM: eşik ×1.05 iken ittifak kurulur kurulmaz açığa
     çıkıyordu (6 devletin toplamı tek devleti zaten aşıyor).
     Gölgeler Savaşı hiç yaşanmıyordu. Artık iki şart var:
     ezici üstünlük (×1.8) VE en az 2 yıllık hazırlık. */
  if (!ra.revealed){
    const bizim = rebelPower();
    const onun = totalPower(zalim);
    const hazirlik = (G.memAge || 0) - (ra.since || 0);
    if (bizim > onun * 1.8 && hazirlik >= 24){
      ra.revealed = true;
      ra.revealedAt = G.memAge || 0;
      for (const id of ra.members){
        const e = G.emps[id];
        if (!e || e.dead || e.war[zalim.id]) continue;
        const cb = {n:'Özgürlük Savaşı', w:1.45};
        e._lastCB = cb;
        if (typeof warAuthorize === 'function'){
          warAuthorize(e, zalim, cb);
          declareWar(e, zalim);
          if (typeof warAuthClear === 'function') warAuthClear();
        }
        /* CB kaydı declareWar sonrası silinebiliyor — geri yaz */
        e.warCause = e.warCause || {};
        e.warCause[zalim.id] = 'Özgürlük Savaşı';
      }
      /* İsyancılar birbirleriyle barışır — ortak düşman */
      for (const a of ra.members){
        for (const b of ra.members){
          if (a >= b) continue;
          const ea = G.emps[a], eb = G.emps[b];
          if (!ea || !eb || ea.dead || eb.dead) continue;
          if (ea.war[b] && typeof makePeace === 'function') makePeace(ea, eb,'rebel-coalition',null);
          ea.rel[b] = clamp((ea.rel[b] || 0) + 30, -100, 100);
          eb.rel[a] = clamp((eb.rel[a] || 0) + 30, -100, 100);
        }
      }
      say('⚔ ÖZGÜRLÜK SAVAŞI — ' + ra.members.length +
          ' devlet ' + zalim.name + ' zulmüne karşı ayaklandı!', 'war');
      if (typeof UI !== 'undefined' && UI.eventArt)
        UI.eventArt('infaz', 'ÖZGÜRLÜK SAVAŞI',
          zalim.name + ' Yeni Düzen\'ini yıkmak için ' + ra.members.length +
          ' devlet gölgelerden çıktı. Galaktik iç savaş başladı.');
    }
  }
}

/* İsyancıların casusluk avantajı — sabotageChance içinden okunur */
function rebelOpBonus(e, target){
  if (!inRebelAlliance(e)) return 0;
  const ra = G.rebelAlliance;
  if (!ra || target.id !== ra.target) return 0;
  return .30;                                   // +%30 başarı
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 39 — İMPARATORLUĞUN PARÇALANMASI (BALKANİZASYON)
   Özgürlük Savaşı topyekûn fetihle değil, BAŞKENTİN düşmesiyle
   biter. Zalim yıkıldığında elinde kalan gezegenlerin yarısı
   ayrılıp yepyeni bağımsız bir devlet kurar.
   ═══════════════════════════════════════════════════════════════════ */

const SUCCESSOR_NAMES = [
  'Özgür Dünyalar Birliği', 'Yeni Cumhuriyet', 'Ardıl Hanedan',
  'Bağımsız Kolonyal Lig', 'Küllerden Doğan Konfederasyon',
  'Hür Yıldızlar Meclisi', 'Devrik Rejim Kalıntıları',
  'Sınır Dünyaları İttifakı'
];

/* Başkent düştü mü? Her ay kontrol edilir. */
function rebelVictoryCheck(){
  const ra = G.rebelAlliance;
  if (!ra || ra.done) return;
  /* ═══ FAZ 39: GİZLİ İTTİFAK DA ZAFERİ GÖRÜR ═══
     ÖLÇÜM: tohum 99'da zalimin başkenti düştü ama balkanizasyon
     tetiklenmedi — çünkü kontrol yalnız `revealed` iken çalışıyordu.
     Zalim başka bir savaşta başkentini kaybettiyse Yeni Düzen yine
     çökmüş demektir; ittifak açılmasa bile zafer sayılır. */
  if (!ra.revealed){
    const z0 = G.emps[ra.target];
    const b0 = z0 && G.sys[z0.home];
    if (!z0 || z0.dead || !b0 || b0.owner === z0.id) return;
  }
  const zalim = G.emps[ra.target];
  if (!zalim || zalim.dead){ ra.done = true; return; }

  /* ═══ FAZ 39: İSYAN SÜRDÜRÜCÜ ═══
     ÖLÇÜM: 60 yıllık koşuda isyancılar zalimden 45 KAT güçlüydü
     ama "savaşan 0" çıktı — savaşlar yorgunlukla bitmiş ve kimse
     yeniden başlatmamıştı. Başkent hiç düşmedi, balkanizasyon
     tetiklenmedi. Özgürlük Savaşı bir davadır: zalim yıkılana
     kadar yeniden ilan edilir. */
  for (const id of (ra.revealed ? ra.members : [])){
    const e = G.emps[id];
    if (!e || e.dead || e.crisisSide) continue;
    if (e.war[zalim.id]) continue;
    /* Barış imzalamışsa 2 yıl bekle, sonra tekrar ayaklan */
    const barisAy = (e.peaceAt && e.peaceAt[zalim.id]) ? e.peaceAt[zalim.id] : -999;
    if (G.day - barisAy < 720) continue;
    const cb = {n:'Özgürlük Savaşı', w:1.45};
    e._lastCB = cb;
    if (typeof warAuthorize === 'function'){
      warAuthorize(e, zalim, cb);
      declareWar(e, zalim);
      if (typeof warAuthClear === 'function') warAuthClear();
    }
    e.warCause = e.warCause || {};
    e.warCause[zalim.id] = 'Özgürlük Savaşı';
  }

  const bas = G.sys[zalim.home];
  if (!bas) return;
  /* Başkent hâlâ onunsa savaş sürer */
  if (bas.owner === zalim.id) return;
  /* ═══ FAZ 39: ZAFER KOŞULU GENİŞLETİLDİ ═══
     ÖLÇÜM (tohum 99, 720 ay): başkent 47 ay SAHİPSİZ kaldı ve
     124 ay ittifak dışı birinin elindeydi — ama zafer bir kez bile
     tetiklenmedi. Eski koşul "başkenti bir ittifak üyesi almalı"
     diyordu; oysa zalimin başkentini KAYBETMESİ Yeni Düzen'in
     çökmesi için yeterlidir. Kim aldığı ikincildir. */
  const alan = bas.owner;
  if (alan === zalim.id) return;             // hâlâ onda

  /* ═══ ÖZGÜRLÜK SAVAŞI KAZANILDI ═══ */
  ra.done = true;
  ra.wonAt = G.memAge || 0;

  const eskiAd = zalim.name;
  delete zalim.guardian;                      // unvan anında düşer
  zalim.threat = Math.max(0, (zalim.threat || 0) - 60);

  /* Savaşlar biter */
  for (const id of ra.members){
    const e = G.emps[id];
    if (!e || e.dead) continue;
    if (e.war[zalim.id] && typeof makePeace === 'function') makePeace(e, zalim,'rebellion-victory',null);
    e.rel[zalim.id] = clamp((e.rel[zalim.id] || 0) + 25, -100, 100);
  }
  if (G.p && !G.p.dead && G.p.war[zalim.id] && typeof makePeace === 'function')
    makePeace(G.p, zalim,'rebellion-victory',null);

  const alanE = (alan >= 0) ? G.emps[alan] : null;
  const uyeAldi = alanE && (ra.members.indexOf(alan) >= 0 || alan === 0);
  say('⚔ ÖZGÜRLÜK SAVAŞI KAZANILDI — ' + eskiAd + ' başkenti düştü' +
      (uyeAldi ? ' (' + alanE.name + ' ele geçirdi)' : '') +
      ', Yeni Düzen yıkıldı!', 'win');

  const yeni = balkanize(zalim);
  if (typeof UI !== 'undefined' && UI.eventArt)
    UI.eventArt('veri', 'İMPARATORLUK PARÇALANDI',
      eskiAd + ' başkenti düştü ve Yeni Düzen çöktü.' +
      (yeni ? ' Kalan dünyaların yarısı ayrılarak ' + yeni.name +
              ' adıyla bağımsızlığını ilan etti.' : ''));
}

/* Kalan gezegenlerin yarısını yeni bir devlete devret */
function balkanize(zalim){
  const koloniler = (zalim.colonies || []).slice();
  if (koloniler.length < 2) return null;      // bölünecek kadar yok

  /* Ayrılacak yarı — başkent hariç, uzaktakiler önce */
  const bas = G.sys[zalim.home];
  koloniler.sort((a, b) => {
    const sa = G.sys[a.s], sb2 = G.sys[b.s];
    if (!bas || !sa || !sb2) return 0;
    return dist(sb2, bas) - dist(sa, bas);    // uzaktan yakına
  });
  const ayrilan = koloniler.slice(0, Math.floor(koloniler.length / 2));
  if (!ayrilan.length) return null;

  /* Yeni imparatorluk */
  const id = G.emps.length;
  const ad = SUCCESSOR_NAMES[Math.floor(rnd() * SUCCESSOR_NAMES.length)];
  const yeni = makeEmpire(id, zalim.race, ad, true, rnd, []);
  /* Devrik rejimin tersi bir kimlik: özgürlükçü */
  yeni.ethics = {mil: -1, aut: -2, mat: (zalim.ethics && zalim.ethics.mat) || 0};
  yeni.col = shiftColor(zalim.col);
  G.emps.push(yeni);
  recordNews({category:'politics',empires:[yeni.id],key:'empire-start:'+yeni.id,title:'Yeni devlet',text:yeni.name+' siyasi varlık kazandı',important:true});

  /* Gezegen devri */
  for (const c of ayrilan){
    const sy = G.sys[c.s];
    const pl = sy && sy.planets[c.p];
    if (!pl || !pl.col) continue;
    territoryOwnerSet(pl, yeni.id);
    yeni.colonies.push({s: c.s, p: c.p});
    /* Sistem sahipliği: o sistemde zalimin başka kolonisi yoksa devret */
    const kalanBaska = sy.planets.some(p2 =>
      p2.col && p2.owner === zalim.id);
    if (!kalanBaska) territoryOwnerSet(sy, yeni.id);
    pl.col.stab = 45;
    pl.recent_conquest = 24;
  }
  zalim.colonies = zalim.colonies.filter(c =>
    !ayrilan.some(a => a.s === c.s && a.p === c.p));
  if (yeni.colonies.length) yeni.home = yeni.colonies[0].s;

  /* Diplomatik doğuş: herkesle temas, zalimle düşman */
  for (const x of G.emps){
    if (x.dead || x.id === yeni.id) continue;
    if (x.wild || x.crisisSide) continue;
    yeni.contact[x.id] = true; x.contact[yeni.id] = true;
    yeni.rel[x.id] = 0; x.rel[yeni.id] = 0;
  }
  yeni.rel[zalim.id] = -75;
  zalim.rel[yeni.id] = -75;
  /* FAZ 40: kalıcı yeniden birleşme davası — iki taraf da
     diğerini kendi toprağı sayar. Uysal bir ardıl devlet yerine
     ebedi rakip. */
  yeni.sundered = zalim.id;
  zalim.sundered = yeni.id;
  if (typeof remember === 'function'){
    remember(yeni, zalim.id, 'sistemAldi');
    remember(zalim, yeni.id, 'sistemAldi');
  }
  /* İsyancılar yeni devleti sever */
  const ra = G.rebelAlliance;
  if (ra) for (const id2 of ra.members){
    const e = G.emps[id2];
    if (!e || e.dead) continue;
    e.rel[yeni.id] = 30; yeni.rel[e.id] = 30;
  }

  recalcMods(yeni); recalcMods(zalim);
  if (typeof refreshReach === 'function') refreshReach();
  say('🏴 ' + ad + ' bağımsızlığını ilan etti — ' + ayrilan.length +
      ' dünya ' + zalim.name + ' egemenliğinden ayrıldı', 'win');
  return yeni;
}

/* Yeni devlete ayırt edilebilir bir renk üret */
function shiftColor(hex){
  if (!hex || hex[0] !== '#') return '#8fa8c8';
  const r = parseInt(hex.substr(1,2),16), g2 = parseInt(hex.substr(3,2),16),
        b = parseInt(hex.substr(5,2),16);
  const mix = v => Math.max(40, Math.min(235, Math.round(v * .55 + 110)));
  const h = v => v.toString(16).padStart(2,'0');
  return '#' + h(mix(b)) + h(mix(r)) + h(mix(g2));   // kanalları kaydır
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 39 — OYUNCUNUN İSYANA KATILIMI
   Oyuncu otomatik katılmaz (kendi kararı). Katıldığında gücü
   ittifak toplamına eklenir ve isyan eşiğini doğrudan etkiler.
   ═══════════════════════════════════════════════════════════════════ */
function canJoinRebellion(e){
  const ra = G.rebelAlliance;
  if (!ra || ra.done) return {ok:false, why:'Ortada bir isyancı ittifakı yok'};
  const zalim = G.emps[ra.target];
  if (!zalim || zalim.dead) return {ok:false, why:'Hedef artık yok'};
  if (e.id === ra.target) return {ok:false, why:'Zalim sensin'};
  if (ra.members.indexOf(e.id) >= 0) return {ok:false, why:'Zaten üyesin'};
  if (e.ally && e.ally[zalim.id]) return {ok:false, why:'Zalimin müttefikisin'};
  if (typeof isVassal === 'function' && isVassal(e) && e.overlord === zalim.id)
    return {ok:false, why:'Zalimin vasalısın — önce bağımsızlığını kazan'};
  if ((e.rel[zalim.id] || 0) > -20)
    return {ok:false, why:'Ona yeterince düşman değilsin (ilişki −20 altı gerekir)'};
  return {ok:true};
}

function joinRebellion(e){
  const chk = canJoinRebellion(e);
  if (!chk.ok) return chk;
  const ra = G.rebelAlliance;
  ra.members.push(e.id);
  /* Diğer isyancılarla yakınlaşma */
  for (const id of ra.members){
    if (id === e.id) continue;
    const o = G.emps[id];
    if (!o || o.dead) continue;
    e.rel[id] = clamp((e.rel[id] || 0) + 25, -100, 100);
    o.rel[e.id] = clamp((o.rel[e.id] || 0) + 25, -100, 100);
  }
  /* İttifak zaten açıksa hemen savaşa gir */
  if (ra.revealed){
    const zalim = G.emps[ra.target];
    if (zalim && !e.war[zalim.id]){
      e._lastCB = {n:'Özgürlük Savaşı', w:1.45};
      if (typeof warAuthorize === 'function'){
        warAuthorize(e, zalim, e._lastCB);
        declareWar(e, zalim);
        if (typeof warAuthClear === 'function') warAuthClear();
      }
      e.warCause = e.warCause || {};
      e.warCause[zalim.id] = 'Özgürlük Savaşı';
    }
  }
  return {ok:true, revealed: ra.revealed};
}

function leaveRebellion(e){
  const ra = G.rebelAlliance;
  if (!ra || ra.done) return {ok:false, why:'İttifak yok'};
  const i = ra.members.indexOf(e.id);
  if (i < 0) return {ok:false, why:'Üye değilsin'};
  if (ra.revealed) return {ok:false, why:'Savaş başladı — artık geri dönüş yok'};
  ra.members.splice(i, 1);
  /* Diğer isyancılar bunu hoş karşılamaz */
  for (const id of ra.members){
    const o = G.emps[id];
    if (o && !o.dead) o.rel[e.id] = clamp((o.rel[e.id] || 0) - 20, -100, 100);
  }
  return {ok:true};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 42 — İSYANI KIŞKIRT
   Düşmanı içeriden bölme operasyonu. Hedefin en kırılgan SINIR
   kolonisinde istikrarı çökertir ve ayrılıkçı sayacı ateşler.
   Faz 41'de kurduğum secessionTick altyapısını kullanır.
   ═══════════════════════════════════════════════════════════════════ */
const INCITE_COST = 120;
const INCITE_STAB_HIT = 25;       // istikrar düşüşü
const INCITE_MONTHS = 12;         // etki süresi
const INCITE_SEED = 10;           // sayaca eklenen ay

/* Kışkırtılabilecek en zayıf sınır kolonisi. Arayüz de bunu okur. */
function incitablePlanet(e, target){
  if (!target || target.dead) return null;
  let en = null, enSkor = -1;
  for (const c of (target.colonies || [])){
    const sys = G.sys[c.s];
    const pl = sys && sys.planets[c.p];
    if (!pl || !pl.col) continue;
    /* Başkent kışkırtılamaz — merkez sadıktır */
    if (target.home === sys.id) continue;
    if (pl.martial_law > 0) continue;           // sıkıyönetim engelliyor
    /* SINIR mı? Komşusunda yabancı olmalı */
    let sinir = false;
    for (const l of sys.lanes){
      const o2 = G.sys[l];
      if (o2 && o2.owner >= 0 && o2.owner !== target.id){ sinir = true; break; }
    }
    if (!sinir) continue;
    /* En düşük istikrarlı olan en kırılgandır */
    const skor = 100 - (pl.col.stab || 0) + (pl.col.secede || 0) * 2;
    if (skor > enSkor){ enSkor = skor; en = {sys, pl}; }
  }
  return en;
}

function canIncite(e, target){
  const gate = spyTargetCheck(e, target);
  if (!gate.ok) return gate;
  if (target.dead || target.wild || target.crisisSide)
    return {ok:false, why:'Bu devletle casusluk yapılamaz'};
  const lvl = (typeof intelOf === 'function') ? intelOf(e, target.id) : 0;
  if (lvl < 2) return {ok:false, why:'En az 2. seviye istihbarat gerekir'};
  if ((e.res.etk || 0) < INCITE_COST)
    return {ok:false, why:INCITE_COST + ' etki gerekir'};
  const hedef = incitablePlanet(e, target);
  if (!hedef) return {ok:false, why:'Kışkırtılabilecek sınır dünyası yok'};
  return {ok:true, hedef};
}

function inciteRebellion(e, target){
  const chk = canIncite(e, target);
  if (!chk.ok) return chk;
  e.res.etk -= INCITE_COST;

  const {sys, pl} = chk.hedef;
  const ch = (typeof sabotageChance === 'function')
    ? sabotageChance(e, target) : {basari:.4, ifsa:.3};
  /* Halk ayaklandırmak sabotajdan zor: yerel destek gerekir */
  const basari = clamp(ch.basari * .88, .05, .70);
  const ifsa   = clamp(ch.ifsa * 1.20, .06, .65);

  if (rnd() < basari){
    /* ── BAŞARI ── */
    const col = pl.col;
    col.unrest = {left: INCITE_MONTHS, hit: INCITE_STAB_HIT, by: e.id};
    col.stab = clamp(col.stab - INCITE_STAB_HIT, 0, 100);
    /* FAZ 43: tavan — üst üste kışkırtma sayacı şişirmesin
       (ölçümde 130/30 görüldü). */
    const tavan = (typeof SECESSION_LIMIT !== 'undefined') ? SECESSION_LIMIT + 4 : 34;
    col.secede = Math.min(tavan, (col.secede || 0) + INCITE_SEED);
    if (typeof recordSabotage === 'function') recordSabotage('kiskirt');
    const ad = col.name || pl.name;
    const result = finishSpecialOp(e, target, 'incite',
      {ok:true, caught:false, koloni:ad, basarili:true,
        msg:ad + ' halkı ayaklandı — istikrar çöktü, ayrılıkçı sayaç ' + col.secede},
      INCITE_COST, {sys:sys.id, pi:pl.i});
    if (e.id === 0)
      specialOpNotify('🔥 İSYAN KIŞKIRTILDI — ' + ad + ' halkı ayaklandı · istikrar −' +
          INCITE_STAB_HIT + ', ayrılıkçı sayaç ' + col.secede, 'sci');
    else if (target.id === 0)
      specialOpNotify('🔥 AYAKLANMA — ' + ad + ' halkı sokağa döküldü. Dış bir el var.', 'war');
    /* FAZ 42: alan adı `koloni` — arayüz ve testler bunu okuyor
       (kısa `ad` adı çağıran tarafta karışıklık yaratıyordu). */
    return result;
  }

  if (rnd() < ifsa){
    /* ── İFŞA ── */
    if (typeof remember === 'function') remember(target, e.id, 'sabotaj');
    target.rel[e.id] = clamp(target.rel[e.id] - 45, -100, 100);
    target._lastCB = {n:'İç İşlerine Müdahale', w:1.30};
    /* Konsey bunu ağır bulur */
    e.threat = (e.threat || 0) + 15;
    for (const x of G.emps){
      if (x.dead || x.wild || x.crisisSide || x.id === e.id || x.id === target.id) continue;
      x.rel[e.id] = clamp((x.rel[e.id] || 0) - 15, -100, 100);
    }
    if (typeof recordSabotage === 'function') recordSabotage('ifsa');
    const result = finishSpecialOp(e, target, 'incite', {ok:true, caught:true,
      msg: 'Ajan infaz edildi — ' + target.name +
           ' iç işlerine müdahaleyi ifşa etti. Konseyde itibarın sarsıldı.'},
      INCITE_COST, {sys:sys.id, pi:pl.i});
    if (target.id === 0)
      specialOpNotify('KIŞKIRTMA GİRİŞİMİ YAKALANDI — ' + e.name + ' iç işlerimize müdahale etmeye çalıştı.', 'win');
    return result;
  }

  if (typeof recordSabotage === 'function') recordSabotage('sessiz');
  return finishSpecialOp(e, target, 'incite',
    {ok:true, caught:false, msg:'Halk kıpırdamadı — kışkırtma tutmadı'}, INCITE_COST);
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 44 — HİMAYE TEKLİFİ (KUKLA DEVLET VASALLIĞI)
   Kışkırtmayla doğan ve minnet bağı olan devlete hami doğrudan
   vasallık teklif edebilir. +80 ilişki ve 'yardimEtti' anısı
   sayesinde kabul olasılığı yüksek — ama garanti değil:
   agresif doğan ayrılıkçılar bağımsızlığa da düşkün.
   ═══════════════════════════════════════════════════════════════════ */
const PATRONAGE_COST = 150;

function canOfferPatronage(e, target){
  if (!e || !target || target.dead) return {ok:false, why:'Hedef yok'};
  if (target.id === e.id) return {ok:false, why:'Kendine teklif edemezsin'};
  if (target.wild || target.crisisSide) return {ok:false, why:'Bu taraf müzakere etmez'};
  if (target.founder !== e.id)
    return {ok:false, why:'Bu devlet senin desteğinle doğmadı'};
  if (typeof isVassal === 'function' && isVassal(target))
    return {ok:false, why:'Zaten bir senyöre bağlı'};
  if (e.war[target.id]) return {ok:false, why:'Onunla savaştasın'};
  if ((e.res.etk || 0) < PATRONAGE_COST)
    return {ok:false, why:PATRONAGE_COST + ' etki gerekir'};
  if (target._patronageCd && target._patronageCd > (G.memAge || 0))
    return {ok:false, why:'Yakın zamanda reddettiler — biraz bekle'};
  return {ok:true};
}

/* Kabul olasılığı — arayüz de bunu gösterir */
function patronageChance(e, target){
  let p = .30;
  p += clamp((target.rel[e.id] || 0) / 160, -.4, .55);      // minnet ağır basar
  /* Güç farkı: zayıf devlet korunmaya muhtaç */
  const oran = totalPower(e) / Math.max(1, totalPower(target));
  p += clamp((oran - 1) * .12, -.15, .30);
  /* Tehdit altındaysa himaye cazip */
  let dusman = 0;
  for (const o of G.emps){
    if (o.dead || o.wild || o.crisisSide || o.id === target.id) continue;
    if (target.war[o.id]) dusman++;
  }
  p += Math.min(.25, dusman * .12);
  /* Ayrılıkçı gururu: yeni kazanılan bağımsızlık kolay bırakılmaz */
  const yas = (G.memAge || 0) - (target._bornAt || 0);
  if (yas < 36) p -= .20;
  const P = (typeof personaOf === 'function') ? personaOf(target) : null;
  if (P){
    if (P.n === 'İzolasyonist') p -= .25;
    else if (P.n === 'Militarist') p -= .15;
    else if (P.n === 'Tüccar') p += .10;
  }
  return clamp(p, .05, .92);
}

function offerPatronage(e, target){
  const chk = canOfferPatronage(e, target);
  if (!chk.ok) return chk;
  e.res.etk -= PATRONAGE_COST;
  const sans = patronageChance(e, target);

  if (rnd() < sans){
    if (typeof subjugate === 'function') subjugate(e, target, 'haracguzar');
    else { target.overlord = e.id; target.vassalType = 'haracguzar'; }
    target.rel[e.id] = clamp((target.rel[e.id] || 0) + 10, -100, 100);
    if (typeof remember === 'function') remember(target, e.id, 'yardimEtti');
    if (e.id === 0)
      say('🤝 HİMAYE KABUL EDİLDİ — ' + target.name + ' vasalın oldu', 'win');
    return {ok:true, kabul:true,
      msg: target.name + ' himayeni kabul etti ve vasalın oldu'};
  }

  /* Ret: gurur kırılmaz ama ilişki hafif sarsılır */
  target._patronageCd = (G.memAge || 0) + 36;
  target.rel[e.id] = clamp((target.rel[e.id] || 0) - 8, -100, 100);
  return {ok:true, kabul:false,
    msg: target.name + ' bağımsızlığını korumayı seçti — teklifin reddedildi'};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 48 — STATÜKO BARIŞI (UTI POSSIDETIS)
   "Elinde ne varsa senindir." Yorgunluk tavana vurduğunda ya da
   savaş çok uzadığında taraflar fiili durumu tanıyıp sınırları
   dondurur. İşgal edilmiş sistemler işgalcinin toprağı olur.
   ═══════════════════════════════════════════════════════════════════ */
const STATUS_QUO_EXH = 85;        // bu yorgunluktan sonra masaya gelinir
const STATUS_QUO_MONTHS = 96;     // ya da 8 yıl sürmüşse

function canStatusQuo(a, b){
  if (!a || !b || a.dead || b.dead) return {ok:false, why:'Taraf yok'};
  if (!a.war[b.id]) return {ok:false, why:'Savaşta değilsiniz'};
  const exhA = (a.exh && a.exh[b.id]) || 0;
  const exhB = (b.exh && b.exh[a.id]) || 0;
  const bas = (a.warSince && a.warSince[b.id]) !== undefined
    ? a.warSince[b.id] : null;
  const ay = bas !== null ? Math.floor((G.day - bas) / 30) : 0;
  if (exhA < STATUS_QUO_EXH && exhB < STATUS_QUO_EXH && ay < STATUS_QUO_MONTHS)
    return {ok:false, why:'Henüz iki taraf da yeterince yorulmadı (' +
      Math.round(Math.max(exhA, exhB)) + '/' + STATUS_QUO_EXH + ')'};
  return {ok:true, exhA, exhB, ay};
}

/* Fiili işgal haritası: her sistemin GERÇEK sahibi kim?
   Bir sistem, orada koloni sahibi olan devletindir; koloni yoksa
   yörüngeyi tutan devletindir. */
function occupationMap(a, b){
  const sonuc = [];
  for (const sy of G.sys){
    /* Yalnız iki tarafın da ilgilendiği sistemler */
    let kolA = false, kolB = false;
    for (const pl of sy.planets){
      if (!pl.col) continue;
      if (pl.owner === a.id) kolA = true;
      if (pl.owner === b.id) kolB = true;
    }
    if (!kolA && !kolB && sy.owner !== a.id && sy.owner !== b.id) continue;
    /* Gerçek hâkim: koloni sahibi öncelikli */
    let gercek = -1;
    if (kolA && !kolB) gercek = a.id;
    else if (kolB && !kolA) gercek = b.id;
    else if (kolA && kolB) gercek = sy.owner;      // karışık: mevcut kalır
    else gercek = sy.owner;
    /* ═══ FAZ 48 DÜZELTMESİ: FİİLİ YÖRÜNGE HAKİMİYETİ ═══
       ÖLÇÜM: kolonisiz bir sistemi filoyla tutan taraf statükoda
       hiç toprak kazanmıyordu — kod yalnız `sy.orbitHeld`
       damgasına bakıyordu, o da her savaşta düşmüyor. Artık
       yörüngedeki SİLAHLI FİLO doğrudan sayılıyor: kim orada
       duruyorsa fiili hâkim odur (uti possidetis'in özü). */
    if (!kolA && !kolB){
      let fA = 0, fB = 0;
      for (const f of G.fleets){
        if (!f.ships || !f.ships.length || f.sys !== sy.id) continue;
        if (typeof isArmed === 'function' && !isArmed(f)) continue;
        if (f.e === a.id) fA += fleetPower(f);
        else if (f.e === b.id) fB += fleetPower(f);
      }
      if (fA > fB && fA > 0) gercek = a.id;
      else if (fB > fA && fB > 0) gercek = b.id;
      else if (sy.orbitHeld !== undefined) gercek = sy.orbitHeld;
    }
    if (gercek >= 0 && gercek !== sy.owner) sonuc.push({sys:sy, yeni:gercek});
  }
  return sonuc;
}

function statusQuoPeace(a, b){
  const chk = canStatusQuo(a, b);
  if (!chk.ok) return chk;

  /* Sınırları fiili duruma göre dondur */
  const devir = occupationMap(a, b);
  let n = 0;
  for (const d of devir){
    if (d.yeni !== a.id && d.yeni !== b.id) continue;
    if(d.sys.owner!==d.yeni)d.sys.shareRev=(d.sys.shareRev||0)+1;
    territoryOwnerSet(d.sys, d.yeni);
    n++;
  }

  /* Barışı imzala — normal makePeace tüm bağları temizler */
  a.war[b.id] = false; b.war[a.id] = false;
  a.peaceAt = a.peaceAt || {}; b.peaceAt = b.peaceAt || {};
  a.peaceAt[b.id] = G.day; b.peaceAt[a.id] = G.day;
  if (a.exh) a.exh[b.id] = Math.max(0, (a.exh[b.id] || 0) - 40);
  if (b.exh) b.exh[a.id] = Math.max(0, (b.exh[a.id] || 0) - 40);
  /* Statüko onurlu bir sondur — kin azalır */
  a.rel[b.id] = clamp((a.rel[b.id] || 0) + 18, -100, 100);
  b.rel[a.id] = clamp((b.rel[a.id] || 0) + 18, -100, 100);
  if (typeof remember === 'function'){
    remember(a, b.id, 'barisImzaladi');
    remember(b, a.id, 'barisImzaladi');
  }
  if (typeof refreshReach === 'function') refreshReach();
  G.emps.forEach(x => { if (!x.dead) recalcMods(x); });

  const mesaj = 'STATÜKO BARIŞI — ' + a.name + ' ve ' + b.name +
    ' fiili sınırları tanıdı' + (n ? ' (' + n + ' sistem el değiştirdi)' : '');
  if (a.id === 0 || b.id === 0) say('🕊 ' + mesaj, 'win');
  else say(mesaj);
  warLedgerSync('status-quo',a.id);
  recordNews({category:'peace',empires:[a.id,b.id],key:'status-quo:'+a.id+':'+b.id+':'+G.day,title:'Statüko barışı',text:a.name+' ile '+b.name+' fiili sınırları tanıdı',important:true});
  return {ok:true, devredilen:n};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 48 — İSTİHBARAT PAYLAŞIMI PAKTI
   ═══════════════════════════════════════════════════════════════════ */
const SHAREVIS_COST = 60;

function canShareVision(e, o){
  if (!e || !o || o.dead) return {ok:false, why:'Hedef yok'};
  if (o.id === e.id) return {ok:false, why:'Kendinle paylaşamazsın'};
  if (o.wild || o.crisisSide) return {ok:false, why:'Bu taraf müzakere etmez'};
  if (!e.contact[o.id]) return {ok:false, why:'Temasın yok'};
  if (e.war[o.id]) return {ok:false, why:'Savaştasınız'};
  if (e.shareVis && e.shareVis[o.id]) return {ok:false, why:'Zaten paylaşımdasınız'};
  if ((e.res.etk || 0) < SHAREVIS_COST)
    return {ok:false, why:SHAREVIS_COST + ' etki gerekir'};
  /* Güven şartı: kimse haritasını yabancıya açmaz */
  const t = (typeof trustOf === 'function') ? trustOf(o, e.id) : 0;
  const rel = o.rel[e.id] || 0;
  if (rel < 20 && t < 15)
    return {ok:false, why:'Yeterince güvenmiyorlar (ilişki ' + Math.round(rel) + ')'};
  return {ok:true};
}

function offerShareVision(e, o){
  const chk = canShareVision(e, o);
  if (!chk.ok) return chk;
  e.res.etk -= SHAREVIS_COST;
  /* Kabul: ilişki + güven + dürüstlük */
  let p = .35 + clamp((o.rel[e.id] || 0) / 120, -.3, .45);
  if (e.mods) p += (e.mods.trustCap || 0) / 100;      // DÜRÜST bonusu
  if (o.ally && o.ally[e.id]) p += .30;
  const P = (typeof personaOf === 'function') ? personaOf(o) : null;
  if (P && P.n === 'İzolasyonist') p -= .30;
  if (rnd() < clamp(p, .05, .95)){
    e.shareVis = e.shareVis || {}; o.shareVis = o.shareVis || {};
    e.shareVis[o.id] = true; o.shareVis[e.id] = true;
    if(e===G.p||o===G.p)refreshSharedVision();
    if (typeof remember === 'function') remember(o, e.id, 'yardimEtti');
    return {ok:true, kabul:true, msg: o.name + ' istihbarat paylaşımını kabul etti'};
  }
  return {ok:true, kabul:false, msg: o.name + ' haritasını paylaşmayı reddetti'};
}

function endShareVision(e, o){
  if (e.shareVis) delete e.shareVis[o.id];
  if (o.shareVis) delete o.shareVis[e.id];
  o.rel[e.id] = clamp((o.rel[e.id] || 0) - 8, -100, 100);
  return {ok:true};
}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 48 — FEDERASYON ÜYELİK OYLAMASI
   Kabul artık otomatik değil: mevcut üyeler oy verir.
   ═══════════════════════════════════════════════════════════════════ */
function fedMemberVote(fed,aday){
 const evet=[],hayir=[];for(const id of fed.members){const e=G.emps[id];if(!e||e.dead||id===0)continue;
  (aiFedAdmissionScore(e,aday,fed.type).ok?evet:hayir).push(id);}
 return {evet,hayir,gecti:evet.length>fed.members.length/2};
}
function fedInvite(fed,aday){
 const member=G.p&&fed?.members.includes(G.p.id)?G.p:G.emps[fed?.leader];
 return member&&aday&&fedOf(fed.id)===fed?proposeFedMotion(member,'admit',{target:aday.id}):{ok:false,why:'Geçerli federasyon ve aday gerekli'};
}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 48 — OYUNCU KONSEY TASARISI
   120 etki ile gündeme doğrudan yasa sokma. Reddedilirse prestij
   ve diplomatik ağırlık bedeli var.
   ═══════════════════════════════════════════════════════════════════ */
const BILL_COST = 120;

function canProposeBill(e){
  if (!councilExists()) return {ok:false, why:'Galaktik Konsey kurulmamış'};
  const c = G.council;
  if (!c.members.includes(e.id)) return {ok:false, why:'Konsey üyesi değilsin'};
  if (c.vote) return {ok:false, why:'Halihazırda bir oylama sürüyor'};
  if (c.campaign) return {ok:false, why:'Kampanya dönemi sürüyor'};
  if ((e.res.etk || 0) < BILL_COST)
    return {ok:false, why:BILL_COST + ' etki gerekir'};
  if (e._billCd && e._billCd > (G.memAge || 0))
    return {ok:false, why:'Yakında tasarı sundun — ' +
      (e._billCd - (G.memAge || 0)) + ' ay bekle'};
  return {ok:true};
}

function proposeBill(e, key, targetId){
  const chk = canProposeBill(e);
  if (!chk.ok) return chk;
  const R = RESOLUTIONS[key];
  if (!R) return {ok:false, why:'Bilinmeyen tasarı'};
  if (R.hedefli && (targetId === undefined || targetId === null))
    return {ok:false, why:'Bu tasarı bir hedef gerektirir'};

  e.res.etk -= BILL_COST;
  e._billCd = (G.memAge || 0) + 36;
  e._billPending = {key, target: targetId};

  const c = G.council;
  c.campaign = {key, sponsor: e.id, left: (typeof CAMPAIGN_MONTHS !== 'undefined'
    ? CAMPAIGN_MONTHS : 3), bribed:{}, blackmailed:[], agenda:null,
    target: targetId, byPlayer: e.id === 0};
  if (targetId !== undefined && targetId !== null) c.campaign.hedefId = targetId;
  say('📜 TASARI SUNULDU — ' + R.ico + ' ' + R.n +
      ' · ' + c.campaign.left + ' ay kampanya', 'sci');
  return {ok:true};
}

/* Tasarı reddedilirse sunan bedel öder — finishCouncilVote çağırır */
function billRejected(e, key){
  if (!e) return;
  e.prestige = Math.max(0, (e.prestige || 0) - 10);
  e._billFail = (e._billFail || 0) + 1;
  /* Diplomatik ağırlık cezası: 5 yıl sürer */
  e._billPenalty = (G.memAge || 0) + 60;
  for (const x of G.emps){
    if (x.dead || x.wild || x.crisisSide || x.id === e.id) continue;
    x.rel[e.id] = clamp((x.rel[e.id] || 0) - 5, -100, 100);
  }
  if (e.id === 0)
    say('📜 Tasarın reddedildi — konseydeki ağırlığın 5 yıl boyunca azaldı', 'war');
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 48 — PAYLAŞILAN GÖRÜŞ
   İstihbarat paylaşımı paktı olan devletin keşfettiği sistemler
   ve gördüğü alan alıcının haritasına kopyalanır. Tek geçiş,
   ayda bir çalışır.
   ═══════════════════════════════════════════════════════════════════ */
function shareVision(giver, taker){
  if (!giver || !taker || giver.dead || taker.dead || giver.war?.[taker.id] || taker.war?.[giver.id]) return 0;
  const live=nativeSensorVision(giver);
  let yeni = 0;
  for (const sy of G.sys){
    if ((sy.seen.includes(giver.id)||live.has(sy.id)) && !sy.seen.includes(taker.id)){
      sy.seen.push(taker.id);yeni++;
    }
  }
  if(taker===G.p)refreshSharedVision();
  return yeni;
}

function visionTick(){
  for(const sub of G.emps){const c=vassalContractOf(sub);if(c?.terms.sensors){const lord=overlordOf(sub);shareVision(lord,sub);shareVision(sub,lord);}}
  for (const e of G.emps){
    if (e.dead || e.wild || e.crisisSide || !e.visionFrom) continue;
    for (const gid in e.visionFrom){
      const g = G.emps[gid];
      if (!g || g.dead){ delete e.visionFrom[gid]; continue; }
      /* Savaş çıkarsa paylaşım biter — kimse düşmanına göz vermez */
      if (!e.visionFrom[gid] || e.war[g.id] || g.war[e.id]){ delete e.visionFrom[gid]; continue; }
      shareVision(g, e);
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 49 — PANOPTİKON KARŞI İSTİHBARATI
   Gözlendiğini fark eden devlet iki yolla karşılık verir:
     SENSÖR KÖRLEME  → 24 ay karanlık, ucuz, düşük risk
     AŞIRI YÜKLEME   → yapıya kalıcı hasar, pahalı, yüksek risk
   ═══════════════════════════════════════════════════════════════════ */
const BLIND_COST = 80;
const OVERLOAD_COST = 140;
const BLIND_MONTHS = 24;

function panopticonTargets(e){
  if (!e || !e.panoptSeen) return [];
  const out = [];
  for (const oid in e.panoptSeen){
    const o = G.emps[oid];
    if (!o || o.dead) continue;
    const kayit = e.panoptSeen[oid];
    const kilit = o.panoptLock && o.panoptLock[kayit.sys];
    if (!kilit) continue;                       // yapı yıkılmış
    out.push({emp:o, sys:kayit.sys, kilit});
  }
  return out;
}

function canCounterPanopt(e, o, tur){
  if (!e || !o || o.dead) return {ok:false, why:'Hedef yok'};
  const lvl = (typeof intelOf === 'function') ? intelOf(e, o.id) : 0;
  if (lvl < 2) return {ok:false, why:'2. seviye istihbarat gerekir'};
  const hedefler = panopticonTargets(e).filter(x => x.emp.id === o.id);
  if (!hedefler.length) return {ok:false, why:'Tespit edilmiş bir Panoptikon yok'};
  const bedel = tur === 'overload' ? OVERLOAD_COST : BLIND_COST;
  if ((e.res.etk || 0) < bedel) return {ok:false, why:bedel + ' etki gerekir'};
  return {ok:true, hedef: hedefler[0]};
}

function counterPanopticon(e, o, tur){
  const chk = canCounterPanopt(e, o, tur);
  if (!chk.ok) return chk;
  const bedel = tur === 'overload' ? OVERLOAD_COST : BLIND_COST;
  e.res.etk -= bedel;

  const ch = (typeof sabotageChance === 'function')
    ? sabotageChance(e, o) : {basari:.4, ifsa:.3};
  /* Aşırı yükleme daha zor ve daha riskli */
  const basari = tur === 'overload'
    ? clamp(ch.basari * .70, .05, .60) : clamp(ch.basari * .95, .08, .80);
  const ifsa = tur === 'overload'
    ? clamp(ch.ifsa * 1.35, .06, .60) : clamp(ch.ifsa * .85, .04, .45);

  const kilit = chk.hedef.kilit;
  if (rnd() < basari){
    if (tur === 'overload'){
      kilit.hp = Math.max(0, (kilit.hp || 100) - 60);
      if (kilit.hp <= 0){
        /* Yapı çöktü: kilit tamamen silinir */
        delete o.panoptLock[chk.hedef.sys];
        const sy = G.sys[chk.hedef.sys];
        if (sy && sy.built) delete sy.built.panopt;
        if (e.id === 0)
          say('💥 PANOPTİKON ÇÖKTÜ — ' + o.name + ' gözlem istasyonunu kaybetti', 'win');
        else if (o.id === 0)
          say('💥 PANOPTİKONUMUZ AŞIRI YÜKLENDİ VE ÇÖKTÜ', 'war');
      } else if (e.id === 0)
        say('⚡ İstasyon hasar aldı (kalan bütünlük %' + kilit.hp + ')', 'sci');
    } else {
      kilit.blindUntil = (G.memAge || 0) + BLIND_MONTHS;
      if (e.id === 0)
        say('🌑 SENSÖRLER KÖRLENDİ — ' + o.name + ' ' + BLIND_MONTHS +
            ' ay boyunca bizi göremeyecek', 'win');
      else if (o.id === 0)
        say('🌑 Panoptikon sensörlerimiz körlendi — ' + BLIND_MONTHS + ' ay karanlık', 'war');
    }
    if (typeof recordSabotage === 'function') recordSabotage('basari');
    return {ok:true, caught:false,
      msg: tur === 'overload' ? 'İstasyon aşırı yüklendi' : 'Sensörler körlendi'};
  }

  if (rnd() < ifsa){
    if (typeof remember === 'function') remember(o, e.id, 'sabotaj');
    o.rel[e.id] = clamp((o.rel[e.id] || 0) - 40, -100, 100);
    o._lastCB = {n:'Sensör Sabotajı', w:1.20};
    if (typeof recordSabotage === 'function') recordSabotage('ifsa');
    return {ok:true, caught:true,
      msg: 'AJANIMIZ YAKALANDI — ' + o.name + ' sabotajı ifşa etti'};
  }
  if (typeof recordSabotage === 'function') recordSabotage('sessiz');
  return {ok:true, caught:false, msg:'Operasyon sonuçsuz kaldı'};
}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 49 — FEDERAL DONANMA
   Üyelerin alaşım gelirinden %5 ortak fona akar. Başkan bu fonla
   filo kapasitesi HARCAMADAN gemi basar; bakım da fondan çıkar.
   Liderlik el değiştirince donanma yeni başkana geçer.
   ═══════════════════════════════════════════════════════════════════ */
const FED_TITHE = .05;

function fedFundTick(){
  if (typeof G.feds === 'undefined' || !G.feds) return;
  for (const f of G.feds){
    if (!f || f.dead || !f.members || !f.members.length) continue;
    f.fund = f.fund || {ala:0, ene:0};

    /* ── ÖŞÜR ── */
    for (const id of f.members){
      const e = G.emps[id];
      if (!e || e.dead) continue;
      const rate = f.laws && f.laws.ortakDon ? .09 : f.laws && f.laws.sivilFon ? .03 : fedType(f).tithe;
      const ala = Math.max(0, ((e.inc && e.inc.ala) || 0) * rate);
      const ene = Math.max(0, ((e.inc && e.inc.ene) || 0) * rate);
      if (ala > 0 && (e.res.ala || 0) >= ala){ e.res.ala -= ala; f.fund.ala += ala; }
      if (ene > 0 && (e.res.ene || 0) >= ene){ e.res.ene -= ene; f.fund.ene += ene; }
    }

    /* ── FEDERAL FİLO KOMUTASI ──
       Başkan değiştiyse donanma yeni başkana geçer. */
    const baskan = G.emps[f.leader];
    if (baskan && !baskan.dead){
      for (const fl of G.fleets){
        if (!fl.federal || fl.fedId !== f.id) continue;
        if (fl.e !== f.leader){
          fl.e = f.leader;
          if (f.leader === 0)
            say('🏛 Federal donanma komutası sana geçti', 'sci');
        }
      }
    }

    /* ── BAKIM FONDAN ── */
    let bakim = 0;
    for (const fl of G.fleets){
      if (!fl.federal || fl.fedId !== f.id || !fl.ships) continue;
      for (const sh of fl.ships)
        bakim += (SHIPS[sh.c] && SHIPS[sh.c].up) || 0;
    }
    if (bakim > 0){
      /* ═══ FAZ 50: FON TÜKENME UYARISI ═══
         Rezerv 3 aylık bakımın altına düşünce başkana kırmızı
         uyarı. Sessizce filo dağıtmak yerine önceden haber ver. */
      const kalanAy = bakim > 0 ? Math.floor(f.fund.ene / bakim) : 99;
      if (kalanAy <= 3 && f.leader === 0 && f._uyariAt !== (G.memAge || 0)){
        f._uyariAt = G.memAge || 0;
        say('⚠ FEDERAL FON TÜKENİYOR — gemiler ' + Math.max(0, kalanAy) +
            ' ay içinde dağıtılacak! Acil hibe gönder.', 'war');
      }
      f.fund.ene -= bakim;
      if (f.fund.ene < 0){
        /* Fon tükendi: en zayıf federal filo dağıtılır */
        f.fund.ene = 0;
        let en = null;
        for (const fl of G.fleets){
          if (!fl.federal || fl.fedId !== f.id || !fl.ships.length) continue;
          if (!en || fl.ships.length < en.ships.length) en = fl;
        }
        if (en){
          en.ships.length = 0;
          if (f.leader === 0) say('⚠ Federal fon tükendi — bir donanma dağıtıldı', 'war');
        }
        G.fleets = G.fleets.filter(x => x.ships && x.ships.length);
      }
    }
  }
}

function canBuildFederal(e, cls){
  const access = shipBuildAccess(e, cls);
  if (!access.ok) return access;
  const f = (typeof findFed === 'function') ? findFed(e) : null;
  if (!f) return {ok:false, why:'Bir federasyona üye değilsin'};
  if (f.leader !== e.id) return {ok:false, why:'Yalnız federasyon başkanı basabilir'};
  const S = SHIPS[cls];
  if (!S) return {ok:false, why:'Bilinmeyen gemi'};
  f.fund = f.fund || {ala:0, ene:0};
  const bedel = (S.cost && S.cost.ala) ? S.cost.ala * 1.15 : 100;
  if (f.fund.ala < bedel)
    return {ok:false, why:'Federal fon yetersiz (' + Math.round(f.fund.ala) +
      '/' + Math.round(bedel) + ' alaşım)'};
  return {ok:true, fed:f, bedel};
}

function buildFederalShip(e, sysId, cls){
  const chk = canBuildFederal(e, cls);
  if (!chk.ok) return chk;
  const sy = G.sys[sysId];
  if (!sy) return {ok:false, why:'Sistem yok'};
  chk.fed.fund.ala -= chk.bedel;
  const fl = newFleet(e, sysId, [{c:cls}], 'Federal Donanma');
  fl.federal = true;
  fl.fedId = chk.fed.id;
  if (e.id === 0)
    say('🏛 Federal donanmaya ' + SHIPS[cls].n + ' katıldı (kapasite harcanmadı)', 'sci');
  return {ok:true};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 50 — ACİL HİBE
   Başkan şahsi kasasından federal fona tek tıkla aktarım yapar.
   ═══════════════════════════════════════════════════════════════════ */
const GRANT_ALA = 500, GRANT_ENE = 1000;

function canGrantFed(e){
  const f = (typeof findFed === 'function') ? findFed(e) : null;
  if (!f) return {ok:false, why:'Bir federasyona üye değilsin'};
  if (f.leader !== e.id) return {ok:false, why:'Yalnız başkan hibe gönderebilir'};
  if ((e.res.ala || 0) < GRANT_ALA || (e.res.ene || 0) < GRANT_ENE)
    return {ok:false, why:GRANT_ALA + ' alaşım ve ' + GRANT_ENE + ' enerji gerekir'};
  return {ok:true, fed:f};
}

function grantFed(e){
  const chk = canGrantFed(e);
  if (!chk.ok) return chk;
  const f = chk.fed;
  f.fund = f.fund || {ala:0, ene:0};
  e.res.ala -= GRANT_ALA; e.res.ene -= GRANT_ENE;
  f.fund.ala += GRANT_ALA; f.fund.ene += GRANT_ENE;
  if (e.id === 0)
    say('🏛 ACİL HİBE — federal fona ' + GRANT_ALA + ' alaşım, ' +
        GRANT_ENE + ' enerji aktarıldı', 'win');
  return {ok:true};
}

/* Fon durumu — arayüz okur */
function fedFundStatus(f){
  if (!f) return null;
  f.fund = f.fund || {ala:0, ene:0};
  let bakim = 0;
  for (const fl of G.fleets){
    if (!fl.federal || fl.fedId !== f.id || !fl.ships) continue;
    for (const sh of fl.ships) bakim += (SHIPS[sh.c] && SHIPS[sh.c].up) || 0;
  }
  const kalanAy = bakim > 0 ? Math.floor(f.fund.ene / bakim) : 99;
  return {bakim, kalanAy, kritik: bakim > 0 && kalanAy <= 3,
          ala: f.fund.ala, ene: f.fund.ene};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 51 — DAİMİ KONSEY HÜKÜMDARLIĞI
   Başkan 200 etki harcayarak seçimleri kaldırma tasarısı sunar.
   Geçerse taht kalıcı olur ve Diplomatik Hegemonya zaferinin
   ön şartı tamamlanır. Reddedilirse ağır bedel: galaksi bir
   diktatör adayını unutmaz.
   ═══════════════════════════════════════════════════════════════════ */
const PRESIDENT_TERM = 180;        // 15 yıl
const PERMANENT_COST = 200;

function canClaimPermanent(e){
  if (typeof councilExists !== 'function' || !councilExists())
    return {ok:false, why:'Galaktik Konsey kurulmamış'};
  const c = G.council;
  if (c.permanent !== undefined && c.permanent !== null)
    return {ok:false, why:'Daimi hükümdarlık zaten ilan edilmiş'};
  if (c.president !== e.id)
    return {ok:false, why:'Yalnız dönem başkanı sunabilir'};
  if (c.vote || c.campaign)
    return {ok:false, why:'Halihazırda bir oylama sürüyor'};
  if ((e.res.etk || 0) < PERMANENT_COST)
    return {ok:false, why:PERMANENT_COST + ' etki gerekir'};
  /* En az bir tam dönem başkanlık yapmış olmalı */
  if (((c.terms && c.terms[e.id]) || 0) < 1)
    return {ok:false, why:'Önce bir tam dönem başkanlık yapmalısın'};
  return {ok:true};
}

function claimPermanent(e){
  const chk = canClaimPermanent(e);
  if (!chk.ok) return chk;
  const c = G.council;
  e.res.etk -= PERMANENT_COST;

  /* Oylama: her üye kendi çıkarına bakar */
  let evet = 0, hayir = 0;
  for (const m of c.members){
    const o = G.emps[m];
    if (!o || o.dead) continue;
    const w = voteWeight(o);
    if (m === e.id){ evet += w; continue; }
    let want = .12;                                    // taban: kimse taht istemez
    want += clamp((o.rel[e.id] || 0) / 190, -.35, .40);
    if (typeof isVassal === 'function' && isVassal(o) && o.overlord === e.id) want += .55;
    if (o.ally && o.ally[e.id]) want += .25;
    if (o.war[e.id]) want -= .45;
    const P = (typeof personaOf === 'function') ? personaOf(o) : null;
    if (P){
      if (P.n === 'İzolasyonist') want -= .20;
      else if (P.n === 'Pasifist') want -= .15;
    }
    /* Otoriter devletler tahta daha sıcak bakar */
    if ((o.ethics && (o.ethics.aut || 0)) > 0) want += .18;
    else if ((o.ethics && (o.ethics.aut || 0)) < 0) want -= .22;
    if (rnd() < clamp(want, .03, .92)) evet += w; else hayir += w;
  }

  if (evet > hayir){
    c.permanent = e.id;
    c.president = e.id;
    c.termAge = 0;
    for (const x of G.emps){
      if (x.dead || x.wild || x.crisisSide || x.id === e.id) continue;
      x.rel[e.id] = clamp((x.rel[e.id] || 0) - 12, -100, 100);
    }
    if (e.id === 0)
      say('👑 DAİMİ KONSEY HÜKÜMDARLIĞI İLAN EDİLDİ — seçimler kaldırıldı', 'win');
    else
      say('👑 ' + e.name + ' Daimi Konsey Hükümdarı oldu', 'war');
    if (typeof checkVictory === 'function') checkVictory(e, 'hegemonya');
    return {ok:true, gecti:true, evet, hayir};
  }

  /* RET: diktatör adayı damgası */
  e.threat = (e.threat || 0) + 30;
  e._billPenalty = (G.memAge || 0) + 60;
  for (const x of G.emps){
    if (x.dead || x.wild || x.crisisSide || x.id === e.id) continue;
    x.rel[e.id] = clamp((x.rel[e.id] || 0) - 22, -100, 100);
  }
  if (e.id === 0)
    say('Daimi hükümdarlık tasarın REDDEDİLDİ — galaksi seni diktatör adayı olarak gördü', 'war');
  return {ok:true, gecti:false, evet, hayir};
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 59 — AGRESİF SABOTAJLAR
   İki yeni operasyon. İkisi de 2. seviye ağ ister ve hedef SİSTEM
   seçimi gerektirir — imparatorluk geneline değil, tek bir noktaya
   vururlar. Bu yüzden cerrahi: savaş açmadan cepheyi zayıflatırsın.
   ═══════════════════════════════════════════════════════════════════ */
const SABO_YARD_COST  = 110;   // tersane sabotajı
const SABO_SUPPLY_COST = 130;  // lojistik hack (daha pahalı: daha yıkıcı)
const SABO_YARD_MONTHS = 12;
const SABO_SUPPLY_MONTHS = 6;

/* Hedef devletin sabote edilebilecek sistemleri */
function sabotageTargets(e, o, tur){
  if (!e || !o || o.dead) return [];
  const liste = [];
  for (const sy of G.sys){
    if (sy.owner !== o.id) continue;
    if (sy.seen.indexOf(e.id) < 0) continue;        // görmediğin yeri vuramazsın
    if (tur === 'yard'){
      const n = (typeof yardCount === 'function') ? yardCount(sy) : 0;
      if (!n) continue;
      if (sy.yardLock && sy.yardLock > (G.memAge || 0)) continue;
      liste.push({sy, bilgi: n + ' tersane'});
    } else {
      if (sy.supplyHack && sy.supplyHack > (G.memAge || 0)) continue;
      /* Filo varsa cazip */
      let filo = 0;
      for (const f of G.fleets)
        if (f.e === o.id && f.sys === sy.id && f.ships) filo += f.ships.length;
      liste.push({sy, bilgi: filo ? filo + ' gemi konuşlu' : 'boş sistem'});
    }
  }
  return liste;
}

function canSabotage(e, o, tur){
  if (!e || !o || o.dead) return {ok:false, why:'Hedef yok'};
  if (o.id === e.id) return {ok:false, why:'Kendini sabote edemezsin'};
  if (o.wild || o.crisisSide) return {ok:false, why:'Bu tarafın altyapısı yok'};
  const lvl = (typeof intelOf === 'function') ? intelOf(e, o.id) : 0;
  if (lvl < 2) return {ok:false, why:'En az 2. seviye istihbarat gerekir'};
  const bedel = tur === 'yard' ? SABO_YARD_COST : SABO_SUPPLY_COST;
  if ((e.res.etk || 0) < bedel) return {ok:false, why:bedel + ' etki gerekir'};
  const hedefler = sabotageTargets(e, o, tur);
  if (!hedefler.length)
    return {ok:false, why: tur === 'yard'
      ? 'Görebildiğin, sabote edilmemiş tersanesi yok'
      : 'Görebildiğin, hacklenmemiş sistemi yok'};
  return {ok:true, hedefler};
}

function doSabotage(e, o, tur, sysId){
  const chk = canSabotage(e, o, tur);
  if (!chk.ok) return chk;
  const sy = G.sys[sysId];
  if (!sy || sy.owner !== o.id) return {ok:false, why:'Sistem geçersiz'};

  const bedel = tur === 'yard' ? SABO_YARD_COST : SABO_SUPPLY_COST;
  e.res.etk -= bedel;

  const ch = (typeof sabotageChance === 'function')
    ? sabotageChance(e, o) : {basari:.4, ifsa:.3};
  /* Altyapı sabotajı casus sokmaktan zor: fiziksel erişim gerekir */
  const basari = clamp(ch.basari * (tur === 'yard' ? .90 : .80), .05, .78);
  const ifsa   = clamp(ch.ifsa   * (tur === 'yard' ? 1.10 : 1.25), .06, .70);

  if (rnd() < basari){
    if (tur === 'yard'){
      sy.yardLock = (G.memAge || 0) + SABO_YARD_MONTHS;
      /* Sıradaki üretim de iptal — tezgâh kapandı */
      if (sy.queue) sy.queue.length = 0;
      if (typeof recordSabotage === 'function') recordSabotage('yardSabo');
      if (e.id === 0 && typeof UI !== 'undefined')
        UI.eventArt('veri', 'TERSANE SABOTE EDİLDİ',
          sy.name + ' tersanesinde kontrol sistemleri çöktü. ' +
          SABO_YARD_MONTHS + ' ay boyunca tek bir gemi bile inşa edilemeyecek. ' +
          'Tezgâhtaki siparişler de iptal oldu.');
      else if (o.id === 0 && typeof UI !== 'undefined')
        UI.eventArt('infaz', 'TERSANEMİZ SABOTE EDİLDİ',
          sy.name + ' tersanesi ' + SABO_YARD_MONTHS +
          ' ay devre dışı. Failin kim olduğunu bilmiyoruz.');
    } else {
      sy.supplyHack = (G.memAge || 0) + SABO_SUPPLY_MONTHS;
      sy.supplyHackBy = e.id;
      if (typeof recordSabotage === 'function') recordSabotage('supplyHack');
      if (e.id === 0 && typeof UI !== 'undefined')
        UI.eventArt('veri', 'LOJİSTİK AĞI ÇÖKERTİLDİ',
          sy.name + ' sisteminin ikmal ağı ' + SABO_SUPPLY_MONTHS +
          ' ay boyunca karanlıkta. Oradaki filolar tedariksiz kalacak ' +
          've ciddi güç kaybı yaşayacak.');
      else if (o.id === 0 && typeof UI !== 'undefined')
        UI.eventArt('infaz', 'LOJİSTİK AĞIMIZ ÇÖKTÜ',
          sy.name + ' sisteminde ikmal hatları kesildi. Filolarımız ' +
          SABO_SUPPLY_MONTHS + ' ay boyunca tedariksiz savaşacak.');
    }
    /* Hedef bir şeyler döndüğünü sezer, faili bilmez */
    o.hitLog = o.hitLog || [];
    o.hitLog.push({t: G.memAge || 0, k: tur === 'yard' ? 'yardSabo' : 'supplyHack',
                   by: e.id, caught: false, known: false, sys: sy.id});
    return {ok:true, caught:false, sys:sy.name,
      msg: sy.name + ' vuruldu — ' + (tur === 'yard'
        ? 'tersane ' + SABO_YARD_MONTHS + ' ay kapalı'
        : 'lojistik ' + SABO_SUPPLY_MONTHS + ' ay çökük')};
  }

  if (rnd() < ifsa){
    if (typeof remember === 'function') remember(o, e.id, 'sabotaj');
    o.rel[e.id] = clamp((o.rel[e.id] || 0) - 45, -100, 100);
    o._lastCB = {n:'Altyapı Sabotajı', w:1.25};
    e.threat = (e.threat || 0) + 18;
    for (const x of G.emps){
      if (x.dead || x.wild || x.crisisSide || x.id === e.id || x.id === o.id) continue;
      x.rel[e.id] = clamp((x.rel[e.id] || 0) - 10, -100, 100);
    }
    if (typeof recordSabotage === 'function') recordSabotage('ifsa');
    if (e.id === 0 && typeof UI !== 'undefined')
      UI.eventArt('infaz', 'SABOTAJ EKİBİ YAKALANDI',
        o.name + ' ekibimizi ' + sy.name + ' yörüngesinde yakaladı. ' +
        'Kanıtlar galaksiye yayıldı; ellerinde meşru bir savaş nedeni var.');
    return {ok:true, caught:true,
      msg: 'Ekibimiz yakalandı — ' + o.name + ' savaş nedeni kazandı'};
  }

  if (typeof recordSabotage === 'function') recordSabotage('sessiz');
  return {ok:true, caught:false, msg:'Ekip hedefe sızamadı, sessizce çekildi'};
}

/* Aylık temizlik: süresi dolan kilitler kalkar */
function sabotageTick(){
  const simdi = G.memAge || 0;
  for (const sy of G.sys){
    if (sy.yardLock && sy.yardLock <= simdi){
      delete sy.yardLock;
      if (sy.owner === 0)
        say('⚓ ' + sy.name + ' tersanesi yeniden faal', 'win');
    }
    if (sy.supplyHack && sy.supplyHack <= simdi){
      delete sy.supplyHack; delete sy.supplyHackBy;
      if (sy.owner === 0)
        say('📦 ' + sy.name + ' lojistik ağı onarıldı', 'win');
    }
  }
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 66 — HAVUZLANMIŞ İSTİHBARAT
   Casusluk ağı paktı olan ortakların bir hedef üzerindeki
   seviyeleri birleşir. En yüksek olan geçerli; ortak sayısı
   arttıkça galaksinin görünmeyen köşesi kalmaz.
   ═══════════════════════════════════════════════════════════════════ */
function pooledIntel(e, targetId){
  let en = (typeof intelOf === 'function') ? intelOf(e, targetId) : 0;
  if (!e || !e.spynet) return en;
  for (const pid in e.spynet){
    if (!e.spynet[pid]) continue;
    const ortak = G.emps[pid];
    if (!ortak || ortak.dead || ortak.id === targetId) continue;
    /* Savaşa girdiysek pakt fiilen ölür */
    if (e.war[ortak.id]) continue;
    const lv = (typeof intelOf === 'function') ? intelOf(ortak, targetId) : 0;
    if (lv > en) en = lv;
  }
  return en;
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 71 — FEDERASYON UYUMU (COHESION)
   0–100 arası. Etik zıtlığı, onaysız savaşlar ve liderlik
   çekişmesi düşürür; ortak düşman, ortak yasa ve uzun birliktelik
   yükseltir. Sıfıra inerse federasyon dağılır.
   ═══════════════════════════════════════════════════════════════════ */
/* FAZ 71: FED_LAWS zaten satır 687'de tanımlıydı (savunma paktı,
   ortak araştırma vb.). Bunlar YENİ İÇ YASALAR — oylama ile
   kabul edilen, uyuma etki eden ek düzenlemeler. */
const FED_INNER_LAWS = {
  serbest  :{n:'Serbest Dolaşım', ico:'🚪', c:80, cat:'Üyelik ve yönetim', ai:'dip',
             d:'Üyeler birbirinin sınırlarından geçebilir; uyum +8.'},
  ortakDon :{n:'Ortak Donanma',   ico:'⚓', c:140, cat:'Bütçe', group:'butce', ai:'war',
             d:'Pozitif aylık alaşım ve enerji gelirinden federal fon kesintisi %5 → %9; her üyeye +15 filo kapasitesi. Stok kesintiyi karşılamıyorsa o kaynak alınmaz.'},
  bilimAgi :{n:'Bilim Ağı',       ico:'🔬', c:110, cat:'Bilim', group:'bilim', ai:'sci',
             d:'Tüm üyelerin aylık araştırma geliri +%12.'},
  savasOnay:{n:'Savaş Onayı',     ico:'⚖', c:100, cat:'Üyelik ve yönetim', ai:'dip',
             d:'Yeni dış saldırı savaşları federasyon izni ister. İzin yalnız öneren üye ve hedef için, 180 gün ve tek ilan geçerlidir. Savunma yükümlülükleri muaftır; mevcut savaşlar sürer.'},
  sivilFon:{n:'Sivil Bütçe', ico:'🏗', c:100, cat:'Bütçe', group:'butce', ai:'eco',
             d:'Federal fon kesintisi %3 olur. Pozitif aylık enerji geliri +%8; araştırma geliri −%4. Ortak Donanma yerine geçer.'},
  patentOzerk:{n:'Patent Özerkliği', ico:'📚', c:90, cat:'Bilim', group:'bilim', ai:'eco',
             d:'Araştırma geliri +%4, aylık Etki +2. Bilim Ağı yerine geçer.'},
  seriUretim:{n:'Ortak Sanayi Standartları', ico:'🏭', c:120, cat:'Üretim ve refah', group:'uretim', ai:'war',
             d:'Pozitif aylık alaşım geliri +%10; pozitif mineral geliri −%5. Refah Şartı yerine geçer.'},
  refah:{n:'Refah Şartı', ico:'🌾', c:100, cat:'Üretim ve refah', group:'uretim', ai:'eco',
             d:'Pozitif aylık yiyecek ve tüketim malı gelirleri +%10; pozitif alaşım geliri −%5. Ortak Sanayi Standartları yerine geçer.'},
  ortakDoktrin:{n:'Ortak Muharebe Doktrini', ico:'🛡', c:130, cat:'Savunma ve lojistik', ai:'war',
             d:'Gemi hasar değiştiricisi +8 yüzde puan; filo bakım değiştiricisi +5 yüzde puan.'},
  ikmalStandardi:{n:'Ortak Seyir Standartları', ico:'🚀', c:110, cat:'Savunma ve lojistik', ai:'war',
             d:'Filo hız değiştiricisi +8 yüzde puan; filo bakım değiştiricisi +6 yüzde puan.'},
  uyumProgrami:{n:'Uzlaşma Programı', ico:'🤝', c:90, cat:'Üyelik ve yönetim', ai:'dip',
             d:'Federasyon uyumuna ayda +0,6; her üyenin aylık Etki gelirine −1.'}
};

function fedLawConflicts(f, key){
  const L = FED_INNER_LAWS[key];
  return L && L.group ? Object.keys(FED_INNER_LAWS).filter(k =>
    k !== key && FED_INNER_LAWS[k].group === L.group && f.laws && f.laws[k]) : [];
}
function fedLawCost(key, repeal){
  const L = Object.hasOwn(FED_INNER_LAWS,key)?FED_INNER_LAWS[key]:Object.hasOwn(FED_LAWS,key)?{c:60}:null;
  return L ? (repeal ? Math.ceil(L.c / 2) : L.c) : Infinity;
}
function fedApplyIncomeLaws(e, inc){
  const positive = (key, factor) => { if (inc[key] > 0) inc[key] *= factor; };
  const f=findFed(e);if(f){const T=fedType(f);positive('ara',T.ara);positive('ene',T.ene);}
  if (fedHasLaw(e, 'bilimAgi')) inc.ara *= 1.12;
  if (fedHasLaw(e, 'sivilFon')){ positive('ene',1.08); inc.ara *= .96; }
  if (fedHasLaw(e, 'patentOzerk')){ inc.ara *= 1.04; inc.etk += 2; }
  if (fedHasLaw(e, 'seriUretim')){ positive('ala',1.10); positive('min',.95); }
  if (fedHasLaw(e, 'refah')){ positive('yiy',1.10); positive('tuk',1.10); positive('ala',.95); }
  if (fedHasLaw(e, 'uyumProgrami')) inc.etk -= 1;
  return inc;
}

function fedCohesion(f){
  if (!f) return 0;
  return Math.round(f.cohesion === undefined ? 70 : f.cohesion);
}

/* İki üyenin etik uzaklığı — 0 (aynı) … 1 (tam zıt) */
function ethicGap(a, b){
  let t = 0, n = 0;
  for (const ax in ETHICS){
    const va = (a.ethics && a.ethics[ax]) || 0;
    const vb = (b.ethics && b.ethics[ax]) || 0;
    t += Math.abs(va - vb); n += ETHIC_MAX * 2;
  }
  return n ? t / n : 0;
}

function cohesionTick(){
  if (!G.feds) return;
  for (let i = G.feds.length - 1; i >= 0; i--){
    const f = G.feds[i];
    if (!f || !f.members) continue;
    const uyeler = f.members.map(m => G.emps[m]).filter(x => x && !x.dead);
    if (uyeler.length < 2){ f.cohesion = 0; }
    if (f.cohesion === undefined) f.cohesion = 70;

    let delta = 0;

    /* ── ETİK ZITLIĞI ── en büyük sürtüşme kaynağı */
    let gapTop = 0, cift = 0;
    for (let a = 0; a < uyeler.length; a++)
      for (let b = a + 1; b < uyeler.length; b++){
        gapTop += ethicGap(uyeler[a], uyeler[b]); cift++;
      }
    const ortGap = cift ? gapTop / cift : 0;
    delta -= ortGap * 3.2;                    // tam zıtlıkta −3.2/ay

    /* 91E.1: yeni saldırılar izin kapısından geçer. Eski savaşların
       saldırganını tahmin ederek geriye dönük uyum cezası üretmeyiz. */
    if (f.laws && f.laws.uyumProgrami) delta += .6;

    /* ── ORTAK DÜŞMAN birleştirir ── */
    let ortak = 0;
    for (const o of G.emps){
      if (o.dead || o.wild || o.crisisSide || f.members.includes(o.id)) continue;
      let kac = 0;
      for (const u of uyeler) if (u.war[o.id]) kac++;
      if (kac >= 2) ortak++;
    }
    delta += Math.min(1.6, ortak * .8);

    /* ── ORTAK YASALAR ── */
    const yasaN = f.laws ? Object.keys(f.laws).length : 0;
    delta += yasaN * .35;

    /* ── ZAMAN: uzun birliktelik alışkanlık yaratır ── */
    const yil = ((G.day - (f.founded || 0)) / 360);
    delta += Math.min(.8, yil * .06);

    /* ── İÇ SAVAŞ: üyeler birbiriyle savaşıyorsa yıkıcı ── */
    for (let a = 0; a < uyeler.length; a++)
      for (let b = a + 1; b < uyeler.length; b++)
        if (uyeler[a].war[uyeler[b].id]) delta -= 6;

    f.cohesion = clamp(f.cohesion + delta, 0, 100);

    /* Oyuncuya uyarı */
    if (f.members.includes(0)){
      if (f.cohesion < 25 && f._uyumUyari !== 'kritik'){
        f._uyumUyari = 'kritik';
        say('⚠ ' + f.name + ' uyumu kritik (%' + Math.round(f.cohesion) +
            ') — federasyon dağılmak üzere', 'war');
      } else if (f.cohesion >= 45 && f._uyumUyari === 'kritik'){
        f._uyumUyari = null;
      }
    }

    /* ── ÇÖKÜŞ ── */
    if (f.cohesion <= 0){
      const ad = f.name;
      for (const u of uyeler){
        delete u.fedId;
        for (const v of uyeler)
          if (v !== u) u.rel[v.id] = clamp((u.rel[v.id] || 0) - 15, -100, 100);
      }
      fedDissolve(f);
      for (const u of uyeler) if (!u.dead) recalcMods(u);
      if (f.members.includes(0) && typeof UI !== 'undefined')
        UI.eventArt('veri', 'FEDERASYON DAĞILDI',
          ad + ' iç uyumunu tamamen kaybetti ve dağıldı. Üyeler artık ' +
          'birbirine yabancı; ortak savunma ve fon sona erdi.', 'war');
      else say('🏛 ' + ad + ' dağıldı — uyum tükendi', 'war');
    }
  }
}

/* ═══ FEDERASYON İÇ YASALARI ═══ */
function canFedLaw(e, key, repeal = false){
  const F = FED_INNER_LAWS[key];
  if (!Object.hasOwn(FED_INNER_LAWS,key)&&!Object.hasOwn(FED_LAWS,key)) return {ok:false, why:'Bilinmeyen yasa'};
  if (!e || G.emps[e.id] !== e || e.dead || e.wild || e.crisisSide)
    return {ok:false, why:'Geçerli üye gerekli'};
  const f = findFed(e);
  if (!f) return {ok:false, why:'Bir federasyona üye değilsin'};
  if (repeal ? !(f.laws && f.laws[key]) : !!(f.laws && f.laws[key]))
    return {ok:false, why:repeal ? 'Bu yasa yürürlükte değil' : 'Bu yasa zaten yürürlükte'};
  const aq=fedAgendaCheck(f,'law',key,{repeal:!!repeal});if(!aq.ok)return aq;
  const cost = fedLawCost(key, repeal);
  if (!Number.isFinite(e.res.etk) || e.res.etk < cost) return {ok:false, why:cost + ' etki gerekir'};
  return {ok:true, fed:f};
}
function proposeFedLaw(e, key, repeal = false){
  const chk = canFedLaw(e, key, repeal);
  if (!chk.ok) return chk;
  if(fedAgendaWaiting(chk.fed))return fedAgendaEnqueue(chk.fed,e,'law',key,{repeal:!!repeal});
  const result = fedChange(() => {
    e.res.etk -= fedLawCost(key, repeal);
    return fedOpenVote(chk.fed, key, e, {repeal:!!repeal});
  });
  fedPresentVote(chk.fed, result);
  return result;
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 72 — BAĞIMSIZLIK DESTEKLEME
   Bir devlet, BAŞKASININ vasalına gizlice destek sözü verir.
   Vasal isyan ederse destekçiler otomatik savaşa girer. Bu söz
   vasalın cesaretini artırır: sadakat eşiği düşer, emir reddetme
   olasılığı yükselir.
   ═══════════════════════════════════════════════════════════════════ */
const SUPPORT_COST = 140;

function canSupportIndep(e, sub){
  if (!e || !sub || sub.dead) return {ok:false, why:'Hedef yok'};
  if (sub.id === e.id) return {ok:false, why:'Kendini destekleyemezsin'};
  if (sub.wild || sub.crisisSide) return {ok:false, why:'Bu taraf müzakere etmez'};
  if (typeof isVassal !== 'function' || !isVassal(sub))
    return {ok:false, why:'Bu devlet kimsenin vasalı değil'};
  if (sub.overlord === e.id)
    return {ok:false, why:'Kendi vasalının isyanını destekleyemezsin'};
  if (sub.indepBackers && sub.indepBackers.indexOf(e.id) >= 0)
    return {ok:false, why:'Zaten destekliyorsun'};
  if (!e.contact[sub.id]) return {ok:false, why:'Temas yok'};
  if ((e.res.etk || 0) < SUPPORT_COST)
    return {ok:false, why:SUPPORT_COST + ' etki gerekir'};
  const lord = overlordOf(sub);
  if (lord && e.ally && e.ally[lord.id])
    return {ok:false, why:'Senyörü müttefikin — bu ihanet olur'};
  return {ok:true, lord};
}

function supportIndep(e, sub){
  const chk = canSupportIndep(e, sub);
  if (!chk.ok) return chk;
  e.res.etk -= SUPPORT_COST;
  sub.indepBackers = sub.indepBackers || [];
  sub.indepBackers.push(e.id);
  sub.rel[e.id] = clamp((sub.rel[e.id] || 0) + 22, -100, 100);

  /* Senyör sezerse öfkelenir — %40 ihtimalle sızar */
  const lord = chk.lord;
  if (lord && rnd() < .40){
    lord.rel[e.id] = clamp((lord.rel[e.id] || 0) - 30, -100, 100);
    if (typeof remember === 'function') remember(lord, e.id, 'komplo');
    if (lord.id === 0)
      say('🕯 ' + e.name + ' vasalın ' + sub.name +
          ' ile gizli görüşmeler yapıyor', 'war');
    if (e.id === 0)
      say('⚠ Destek sözün sızdı — ' + lord.name + ' öfkeli', 'war');
  } else if (e.id === 0){
    say('🕯 ' + sub.name + ' bağımsızlık sözünü aldı — isyan ederlerse ' +
        'yanlarında savaşacaksın', 'sci');
  }
  return {ok:true, sizdi: false};
}

/* İsyan patladığında destekçileri savaşa sok */
function joinIndepWar(sub, lord){
  if (!sub || !sub.indepBackers) return 0;
  let kac = 0;
  for (const bid of sub.indepBackers){
    const b = G.emps[bid];
    if (!b || b.dead || b.wild || b.crisisSide) continue;
    if (b.war[lord.id]) continue;
    b.war[lord.id] = true; lord.war[b.id] = true;
    b.warSince = b.warSince || {}; b.warSince[lord.id] = G.day;
    b.warCause = b.warCause || {}; b.warCause[lord.id] = 'Bağımsızlık Desteği';
    warStartNotice(b,lord,{sponsor:sub.id,enemy:lord.id,kind:'independenceSupport'});
    if (typeof recalcMods === 'function'){ recalcMods(b); recalcMods(lord); }
    kac++;
    if (b.id === 0)
      say('⚔ Verdiğin söz gereği ' + sub.name + ' yanında savaşa girdin', 'war');
  }
  sub.indepBackers = [];              // söz yerine getirildi
  return kac;
}


/* ═══════════════════════════════════════════════════════════════════
   FAZ 78 — BİAT VE HİMAYE MÜZAKERESİ
   Vasallık motoru (subjugate, vassalLoyalty, EDICTS) Faz 71'de
   kurulmuştu ama yalnız SAVAŞ SONUCU ya da AI sığınmasıyla
   işliyordu. Artık masada da konuşulabiliyor:
     · Biat İste  → güçlüyken zayıfa teklif
     · Koruma Talep Et → zayıfken güçlüden isteme
   ═══════════════════════════════════════════════════════════════════ */
const VASSAL_DEMAND_COST = 160;   // biat isteme bedeli
const VASSAL_SEEK_COST   = 90;    // koruma talep etme bedeli

function canDemandVassal(e, o){
  if (!e || !o || o.dead) return {ok:false, why:'Hedef yok'};
  if (o.id === e.id) return {ok:false, why:'Kendine biat edemezsin'};
  if (o.wild || o.crisisSide) return {ok:false, why:'Bu taraf müzakere etmez'};
  if (!e.contact[o.id]) return {ok:false, why:'Temas yok'};
  if (isVassal(o)) return {ok:false, why:o.name + ' zaten bir senyöre bağlı'};
  if (isVassal(e)) return {ok:false, why:'Vasal, vasal edinemez'};
  if (e.war[o.id]) return {ok:false, why:'Savaştayken masaya oturulmaz'};
  if (typeof isPurifier === 'function' && isPurifier(e))
    return {ok:false, why:'Doktrinin diplomasiye kapalı'};
  if ((e.res.etk || 0) < VASSAL_DEMAND_COST)
    return {ok:false, why:VASSAL_DEMAND_COST + ' etki gerekir'};
  const oran = totalPower(e) / Math.max(1, e.ai?aiKnownPower(e,o):totalPower(o));
  if (oran < 1.6)
    return {ok:false, why:'Yeterince güçlü değilsin (' + oran.toFixed(1) +
            '× — en az 1.6× gerekir)'};
  return {ok:true, oran};
}

/* Hedef kabul eder mi? Güç farkı, ilişki ve mizaç belirler. */
function vassalAcceptChance(lord, sub){
  const oran = totalPower(lord) / Math.max(1, totalPower(sub));
  let p = clamp((oran - 1.6) * .28, 0, .55);
  p += clamp((sub.rel[lord.id] || 0) / 320, -.20, .22);
  let savasta = 0;
  for (const w in sub.war) if (sub.war[w] && G.emps[w] && !G.emps[w].wild) savasta++;
  p += savasta * .12;                                   // sıkışmışsa razı olur
  let sysN = 0;
  for (const sy of G.sys) if (sy.owner === sub.id) sysN++;
  if (sysN <= 3) p += .15;                              // küçük devlet
  const P = (typeof personaOf === 'function') ? personaOf(sub) : null;
  if (P){
    if (P.n === 'Militarist') p -= .22;
    if (P.n === 'Fanatik Arındırıcılar') p = 0;
    if (P.n === 'Pasifist') p += .12;
  }
  return clamp(p, 0, .88);
}

function demandVassal(e,o,tur,terms=null){return vassalOffer(e,o,'demand',VASSAL_TYPES[tur]?tur:'haracguzar',terms);}

function canSeekProtection(e, o){
  if (!e || !o || o.dead) return {ok:false, why:'Hedef yok'};
  if (o.id === e.id) return {ok:false, why:'Kendinden koruma istenmez'};
  if (o.wild || o.crisisSide) return {ok:false, why:'Bu taraf himaye vermez'};
  if (!e.contact[o.id]) return {ok:false, why:'Temas yok'};
  if (isVassal(e)) return {ok:false, why:'Zaten bir senyörün var'};
  if (isVassal(o)) return {ok:false, why:o.name + ' de bir vasal'};
  if (e.war[o.id]) return {ok:false, why:'Savaştığın devletten himaye istenmez'};
  if (typeof vassalsOf === 'function' && vassalsOf(e).length)
    return {ok:false, why:'Kendi vasalların varken boyun eğemezsin'};
  if ((e.res.etk || 0) < VASSAL_SEEK_COST)
    return {ok:false, why:VASSAL_SEEK_COST + ' etki gerekir'};
  const oran = (e.ai?aiKnownPower(e,o):totalPower(o)) / Math.max(1, totalPower(e));
  if (oran < 1.3)
    return {ok:false, why:'Yeterince güçlü değil — seni koruyamaz'};
  return {ok:true, oran};
}

function seekProtection(e,o,tur,terms=null){return vassalOffer(e,o,'seek',VASSAL_TYPES[tur]?tur:'bekci',terms);}

/* ═══════════════════════════════════════════════════════════════════
   FAZ 78 — AYRILIKÇILARI FONLA (vasal sadakati sabotajı)
   Mevcut inciteRebellion() bir devletin KENDİ kolonilerini
   kışkırtıyor. Bu farklı: RAKİBİNİN VASALINI hedef alıyor ve
   sadakati aşındırıyor. Sadakat dibe vurunca vasal kendiliğinden
   bağımsızlık savaşı başlatıyor — sen hiç savaşa girmeden
   rakibinin arkasını yakıyorsun.
   ═══════════════════════════════════════════════════════════════════ */
const FUND_SEP_COST = {etk: 70, ene: 300};
const FUND_SEP_HIT  = 12;      // her fonlamada sadakat düşüşü
const FUND_SEP_CD   = 12;      // ay

function canFundSeparatists(e, sub){
  if (!e || !sub || sub.dead) return {ok:false, why:'Hedef yok'};
  if (sub.id === e.id) return {ok:false, why:'Kendi halkını fonlayamazsın'};
  if (sub.wild || sub.crisisSide) return {ok:false, why:'Bu tarafta vasal yok'};
  if (typeof isVassal !== 'function' || !isVassal(sub))
    return {ok:false, why:'Bu devlet kimsenin vasalı değil'};
  if (sub.overlord === e.id)
    return {ok:false, why:'Kendi vasalını fonlamak intihardır'};
  if (!e.contact[sub.id]) return {ok:false, why:'Temas yok'};
  if (typeof isPurifier === 'function' && isPurifier(e))
    return {ok:false, why:'Doktrinin gizli diplomasiye kapalı'};
  if (sub._fundCd && sub._fundCd > (G.memAge || 0))
    return {ok:false, why:'Ajanlar hâlâ sahada — ' +
            (sub._fundCd - (G.memAge || 0)) + ' ay bekle'};
  for (const r in FUND_SEP_COST)
    if ((e.res[r] || 0) < FUND_SEP_COST[r])
      return {ok:false, why:'Yetersiz ' + (RES[r] ? RES[r].n : r) +
              ' (' + FUND_SEP_COST[r] + ' gerekir)'};
  return {ok:true, sadakat: vassalLoyalty(sub)};
}

function fundSeparatists(e, sub){
  const chk = canFundSeparatists(e, sub);
  if (!chk.ok) return chk;
  for (const r in FUND_SEP_COST) e.res[r] -= FUND_SEP_COST[r];
  sub._fundCd = (G.memAge || 0) + FUND_SEP_CD;

  const lord = overlordOf(sub);
  /* Kalıcı sadakat aşınması — vassalLoyalty bunu okur */
  sub.sepFunded = (sub.sepFunded || 0) + FUND_SEP_HIT;
  sub.rel[e.id] = clamp((sub.rel[e.id] || 0) + 10, -100, 100);
  const kalan = vassalLoyalty(sub);

  /* İfşa riski: senyörün istihbaratı yakalayabilir */
  const lvl = (lord && typeof intelOf === 'function') ? intelOf(lord, e.id) : 0;
  const ifsa = clamp(.18 + lvl * .10, .05, .60);
  if (lord && rnd() < ifsa){
    lord.rel[e.id] = clamp((lord.rel[e.id] || 0) - 35, -100, 100);
    if (typeof remember === 'function') remember(lord, e.id, 'komplo');
    lord._lastCB = {n:'Vasal Kışkırtma', w:1.20};
    if (e.id === 0)
      say('⚠ Fonlama sızdı — ' + lord.name + ' arkasındaki eli gördü', 'war');
    else if (lord.id === 0 && typeof UI !== 'undefined')
      UI.eventArt('infaz', 'VASAL KIŞKIRTMA İFŞA OLDU',
        e.name + ' vasalın ' + sub.name + ' içindeki ayrılıkçıları gizlice ' +
        'finanse ediyor. Kanıtlar elimizde — savaş nedeni doğdu.',
        'war', 'kritik', e);
    return {ok:true, ifsa:true, sadakat:kalan};
  }

  if (e.id === 0)
    say('🕯 ' + sub.name + ' içindeki ayrılıkçılara para aktı — sadakat %' +
        kalan, 'sci');
  return {ok:true, ifsa:false, sadakat:kalan};
}

/* Sadakat sıfırlanınca vasal kendiliğinden isyan eder */
function separatistTick(){
  for (const sub of G.emps){
    if (sub.dead || sub.wild || sub.crisisSide) continue;
    if (!isVassal(sub)) continue;
    /* Fonlama zamanla soğur — sürekli beslenmezse etkisi geçer */
    if (sub.sepFunded) sub.sepFunded = Math.max(0, sub.sepFunded - .35);
    if (vassalLoyalty(sub) > 0) continue;

    const lord = overlordOf(sub);
    if (!lord || lord.dead) continue;
    /* ═══ BAĞIMSIZLIK SAVAŞI ═══ */
    sub.overlord = null;
    delete sub.vassalType;
    sub.edicts = {};
    sub.sepFunded = 0;
    sub.war[lord.id] = true; lord.war[sub.id] = true;
    sub.warSince = sub.warSince || {}; sub.warSince[lord.id] = G.day;
    sub.warCause = sub.warCause || {}; sub.warCause[lord.id] = 'Bağımsızlık Savaşı';
    lord.warSince = lord.warSince || {}; lord.warSince[sub.id] = G.day;
    warStartNotice(sub,lord,{kind:'independence'});
    sub.rel[lord.id] = -100;
    if (typeof recalcMods === 'function'){ recalcMods(sub); recalcMods(lord); }
    if (typeof remember === 'function') remember(sub, lord.id, 'ihanet');
    /* Destek sözü verenler de savaşa girer (Faz 72) */
    if (typeof joinIndepWar === 'function') joinIndepWar(sub, lord);

    if (lord.id === 0 && typeof UI !== 'undefined')
      UI.eventArt('infaz', 'VASAL AYAKLANDI',
        sub.name + ' sadakatini tamamen yitirdi ve bağımsızlık savaşı ' +
        'başlattı. Aylardır birileri onların kulağına fısıldıyormuş.',
        'war', 'kritik', sub);
    else if (sub.id === 0 && typeof UI !== 'undefined')
      UI.eventArt('veri', 'ZİNCİRLER KIRILDI',
        lord.name + ' boyunduruğunu reddettik. Bağımsızlık savaşı başladı.',
        'win', 'kritik', lord);
    else if (typeof say === 'function')
      say('⚡ ' + sub.name + ', ' + lord.name + ' senyörlüğüne başkaldırdı', 'war');
  }
}

/* 95D: relationship knowledge is deliberately narrower than mere contact. */
function knownFederationBond(viewer,f,id){
 if(!viewer||!f||!f.members.includes(id))return false;
 if(f.members.includes(viewer.id))return id===viewer.id||!!viewer.contact[id];
 // Existing level-3 intelligence reveals a target's relationship table.
 return !!viewer.contact[id]&&(viewer.intel?.[id]||0)>=3;
}
function knownAllianceBond(viewer,a,b){return !!viewer&&(a.id===viewer.id||!!viewer.contact[a.id])&&(b.id===viewer.id||!!viewer.contact[b.id])&&(viewer.id===a.id||viewer.id===b.id||(viewer.intel?.[a.id]||0)>=3||(viewer.intel?.[b.id]||0)>=3);}
let DIPLO_MAP_CACHE=null;
function diplomacyMapConnections(zoom=.3){
 if(!G.p||zoom<.10)return [];
 const signature=JSON.stringify([Math.floor(G.day),zoom<.18?12:36,FED_LINKS_ON,ALLY_LINKS_ON,G.emps.map(e=>[e.id,e.dead,e.home,G.p.contact[e.id],G.p.intel?.[e.id],Object.entries(e.ally||{}).filter(x=>x[1]).map(x=>x[0])]),(G.feds||[]).map(f=>[f.id,f.leader,f.members,f.emblem])]);
 if(DIPLO_MAP_CACHE&&DIPLO_MAP_CACHE.world===G.sys&&DIPLO_MAP_CACHE.vis===G.vis&&DIPLO_MAP_CACHE.signature===signature)return DIPLO_MAP_CACHE.lines;
 const endpoints=new Map();for(const s of G.sys){if(!pSeen(s)||!territoryOwnerInfo(s.owner)?.known)continue;const e=G.emps[s.owner];if(!endpoints.has(e.id)||s.id===e.home)endpoints.set(e.id,s);}
 const out=[],pairs=new Set(),limit=zoom<.18?12:36;
 const add=(a,b,kind,emblem)=>{const key=Math.min(a,b)+':'+Math.max(a,b);if(a===b||pairs.has(key)||!endpoints.has(a)||!endpoints.has(b)||out.length>=limit)return;pairs.add(key);out.push({a,b,kind,from:endpoints.get(a),to:endpoints.get(b),emblem});};
 if(FED_LINKS_ON)for(const f of G.feds||[]){const ids=f.members.filter(id=>!G.emps[id]?.dead&&knownFederationBond(G.p,f,id)&&endpoints.has(id));if(ids.length<2)continue;const hub=ids.includes(f.leader)?f.leader:ids[0];for(const id of ids)if(id!==hub)add(hub,id,'federation',f.emblem||makeEmblem('federation:'+G.seed+':'+f.id,'#f5c25c',true));}
 if(ALLY_LINKS_ON)for(const a of G.emps){if(a.dead||a.wild)continue;for(const key of Object.keys(a.ally||{})){const b=G.emps[+key];if(!a.ally[key]||!b||b.dead||a.id>=b.id||!b.ally[a.id]||!knownAllianceBond(G.p,a,b))continue;add(a.id,b.id,'alliance');}}
 DIPLO_MAP_CACHE={world:G.sys,vis:G.vis,signature,lines:out};return out;
}

/* 95D: pure entry gate, also consumed by the real declaration path. */
function warDeclarationAccess(a,b,options={}){
 const no=why=>({ok:false,why});
 if(!a||!b||a.dead||b.dead||a.id===b.id)return no('Geçerli ve yaşayan iki devlet gerekli');
 if(a.war[b.id])return no('Savaş zaten sürüyor');
 if(sovereignPair(a,b))return no('Önce bağımsızlık gerekir');
 if(!options.defensive&&!fedWarAllowed(a,b))return no('Federasyon savaş izni gerekli — diplomasi veya federasyon panelinden öner.');
 if(hasCivic(a,'shadow'))return no('Gölge Konseyi resmî savaş ilan etmez — operasyonları kullan');
 if(hasCivic(a,'universal'))return no('Evrensel Barış doktrini savaş ilanını yasaklar');
 if(!options.authorized&&!canDeclareWarOn(a,b))return no('Savaş ilanı yetkisi veya hedef koşulları uygun değil');
 return {ok:true,why:''};
}
function warDeclarationPreview(actor,target,key){
 const access=warDeclarationAccess(actor,target),goal=WAR_GOALS[key],cost=actor&&hasPerk(actor,'freeWar')?0:goal?.etk||0;
 const p={ok:false,target:target&&actor&&(target.id===actor.id||actor.contact[target.id])?{id:target.id,name:target.name}:null,cost,certain:[],conditional:[],risks:[],blockers:[]};
 if(!p.target){p.blockers.push('Hedefle temas yok');p.signature=JSON.stringify(p);return p;}
 if(!access.ok)p.blockers.push(access.why);
 if(!goal)p.blockers.push('Geçerli savaş hedefi seç');
 if((actor.res.etk||0)<cost)p.blockers.push('Yetersiz Etki: '+cost+' gerekir');
 if(councilBlocksWar(actor,target))p.risks.push('Galaktik Konsey yasağını ihlal edersin; mevcut Konsey cezası uygulanır.');
 if(actor.ally[target.id]&&target.ally[actor.id])p.risks.push('İttifakı bozmak ihanet ve itibar kaybı yaratır.');
 if((actor.nap?.[target.id]||0)>G.day)p.risks.push('Saldırmazlık anlaşmasını bozmak itibar kaybı yaratır.');
 const seen=new Set([actor.id,target.id]),queue=[{victim:target,enemy:actor,side:'defense'}];
 const add=(e,enemy,side,why,automatic,defensive=false)=>{
  if(!e||e.dead||e.wild||seen.has(e.id)||!actor.contact[e.id]||e.id===actor.id||e.id===target.id)return;
  const gate=warDeclarationAccess(e,enemy,{authorized:true,defensive}),council=councilBlocksWar(e,enemy);
  const certainty=automatic&&gate.ok&&!council;
  const row={id:e.id,name:e.name,side,why:why+(council?' · Konsey engeli: katılım kesin değil':'')};
  (certainty?p.certain:p.conditional).push(row);seen.add(e.id);
  if(certainty)queue.push({victim:enemy,enemy:e,side:side==='defense'?'attack':'defense'});
 };
 const attackFed=findFed(actor);
 if(attackFed)for(const id of attackFed.members){if(id===actor.id||!knownFederationBond(actor,attackFed,id))continue;const e=G.emps[id],auto=fedDuty(attackFed,'offense')&&G.day>=(attackFed.dutySince?.offense||0)&&attackFed.dutyConsent?.[id]?.offense&&fedSupportGate(e,target).ok;
  add(e,target,'attack',auto?'Kabul edilmiş saldırı yükümlülüğü':'Federasyon oylaması veya ayrı yardım taahhüdü gerekli',!!auto);}
 // Follow only known obligations. A queue item represents the victim of a
 // future declaration, just like fedDefend / overlordDefend in the motor.
 for(let i=0;i<queue.length&&i<G.emps.length*2;i++){
  const {victim,enemy,side}=queue[i],f=findFed(victim);
  if(f)for(const id of f.members){if(id===victim.id||!knownFederationBond(actor,f,id)||!knownFederationBond(actor,f,victim.id))continue;const e=G.emps[id];
    const auto=fedDuty(f,'defense')&&(!f.defenseFrontCutoff||(G.warLedger?.next||1)>=f.defenseFrontCutoff)&&fedSupportGate(e,enemy,false).ok;
    add(e,enemy,side,auto?'Yürürlükteki ortak savunma yükümlülüğü':'Savunma oylaması veya gönüllü yardım gerekli',!!auto,true);
  }
  const lord=overlordOf(victim);
  if(lord&&(actor.id===victim.id||actor.id===lord.id||(actor.intel?.[victim.id]||0)>=3)){
    add(lord,enemy,side,'Senyörlük koruma yükümlülüğü',true,true);
    for(const v of vassalsOf(lord))if(vassalDuty(v,'join',enemy)&&(actor.id===lord.id||actor.id===v.id||(actor.intel?.[v.id]||0)>=3))add(v,enemy,side,'Sınır bekçisinin koruma yükümlülüğü',true,true);
  }
 }
 for(const base of [{e:actor,enemy:target,side:'attack'},{e:target,enemy:actor,side:'defense'}])for(const id of Object.keys(base.e.ally||{})){const e=G.emps[+id];if(e&&base.e.ally[id]&&e.ally[base.e.id]&&knownAllianceBond(actor,base.e,e))add(e,base.enemy,base.side,'İttifak: ayrı gönüllü yardım veya savaş taahhüdü gerekli',false);}
 p.certain.sort((a,b)=>a.id-b.id);p.conditional.sort((a,b)=>a.id-b.id);p.ok=!p.blockers.length;p.signature=JSON.stringify(p);return p;
}

/* 96G.1: clauses belong to the existing subject relationship. Talks refer to
   these same clauses; they do not transfer anything until mutual agreement. */
const VASSAL_RESOURCES=['ene','min','ala','yiy','tuk'];
function vassalDefaultTerms(type,legacy=false){
 return {tax:type==='haracguzar'?{ene:.20,min:.20,ala:.20,yiy:0,tuk:0}:{ene:0,min:0,ala:0,yiy:0,tuk:0},science:type==='akademik'?.22:0,defense:true,war:type==='bekci'?'all':'none',autonomy:legacy||type==='akademik'?'free':'consent',duration:0,renegotiate:24,sensors:false};
}
function vassalTerms(type,raw){
 if(!Object.hasOwn(VASSAL_TYPES,type)||!raw||typeof raw!=='object'||Array.isArray(raw))return null;
 const t={...vassalDefaultTerms(type),...raw,tax:{...vassalDefaultTerms(type).tax,...raw.tax}};
 if(Object.keys(t).some(k=>!['tax','science','defense','war','autonomy','duration','renegotiate','sensors'].includes(k))||Object.keys(t.tax).some(k=>!VASSAL_RESOURCES.includes(k)))return null;
 const max=type==='haracguzar'?.30:.10,maxSci=type==='akademik'?.30:.10;
 if(VASSAL_RESOURCES.some(k=>!Number.isFinite(t.tax[k])||t.tax[k]<0||t.tax[k]>max)||!Number.isFinite(t.science)||t.science<0||t.science>maxSci||type==='akademik'&&t.science<.05)return null;
 if(!['none','defense','all'].includes(t.war)||type==='bekci'&&t.war==='none'||type==='akademik'&&t.war==='all'||!['free','consent'].includes(t.autonomy)||typeof t.defense!=='boolean'||typeof t.sensors!=='boolean')return null;
 if(!Number.isSafeInteger(t.duration)||t.duration!==0&&(t.duration<12||t.duration>240)||![12,24,60].includes(t.renegotiate))return null;
 return t;
}
function vassalContractOf(sub){
 if(!isVassal(sub))return null;
 const c=sub.vassalContract;
 if(c&&c.status==='active'&&c.lord===sub.overlord&&c.sub===sub.id)return c;
 return {v:1,lord:sub.overlord,sub:sub.id,type:vassalType(sub),terms:vassalDefaultTerms(vassalType(sub),true),started:Math.max(0,G.day-((G.memAge||0)-(sub.vassalSince||0))*30),expires:null,status:'active',source:'legacy',legacy:true};
}
function vassalInstall(lord,sub,type,terms,source='voluntary'){
 const previous=sub.vassalContract,now=G.day;
 sub.vassalContract={v:1,lord:lord.id,sub:sub.id,type,terms:JSON.parse(JSON.stringify(terms)),started:now,expires:terms.duration?now+terms.duration*30:null,status:'active',source,revision:(previous?.revision||0)+1};
 sub.vassalType=type;
}
function vassalDuty(sub,kind,enemy){
 const c=vassalContractOf(sub);if(!c)return false;
 if(kind==='protect')return c.terms.defense;
 if(c.terms.war==='all')return true;
 if(c.terms.war!=='defense')return false;
 const lord=G.emps[c.lord],d=lord?.warDefense?.[enemy?.id];
 return !!(enemy&&d?.defensive&&d.since===lord.warSince?.[enemy.id]);
}
function vassalSensorActive(taker,giver){
 const sub=taker?.overlord===giver?.id?taker:giver?.overlord===taker?.id?giver:null;
 return !!(sub&&vassalContractOf(sub)?.terms.sensors);
}
function vassalEstimate(sub,terms){
 const c=terms||vassalContractOf(sub)?.terms,out={};if(!c)return out;
 for(const r of VASSAL_RESOURCES)out[r]=Math.min(Math.max(0,sub.inc?.[r]||0)*c.tax[r]*(sub.edicts?.ekVergi?1.5:1),Math.max(0,sub.res?.[r]||0));
 out.ara=Math.min(Math.max(0,sub.inc?.ara||0)*(c.science+(sub.edicts?.bilimPayi?.since!==undefined?.18:0)),Math.max(0,sub.res?.ara||0));return out;
}
function vassalTransaction(fn){
 if(_dealTxActive||G._sideBuf)return {ok:false,why:'Başka bir diplomatik işlem sürüyor'};
 let tx=null,result;const buf=[];_dealTxActive=true;
 try{tx=dealTxBegin();G._sideBuf=buf;result=fn();if(!result?.ok){dealTxRollback(tx);return result;}if(typeof G._vassalFailInject==='function')G._vassalFailInject();commitSideBuffer(buf);}
 catch(err){if(tx)dealTxRollback(tx);return {ok:false,why:'İşlem uygulanamadı; önceki durum korundu'};}
 finally{if(tx)dealTxRestoreAuth(tx);_dealTxActive=false;}
 flushSideBuffer(buf);return result;
}
function vassalDeclaredWars(e){return G.emps.filter(o=>o!==e&&!o.dead&&!o.wild&&!o.crisisSide&&e.war?.[o.id]).map(o=>o.id);}
function vassalTalkValid(q){
 const lord=G.emps[q?.lord],sub=G.emps[q?.sub];
 if(!q||q.status!=='pending'||!lord||!sub||lord===sub||![lord.id,sub.id].includes(q.from)||![lord.id,sub.id].includes(q.to)||q.from===q.to||lord.dead||sub.dead||lord.wild||sub.wild||lord.crisisSide||sub.crisisSide||lord.war[sub.id]||sub.war[lord.id]||!lord.contact?.[sub.id]&&!sub.contact?.[lord.id]||isPurifier(lord)||isPurifier(sub))return {ok:false,why:'Taraflar veya diplomatik koşullar değişti'};
 if(G.day>=q.expires)return {ok:false,why:'Teklifin süresi doldu'};
 if(q.kind==='new'?(isVassal(sub)||isVassal(lord)||vassalsOf(sub).length):(sub.overlord!==lord.id||!isVassal(sub)))return {ok:false,why:'Egemenlik bağı değişti'};
 if(q.kind!=='release'&&!vassalTerms(q.type,q.terms))return {ok:false,why:'Geçersiz sözleşme hükümleri'};
 return {ok:true};
}
function vassalTalkFinish(sub,status,why){
 const q=sub.vassalTalk;if(!q||q.status!=='pending')return;
 q.status=status;q.finished=G.day;q.why=why;sub._vassalTalkAfter=G.day+360;
 if(status==='rejected'&&typeof remember==='function')remember(G.emps[q.from],q.to,'sinirGergin');
}
function vassalOffer(e,o,mode,type='haracguzar',raw=null){
 const existing=mode==='renew'||mode==='release',sub=existing?(isVassal(e)&&e.overlord===o.id?e:o.overlord===e.id?o:null):mode==='demand'?o:e,lord=existing?(sub&&overlordOf(sub)):mode==='demand'?e:o;
 if(!sub||!lord||!e||!o||e===o||G.emps[e.id]!==e||G.emps[o.id]!==o)return {ok:false,why:'Geçerli bir senyör ve vasal gerekir'};
 if(!existing&&(sub.freeUntil||0)>(G.memAge||0))return {ok:false,why:'Yeni bağımsızlığın koruma süresi devam ediyor'};
 const recent=[e,o].flatMap(x=>[x.vassalTalk,...(x.vassalTalkHistory||[])]).some(q=>q&&q.finished>G.day-360&&[q.lord,q.sub].includes(e.id)&&[q.lord,q.sub].includes(o.id));if(recent)return {ok:false,why:'Bu iki devlet arasında 12 aylık müzakere soğuma süresi sürüyor'};
 const old=sub.vassalTalk;if(old?.status==='pending'&&G.day<old.expires)return {ok:false,why:'Bu vasal için zaten bekleyen müzakere var'};
 if((sub._vassalTalkAfter||0)>G.day)return {ok:false,why:'Müzakere soğuma süresi devam ediyor'};
 const c=existing?vassalContractOf(sub):null;
 if(existing&&(!c||c.lord!==lord.id))return {ok:false,why:'Geçerli sözleşme yok'};
 if(mode==='release'&&e!==sub)return {ok:false,why:'Barışçıl bağımsızlığı vasal talep eder'};
 if(mode==='renew'&&G.day<(c.started+c.terms.renegotiate*30))return {ok:false,why:'Yeniden müzakere tarihi gelmedi'};
 const terms=vassalTerms(type,raw||vassalDefaultTerms(type));if(!terms)return {ok:false,why:'Bu vasal türü için hükümler geçersiz'};
 const cost=mode==='demand'?VASSAL_DEMAND_COST:mode==='seek'?VASSAL_SEEK_COST:mode==='release'?40:60;
 const gate=existing?{ok:!e.war[o.id]&&!e.dead&&!o.dead&&!isPurifier(e)&&!isPurifier(o),why:'Savaş veya doktrin müzakereye engel'}:mode==='demand'?canDemandVassal(e,o):canSeekProtection(e,o);
 if(!gate.ok)return gate;if((e.res.etk||0)<cost)return {ok:false,why:cost+' Etki gerekir'};
 const result=vassalTransaction(()=>{
  if(old){sub.vassalTalkHistory=(sub.vassalTalkHistory||[]).concat(JSON.parse(JSON.stringify(old))).slice(-12);}
  e.res.etk-=cost;sub.vassalTalkSeq=(sub.vassalTalkSeq||0)+1;
  sub.vassalTalk={v:1,id:sub.id+':'+sub.vassalTalkSeq,lord:lord.id,sub:sub.id,kind:existing?mode==='release'?'release':'renew':'new',mode,type,terms,from:e.id,to:o.id,born:G.day,expires:G.day+180,round:1,status:'pending',disclosedWars:{[e.id]:vassalDeclaredWars(e)},paid:{[e.id]:cost},history:[{day:G.day,by:e.id,action:'offer',why:'Açık sözleşme teklifi',terms:JSON.parse(JSON.stringify(terms))}]};
  return {ok:true,pending:true};
 });
 if(result.ok){vassalDriveAI(sub);vassalInboxSync();return {...result,kabul:sub.vassalTalk.status==='accepted',karar:sub.vassalTalk.status,round:sub.vassalTalk.round};}return result;
}
function aiVassalAssessment(e,q){
 const lord=G.emps[q.lord],sub=G.emps[q.sub],other=e===sub?lord:sub,t=q.terms,own=e===sub,profile=aiProfile(e),goal=e.aiStrategy?.objective?.kind||'development',known=aiKnownPower(e,other),power=Math.max(1,totalPower(e)),rel=e.rel[other.id]||0,trust=clamp(rel/100,-1,1),grudge=typeof grudgeOf==='function'?grudgeOf(e,other.id):0;
 const wars=G.emps.filter(o=>o!==e&&!o.dead&&!o.wild&&e.war[o.id]),threat=wars.reduce((n,o)=>Math.max(n,aiKnownPower(e,o)/power),0),recovery=goal==='recovery'||['ene','min','ala','tuk'].some(r=>(e.inc?.[r]||0)<0&&(e.res[r]||0)<-(e.inc[r]||0)*6);
 let score=0;const reasons=[];
 const add=(n,why)=>{score+=n;reasons.push({value:Math.round(n*100)/100,why});};
 if(q.kind==='release'){
  if(own)return {decision:'accept',score:1,reasons:[{value:1,why:'Bağımsızlık isteği'}]};
  add((known/power-1)*.35,'Bilinen güç dengesi');add((sub.vassalAnger||0)/180,'Kendi vasalının açık bağımsızlık arzusu');add(recovery?.25:0,'Kendi toparlanma ihtiyacı');add(trust*.15,'Güven');add(-.55,'Sözleşme ve stratejik bağlılığı koruma');
 }else if(own){
  const ratio=known/power;add(clamp((ratio-1)*.18,0,.65),'Bilinen koruyucu güç');add(clamp(threat*.18,0,.5),'Kendi mevcut tehdidi');add(trust*.25-grudge/250,'Diplomatik hafıza ve güven');
  const burden=VASSAL_RESOURCES.reduce((n,r)=>n+t.tax[r],0)/3+t.science*.65;add(-burden*1.5,'Gerçek gelirden istenen vergi ve bilim payı');
  const projected=vassalEstimate(e,t);if(VASSAL_RESOURCES.some(r=>(e.inc?.[r]||0)-(projected[r]||0)<0&&(e.res[r]||0)<Math.abs((e.inc?.[r]||0)-(projected[r]||0))*6))add(-.5,'Altı aylık kendi rezervi yükü karşılamıyor');
  add(t.defense?.2:-.4,'Senyörün koruma yükümlülüğü');add(t.war==='all'?(recovery?-.5:-.22):t.war==='defense'?-.08:.08,'Askerî yükümlülük ve hazırlık');add(t.autonomy==='free'?.12:-.15,'Diplomatik özerklik');add(profile.war>.8?-.15:0,'Askerî kişilik');add(goal==='regional'||goal==='hegemony'?-.12:0,'Uzun vadeli bağımsız güç hedefi');add(-.15,'Bağımsızlığın siyasi değeri');
 }else{
  add(trust*.3-grudge/250,'Güven ve diplomatik hafıza');add(.25,'Himayenin stratejik değeri');add(t.war==='all'?.28:t.war==='defense'?.1:0,'Müttefik askerî yükümlülük');add(VASSAL_RESOURCES.reduce((n,r)=>n+t.tax[r],0)*.3+t.science*.7,'Sözleşmenin gelir ve bilim faydası');
  add(t.defense?(recovery?-.5:-.12):.12,'Kendi koruma hazırlığı ve toparlanma ihtiyacı');
  const knownFronts=new Set([...(q.disclosedWars?.[sub.id]||[]),...G.emps.filter(o=>o!==e&&e.contact?.[o.id]&&aiKnownWar(e,sub,o)).map(o=>o.id)]);let unknown=0;const knownThreat=[...knownFronts].reduce((n,id)=>{const o=G.emps[id];if(!e.contact?.[id]){unknown++;return n;}return Math.max(n,aiKnownPower(e,o)/power);},0);if(t.defense)add(-clamp(knownThreat*.22+unknown*.2,0,.7),'Bilinen / teklifte bildirilen koruma cephesi yükü');add(profile.war>.8?.1:profile.war<.3?-.1:0,'Kişilik ve askerî amaç');
 }
 if(own&&q.kind==='new'&&t.defense&&!aiProtection(e,lord).ok)add(-.65,'Bilinen ulaşılabilir koruma rotası yok');
 const decision=score>=.18?'accept':score>-.65&&q.round<3?'counter':'reject';
 return {decision,score:Math.round(score*1000)/1000,goal,recovery,reasons};
}
function aiVassalCounter(e,q){
 const terms=JSON.parse(JSON.stringify(q.terms));
 if(q.kind==='release'){
  const c=vassalContractOf(G.emps[q.sub]);if(!c)return null;
  for(const r of VASSAL_RESOURCES)terms.tax[r]=Math.max(0,terms.tax[r]-.05);
  terms.science=Math.max(q.type==='akademik'?.05:0,terms.science-.05);terms.autonomy='free';terms.duration=60;return terms;
 }
 if(e.id===q.sub){for(const r of VASSAL_RESOURCES)terms.tax[r]=Math.max(0,terms.tax[r]-.05);terms.science=Math.max(q.type==='akademik'?.05:0,terms.science-.05);terms.defense=true;terms.autonomy='free';if(terms.war==='all')terms.war='defense';}
 else {if(q.type==='akademik')terms.science=Math.min(.30,terms.science+.05);else for(const r of ['ene','min','ala'])terms.tax[r]=Math.min(q.type==='haracguzar'?.30:.10,terms.tax[r]+.05);if(q.type!=='akademik')terms.war='defense';terms.autonomy='consent';}
 return vassalTerms(q.type,terms);
}
function vassalReply(actor,subId,id,round,action,terms=null,world=G.emps){
 const sub=G.emps[subId],q=sub?.vassalTalk,valid=vassalTalkValid(q);
 if(world!==G.emps||G.emps[actor?.id]!==actor||!valid.ok||!q||q.id!==id||q.round!==+round||q.to!==actor?.id||!['accept','reject','counter'].includes(action))return {ok:false,why:valid.why||'Bu tur artık geçerli değil'};
 const assessment=actor.ai?aiVassalAssessment(actor,q):null,why=assessment?assessment.reasons.map(r=>r.why+': '+r.value).join(' · '):'Oyuncunun açık kararı';
 if(action==='counter'&&(q.round>=3||(actor.res.etk||0)<20))return {ok:false,why:'En çok üç tur; karşı teklif 20 Etki ister'};
 const normalized=action==='counter'?vassalTerms(q.type,terms):null;if(action==='counter'&&!normalized)return {ok:false,why:'Geçersiz karşı teklif'};
 const result=vassalTransaction(()=>{
  if(action==='reject'){q.history.push({day:G.day,by:actor.id,action,why});vassalTalkFinish(sub,'rejected',why);return {ok:true};}
  if(action==='counter'){
   if(JSON.stringify(normalized)===JSON.stringify(q.terms)&&q.kind!=='release')return {ok:false,why:'Karşı teklif en az bir hükmü değiştirmeli'};
   actor.res.etk-=20;q.disclosedWars=q.disclosedWars||{};q.disclosedWars[actor.id]=vassalDeclaredWars(actor);q.paid[actor.id]=(q.paid[actor.id]||0)+20;q.history.push({day:G.day,by:actor.id,action,why,terms:normalized});q.terms=normalized;
   if(q.kind==='release')q.kind='renew';[q.from,q.to]=[q.to,q.from];q.round++;q.expires=G.day+180;return {ok:true};
  }
  const lord=G.emps[q.lord];
  if(q.kind==='release'){if(!freeVassal(sub,'barışçıl bağımsızlık anlaşması'))throw Error('release failed');}
  else if(q.kind==='new'){if(!subjugate(lord,sub,q.type,q.terms,'voluntary'))throw Error('subjugation failed');sub.rel[lord.id]=clamp((sub.rel[lord.id]||0)+(q.mode==='seek'?(sub.ai?25:20):-15),-100,100);}
  else {vassalInstall(lord,sub,q.type,q.terms,'renegotiated');if(vassalContractOf(sub)?.terms.war!=='none')vassalJoinWars(lord,sub);}
  q.history.push({day:G.day,by:actor.id,action,why});vassalTalkFinish(sub,'accepted',why);recalcMods(lord);recalcMods(sub);return {ok:true};
 });
 if(result.ok){vassalDriveAI(sub);vassalInboxSync();}return result;
}
function vassalDriveAI(sub){
 if(sub._vassalDriving)return;sub._vassalDriving=true;
 try{for(let i=0;i<3;i++){
  const q=sub.vassalTalk;if(!q||q.status!=='pending')break;
  const e=G.emps[q.to];if(!e?.ai)break;
  const a=aiVassalAssessment(e,q);let action=a.decision,terms=action==='counter'?aiVassalCounter(e,q):null;
  if(action==='counter'&&(!terms||e.res.etk<20))action='reject';
  const r=vassalReply(e,sub.id,q.id,q.round,action,terms);if(!r.ok)break;
 }}finally{delete sub._vassalDriving;}
}
function vassalInboxSync(){
 if(typeof DiplomaticInbox==='undefined'||!G.p)return;
 for(const sub of G.emps){const q=sub.vassalTalk;if(!q||![q.lord,q.sub].includes(G.p.id))continue;
  const other=q.lord===G.p.id?q.sub:q.lord;
  DiplomaticInbox.source('vassal','vassal:'+q.id+':'+q.round,other,sub.id,q.id+':'+q.round,q.expires,'Vasallık sözleşmesi · '+(q.kind==='release'?'Bağımsızlık talebi':VASSAL_TYPES[q.type].n),q.history.at(-1)?.why||'Sözleşme teklifi');
 }
}
function vassalTalkTick(){
 for(const sub of G.emps){
  const q=sub.vassalTalk;
  if(q?.status==='pending'){const valid=vassalTalkValid(q);if(!valid.ok)vassalTalkFinish(sub,G.day>=q.expires?'expired':'invalid',valid.why);else vassalDriveAI(sub);}
  const c=vassalContractOf(sub);if(!c)continue;
  if(c.expires!==null&&G.day>=c.expires){if(sub.vassalContract)sub.vassalContract.status='expired';freeVassal(sub,'sözleşme süresi doldu');continue;}
  if(!sub.ai||sub.dead||(sub._vassalTalkAfter||0)>G.day||sub.vassalTalk?.status==='pending'||G.day<c.started+c.terms.renegotiate*30)continue;
  const lord=overlordOf(sub),recovery=sub.aiStrategy?.objective?.kind==='recovery';
  if((sub.vassalAnger||0)>=65&&totalPower(sub)>=aiKnownPower(sub,lord)*.65&&sub.res.etk>=40)vassalOffer(sub,lord,'release',c.type,c.terms);
  else if(recovery&&sub.res.etk>=60&&(Object.values(c.terms.tax).some(v=>v>.1)||c.terms.science>.15)){
   const next=aiVassalCounter(sub,{...q,type:c.type,terms:c.terms,sub:sub.id,kind:'renew'});if(next)vassalOffer(sub,lord,'renew',c.type,next);
  }
 }
 vassalInboxSync();
}
function restoreVassalContracts(){
 for(const sub of G.emps){const c=sub.vassalContract,q=sub.vassalTalk;
  if(sub.vassalPaidMonth!==undefined&&(!Number.isSafeInteger(sub.vassalPaidMonth)||sub.vassalPaidMonth<0))throw Error('Bozuk vasallık ödeme dönemi');
  if(c&&(c.v!==1||c.sub!==sub.id||!Number.isSafeInteger(c.lord)||!G.emps[c.lord]||!vassalTerms(c.type,c.terms)||!Number.isFinite(c.started)||c.expires!==null&&!Number.isFinite(c.expires)||!['active','ended','expired'].includes(c.status)))throw Error('Bozuk vasallık sözleşmesi');
  if(q&&(q.v!==1||q.sub!==sub.id||!G.emps[q.lord]||!G.emps[q.from]||!G.emps[q.to]||!['new','renew','release'].includes(q.kind)||!['pending','accepted','rejected','expired','invalid'].includes(q.status)||!Number.isSafeInteger(q.round)||q.round<1||q.round>3||typeof q.id!=='string'||q.id.length>64||!Number.isFinite(q.born)||!Number.isFinite(q.expires)||!vassalTerms(q.type,q.terms)||q.disclosedWars!==undefined&&(!q.disclosedWars||typeof q.disclosedWars!=='object'||Object.entries(q.disclosedWars).some(([id,fronts])=>![String(q.lord),String(q.sub)].includes(id)||!Array.isArray(fronts)||fronts.length>G.emps.length||fronts.some(id=>!Number.isSafeInteger(id)||!G.emps[id])))||!q.paid||typeof q.paid!=='object'||Object.values(q.paid).some(n=>!Number.isFinite(n)||n<0)||!Array.isArray(q.history)||q.history.length>8||q.history.some(r=>!r||!Number.isFinite(r.day)||!G.emps[r.by]||typeof r.why!=='string'||r.why.length>2000)))throw Error('Bozuk vasallık müzakeresi');
  delete sub._vassalDriving;
 }
}

/* BETA-WAR-CENTER.0: voluntary participation is a clause of the existing
   transaction, tied to an immutable source front. No new war/offer store. */
function warFrontKnown(e,f){
 if(!e||!f||!f.sides.every(id=>id===e.id||e.contact[id]))return false;
 return f.sides.includes(e.id)||f.sponsor===e.id||(G.warLedger?.fronts||[]).some(x=>x.sides.includes(e.id)&&x.parent===f.id)||f.sides.some(id=>intelOf(e,id)>=3);
}
function warCenterIndex(e){
 if(!e||G.emps[e.id]!==e)return [];
 const known=id=>id===e.id||!!e.contact[id];
 return (G.warLedger?.fronts||[]).filter(f=>warFrontKnown(e,f)).map(f=>({id:f.id,campaign:f.campaign,sides:f.sides.slice(),roles:f.roles.slice(),opened:f.legacy?null:f.opened,ended:f.ended,entryKind:f.entryKind,sponsor:Number.isInteger(f.sponsor)&&known(f.sponsor)?f.sponsor:null,mine:f.sides.includes(e.id)}));
}
function warSupportGate(joiner,sponsor,it){
 const no=why=>({ok:false,why}),f=(G.warLedger?.fronts||[]).find(x=>x.id===it?.front);
 if(!joiner||!sponsor||G.emps[joiner.id]!==joiner||G.emps[sponsor.id]!==sponsor||joiner===sponsor||joiner.dead||sponsor.dead||joiner.wild||sponsor.wild||joiner.crisisSide||sponsor.crisisSide)return no('Geçerli iki devlet gerekir');
 const plan=it?.plan&&warPreparation(it.plan);
 if(plan){if(plan.owner!==sponsor.id||plan.target!==it.target||warPreparationState(plan)!=='pending'||sponsor.war[it.target])return no('Savaş hazırlığı artık geçerli değil');}
 else if(it?.plan||!f||f.ended!==null||!warLedgerPair(...f.sides)||!f.sides.includes(sponsor.id)||!f.sides.includes(it.target)||it.target===sponsor.id)return no('Kaynak savaş sona erdi veya tarafı değişti');
 const enemy=G.emps[it.target];
 if(!joiner.contact[sponsor.id]||!sponsor.contact[joiner.id]||!joiner.contact[enemy.id]||!sponsor.contact[enemy.id])return no('Katılım için taraflarla temas gerekli');
 if(joiner.war[enemy.id]||enemy.war[joiner.id])return no('Zaten tarafsın; yeni ücretli katılım yok');
 const role=f?f.roles[f.sides.indexOf(sponsor.id)]:0,fs=f?(G.warLedger.fronts||[]).filter(x=>x.campaign===f.campaign&&x.ended===null):[];
 if(joiner.war[sponsor.id]||fs.some(x=>x.sides.some((id,i)=>(id===joiner.id&&x.roles[i]!==role)||(x.roles[i]===role&&joiner.war[id]))))return no('Desteklenen tarafla çakışan savaş var');
 if(joiner.ally[enemy.id]||enemy.ally[joiner.id]||joiner.nap?.[enemy.id]>G.day||enemy.nap?.[joiner.id]>G.day)return no('Mevcut ittifak veya saldırmazlık katılımı engelliyor');
 const peace=Math.max(joiner.peaceAt?.[enemy.id]??-9999,enemy.peaceAt?.[joiner.id]??-9999);
 if(G.day-peace<720-grudgeOf(joiner,enemy.id)*5)return no('Barış sonrası mevcut savaş değerlendirme süresi dolmadı');
 const promise=canPromiseWarOn(joiner,enemy);if(!promise.ok)return promise;
 const access=warDeclarationAccess(joiner,enemy,{authorized:true});if(!access.ok)return access;
 return {ok:true,why:'Kabulde yalnız bu cepheye katılım ve anlaşma şartları birlikte uygulanır',campaign:f?.campaign??null};
}
function warSupportReach(e,enemy,other,terms=[]){
 const targets=G.sys.filter(s=>(s.seen||[]).includes(e.id)&&s.owner===enemy.id),fleets=G.fleets.filter(f=>f.e===e.id&&isArmed(f));
 const passage=terms.some(x=>x.t==='passage');
 return fleets.some(f=>targets.some(s=>findPath(f.mv?f.mv.to:f.sys,s.id,e,(v,u)=>{const t=G.sys[v];return (t.seen||[]).includes(e.id)&&(t.owner===enemy.id||canEnter(e,t)||passage&&t.owner===other.id||hasUsableGate(e,G.sys[u])&&hasUsableGate(e,t));})!==null));
}

/* Preparations are conditional signed deal terms inside the same ledger, not
   a second offer queue. Existing inbox/MP offers perform all negotiations. */
function warPreparation(id){return G.warLedger?.preparations?.find(p=>p.id===id)||null;}
function warPreparationState(p){return p.state==='pending'&&G.day>=p.expires?'expired':p.state;}
function warPreparationsValid(rows){
 if(!Array.isArray(rows)||rows.length>64)return false;const ids=new Set();
 for(const p of rows){if(!p||!Number.isSafeInteger(p.id)||p.id<1||ids.has(p.id)||!G.emps[p.owner]||!G.emps[p.target]||p.owner===p.target||!Object.hasOwn(WAR_GOALS,p.goal)||!['pending','cancelled','launched'].includes(p.state)||!Number.isFinite(p.opened)||!Number.isFinite(p.expires)||p.opened<0||p.expires<=p.opened||!Array.isArray(p.commitments)||p.commitments.length>8)return false;ids.add(p.id);
  const members=new Set();for(const c of p.commitments){const n=encodeOffer(c.terms),j=n&&n.give.concat(n.want).filter(i=>i.t==='warJoin');if(!n||!G.emps[n.from]||!G.emps[n.to]||!['accepted','applied','withdrawn'].includes(c.state)||!Number.isFinite(c.at)||j.length!==1||j[0].plan!==p.id||j[0].target!==p.target||j[0].front!==undefined||(n.give.includes(j[0])?n.from:n.to)!==c.member||(n.give.includes(j[0])?n.to:n.from)!==p.owner||n.give.concat(n.want).some(i=>!['res','passage','warJoin'].includes(i.t)||i.t==='res'&&(!RES[i.r]||!Number.isFinite(i.v)||i.v<=0||i.v>DEAL_AMOUNT_LIMIT))||!G.emps[c.member]||members.has(c.member)||![n.from,n.to].includes(p.owner)||![n.from,n.to].includes(c.member))return false;members.add(c.member);}
 }return true;
}
function warPrepareCreate(e,target,goal){
 const q=warDeclarationPreview(e,G.emps[target],goal);if(!q.ok||councilBlocksWar(e,G.emps[target]))return {ok:false,why:q.blockers.join(' · ')||'Konsey yasağı'};
 const rows=G.warLedger?.preparations||[];if(rows.some(p=>p.owner===e.id&&p.target===target&&warPreparationState(p)==='pending'))return {ok:false,why:'Bu hedef için açık hazırlık var'};
 if(rows.filter(p=>warPreparationState(p)==='pending').length>=16)return {ok:false,why:'Bekleyen hazırlık sınırı'};
 const p={id:Math.max(0,...rows.map(x=>x.id))+1,owner:e.id,target,goal,opened:G.day,expires:G.day+180,state:'pending',commitments:[]};
 if(!G.warLedger)G.warLedger=warLedgerEmpty();G.warLedger.preparations=rows.filter(x=>warPreparationState(x)==='pending').concat(rows.filter(x=>warPreparationState(x)!=='pending').slice(-47),p);return {ok:true,id:p.id};
}
function warPrepareAccept(offer,archived){
 if(G._sideBuf)return false;const q=dealQuote(offer);if(!q.ok)return false;const n=encodeOffer(q.norm),joins=n.give.concat(n.want).filter(x=>x.t==='warJoin'),j=joins[0],p=j&&warPreparation(j.plan);
 if(joins.length!==1||!p||n.give.concat(n.want).some(x=>!['res','passage','warJoin'].includes(x.t)))return false;
 const member=n.give.includes(j)?n.from:n.to; // encodeOffer allocates lists, j is an exact member of them
 if(p.owner===(member)||![n.from,n.to].includes(p.owner)||p.commitments.some(c=>c.member===member&&c.state!=='withdrawn')||p.commitments.length>=8)return false;
 const tx=dealTxBegin();try{p.commitments=p.commitments.filter(c=>c.member!==member);p.commitments.push({member,terms:n,at:G.day,state:'accepted'});if(archived){archived.status='accepted';archived.finished=G.day;}return true;}catch{dealTxRollback(tx);return false;}
}
function warPrepareQuote(e,id){
 const p=warPreparation(id),no=why=>({ok:false,why,stamp:''});if(!p||p.owner!==e.id||warPreparationState(p)!=='pending')return no('Hazırlık açık değil veya yetkin yok');
 const preview=warDeclarationPreview(e,G.emps[p.target],p.goal);if(!preview.ok||councilBlocksWar(e,G.emps[p.target]))return no(preview.blockers.join(' · ')||'Konsey yasağı');
 const contracts=p.commitments.filter(c=>c.state==='accepted');if(!contracts.length)return no('En az bir açık kabul gerekli; basit ilan yolu ayrı kullanılabilir');
 const sums=new Map(),add=(id,r,n)=>{const k=id+':'+r;sums.set(k,(sums.get(k)||0)+n);};add(e.id,'etk',preview.cost);
 for(const c of contracts){const q=dealQuote(c.terms);if(!q.ok)return no('Bir katılımcının savaş veya anlaşma koşulları değişti; kabulü geri çekip yeniden müzakere et');
  for(const [id,items]of[[q.norm.from,q.norm.effectiveGive],[q.norm.to,q.norm.effectiveWant]])for(const i of items)if(i.t==='res')add(id,i.r,i.v);
  add(q.norm.from,'etk',q.cost);
 }
 for(const [key,n]of sums){const[id,r]=key.split(':');if((G.emps[+id].res[r]||0)<n)return no('Toplam taahhütler için kaynak yetersiz');}
 return {ok:true,why:'Son onayda ilan, bütün katılımlar ve bedeller birlikte uygulanır',stamp:JSON.stringify([p.id,p.goal,p.target,preview.signature,contracts.map(c=>c.terms)]),members:contracts.map(c=>c.member)};
}
function warPrepareWithdraw(e,id,member=null){
 const p=warPreparation(id);if(!p||warPreparationState(p)!=='pending')return {ok:false,why:'Hazırlık kapalı'};
 if(member===null&&p.owner===e.id){p.state='cancelled';return {ok:true};}
 const c=p.commitments.find(x=>x.member===member&&x.state==='accepted');if(!c||e.id!==p.owner&&e.id!==member)return {ok:false,why:'Bu kabul üzerinde yetkin yok'};c.state='withdrawn';return {ok:true};
}
function warPrepareView(e){return (G.warLedger?.preparations||[]).filter(p=>p.owner===e.id||p.commitments.some(c=>c.member===e.id)).map(p=>({id:p.id,owner:p.owner,target:p.target,goal:p.goal,opened:p.opened,expires:p.expires,state:warPreparationState(p),commitments:p.commitments.filter(c=>p.owner===e.id||c.member===e.id).map(c=>({member:c.member,state:c.state,terms:encodeOffer(c.terms)})),...(p.owner===e.id?{quote:ColonyInfo.read(()=>warPrepareQuote(e,p.id))}:{})}));}
function warPrepareLaunch(e,id,stamp){
 const p=warPreparation(id),q=warPrepareQuote(e,id);if(!q.ok||q.stamp!==stamp||_dealTxActive||_warLaunchBuffer||G._sideBuf)return {ok:false,why:q.why||'Koşullar değişti; yeniden önizle'};
 const tx=dealTxBegin(),buf=[];_warLaunchBuffer=buf;try{
  G._sideBuf=[];G._dealAuth=true;
  if(!declareWar(e,G.emps[p.target])||!setWarGoal(e,G.emps[p.target],p.goal))throw Error('Savaş ilanı uygulanamadı');
  commitSideBuffer(G._sideBuf);buf.push(...G._sideBuf);delete G._sideBuf;
  const front=warLedgerFind(e.id,p.target);if(!front)throw Error('Cephe oluşturulamadı');
  for(const c of p.commitments.filter(c=>c.state==='accepted')){const n=encodeOffer(c.terms);for(const list of[n.give,n.want])for(let i=0;i<list.length;i++)if(list[i].t==='warJoin')list[i]={t:'warJoin',front:front.id,target:p.target};
   if(!executeDeal(n))throw Error('Katılım şartları son anda değişti');c.state='applied';}
  p.state='launched';p.front=front.id;p.finished=G.day;
 }catch(err){dealTxRollback(tx);return {ok:false,why:'Hazırlık uygulanamadı; savaş ve bütün bedeller geri alındı'};}
 finally{_warLaunchBuffer=null;dealTxRestoreAuth(tx);}
 flushSideBuffer(buf);return {ok:true,front:p.front};
}
/* Autonomous follow-up is scoped to an explicitly negotiated coalition.
   Unused new mechanics leave the old AI/RNG path byte-for-byte unchanged. */
function warCoalitionTick(){
 const roots=(G.warLedger?.fronts||[]).filter(f=>f.coalition&&f.ended===null&&warLedgerPair(...f.sides));
 for(const f of roots)for(const sponsor of f.sides.map(id=>G.emps[id])){
  if(!sponsor.ai||sponsor.dead||sponsor.wild||sponsor.crisisSide||sponsor.coalitionTalk?.until>G.day)continue;
  const enemy=G.emps[f.sides.find(id=>id!==sponsor.id)];
  if(aiKnownPower(sponsor,enemy)<aiKnownPower(sponsor,sponsor)*.8)continue;
  const friend=G.emps.find(e=>e!==sponsor&&e!==enemy&&!e.dead&&!e.wild&&!e.crisisSide&&sponsor.contact[e.id]&&sponsor.ally[e.id]&&warSupportGate(e,sponsor,{front:f.id,target:enemy.id}).ok);
  if(!friend)continue;
  const give=[],v=Math.min(250,Math.floor(Math.max(0,sponsor.res.min||0)*.05));if(v>=10)give.push({t:'res',r:'min',v});
  const want=[{t:'warJoin',front:f.id,target:enemy.id}];sponsor.coalitionTalk={until:G.day+180,front:f.id,to:friend.id};
  if(friend.id===0){const o={from:sponsor.id,to:0,give,want,born:G.day,expires:G.day+180};if(dealQuote(o).ok)UI.aiOffer(o);}
  else aiNegotiate(sponsor,friend,give,want,true);
 }
}

/* BETA-FED-AI.0: a material charter/roster revision needs fresh consent.
   The proposal ID and original deadline survive; historical consents never
   authorize the new revision. Existing revision-zero saves/commands retain
   their old representation. */
function fedFoundUpdate(e,id,revision,type,ballot,selected){
 const p=fedFoundGet(id);if(!p||p.by!==e?.id||G.emps[e.id]!==e||p.status!=='pending'||G.day>=p.expires||revision!==(p.revision||0)||revision>=12)return {ok:false,why:'Güncel açık taslak ve kurucu yetkisi gerekli; süre uzatılmaz'};
 const q=fedFoundQuote(e,type,ballot,selected);if(!q.ok)return q;
 const members=[e.id,...selected.slice().sort((a,b)=>a-b)],terms=type+'|'+ballot+'|'+members.join(',');
 if(terms===p.type+'|'+p.ballot+'|'+p.members.join(','))return {ok:false,why:'Şartlar değişmedi; mevcut rızalar korunuyor'};
 const previous={revision:p.revision||0,type:p.type,ballot:p.ballot,members:p.members.slice(),replies:JSON.parse(JSON.stringify(p.replies)),day:G.day};
 p.revision=(p.revision||0)+1;p.revisions=[...(p.revisions||[]),previous].slice(-12);p.type=type;p.ballot=ballot;p.members=members;p.replies={};
 p.replies[e.id]={status:'accepted',terms:fedFoundTerms(p),day:G.day,why:'Güncel kuruluş şartlarını önerdi'};
 for(const id of members)if(id!==e.id){const o=G.emps[id],a=fedFoundHuman(o)?null:fedFoundAssessment(o,e,p);p.replies[id]={terms:fedFoundTerms(p),status:a?(a.ok?'accepted':'rejected'):'pending',day:G.day,why:a?String(a.why).slice(0,300):'Kadro/tür/rejim değişti; yeni açık onay gerekli'};}
 return {ok:true,id:p.id,revision:p.revision,reconfirm:members.filter(id=>id!==e.id&&previous.members.includes(id)).length,why:'Yeni şart sürümü gönderildi; eski kabul geçmişi saklandı, süre uzatılmadı'};
}
function fedFoundRestoreEdits(p){
 if(p.revision===undefined&&p.revisions===undefined)return {};
 if(!Number.isInteger(p.revision)||p.revision<1||p.revision>12||!Array.isArray(p.revisions)||p.revisions.length>12)return null;
 const revisions=[];let last=-1;
 for(const h of p.revisions){if(!h||!Number.isInteger(h.revision)||h.revision<=last||h.revision>=p.revision||!Object.hasOwn(FED_TYPES,h.type)||!Object.hasOwn(FED_BALLOTS,h.ballot)||!Array.isArray(h.members)||h.members.length>49||h.members.length<2||new Set(h.members).size!==h.members.length||!h.members.includes(p.by)||h.members.some(id=>!Number.isInteger(id)||!G.emps[id])||!Number.isFinite(h.day))return null;
  const replies={};for(const id of h.members){const r=h.replies?.[id];if(!r||!['pending','accepted','rejected'].includes(r.status)||!Number.isFinite(r.day))return null;replies[id]=fedFoundCleanReply(r);}
  revisions.push({revision:h.revision,type:h.type,ballot:h.ballot,members:h.members.slice(),replies,day:h.day});last=h.revision;
 }return {revision:p.revision,revisions};
}
function fedFoundRecordRevision(r){const v=String(r?.key||'').split(':')[2];return /^\d+$/.test(v||'')?+v:0;}

function fedFoundProjectEdits(p,viewer,pi){
 if(!p.revision)return {};
 return {revision:p.revision,revisions:p.revisions.filter(h=>h.members.includes(viewer)).map(h=>({...h,members:h.members.map(pi),replies:Object.fromEntries(Object.entries(h.replies).map(([id,r])=>[pi(+id),{...r,terms:r.terms===fedFoundTerms(h)?fedFoundTerms({...h,members:h.members.map(pi)}):'',why:viewer===p.by||+id===viewer?r.why:'Geçmiş karar kaydedildi'}]))}))};
}

function fedFoundCleanReply(r){
 const values={status:r.status,terms:String(r.terms||'').slice(0,400),day:r.day,why:String(r.why||'').slice(0,300)},out={};
 // Preserve authored field order for raw Save8 round trips, while copying
 // only the same four validated fields. No arbitrary save properties pass.
 for(const k of Object.keys(r))if(Object.hasOwn(values,k))out[k]=values[k];
 for(const k of Object.keys(values))if(!Object.hasOwn(out,k))out[k]=values[k];return out;
}

/* A bounded transfer from actual enemy stock on a real conquered colony.
   A source front owns the dedupe/budget; no separate loot ledger or free
   monthly income. Recapturing the same colony cannot farm the same front. */
function fedRaiderLoot(sys,e,oldPlanets,cause){
 if(cause!=='conquest'||!e||findFed(e)?.type!=='yagmaci')return;
 for(const old of oldPlanets){const victim=G.emps[old.owner],front=victim&&warLedgerFind(e.id,victim.id);if(!victim||victim===e||!e.war[victim.id]||!front||front.ended!==null)continue;
  const book=front.raidLoot||(front.raidLoot={}),r=book[e.id]||(book[e.id]={keys:[],min:0,ala:0}),key=sys.id+':'+old.i;
  if(r.keys.includes(key)||r.keys.length>=64)continue;r.keys.push(key);
  for(const [resource,each,cap]of[['min',120,240],['ala',40,80]]){const take=Math.min(each,cap-r[resource],Math.floor(Math.max(0,victim.res[resource]||0)*.05));if(take<=0)continue;victim.res[resource]-=take;e.res[resource]=(e.res[resource]||0)+take;r[resource]+=take;}
 }
}
function fedRaiderLootValid(f){
 if(f.raidLoot===undefined)return true;const rows=f.raidLoot;if(!rows||typeof rows!=='object'||Array.isArray(rows)||Object.keys(rows).length>2)return false;
 return Object.entries(rows).every(([id,r])=>f.sides.includes(+id)&&r&&Array.isArray(r.keys)&&r.keys.length<=64&&new Set(r.keys).size===r.keys.length&&r.keys.every(k=>typeof k==='string'&&/^\d+:\d+$/.test(k)&&k.length<40)&&Number.isFinite(r.min)&&r.min>=0&&r.min<=240&&Number.isFinite(r.ala)&&r.ala>=0&&r.ala<=80);
}

/* One active ballot; two consecutive emergency openings at most while an
   ordinary row waits. Source IDs come only from actual defensive fronts. */
function fedEmergencyId(f,e,kind,o){
 if(kind!=='joinWar'||!f)return null;
 const sponsor=G.emps[o.sponsor??e?.id],enemy=G.emps[o.target],front=sponsor&&enemy&&warLedgerFind(sponsor.id,enemy.id),def=sponsor?.warDefense?.[enemy?.id];
 if(!sponsor||!enemy||!f.members.includes(sponsor.id)||!front||front.ended!==null||!def?.defensive||def.since!==sponsor.warSince?.[enemy.id])return null;
 if(!f.members.some(id=>id!==sponsor.id&&fedSupportGate(G.emps[id],enemy).ok))return null;return front.id;
}
function fedAgendaOrder(f){
 const pending=(f.agenda?.items||[]).slice(),ordered=[];let streak=f.agenda?.emergencyStreak||0;
 while(pending.length){let i=pending.findIndex(r=>r.defenseFront);if(i<0)i=0;else if(streak>=2){const n=pending.findIndex(r=>!r.defenseFront);if(n>=0)i=n;}
  const r=pending.splice(i,1)[0];ordered.push(r);streak=r.defenseFront?Math.min(2,streak+1):0;
 }return ordered;
}
